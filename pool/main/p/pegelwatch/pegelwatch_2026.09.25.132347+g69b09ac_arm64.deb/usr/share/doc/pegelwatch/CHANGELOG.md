# Änderungsprotokoll PegelWatch

Neue Einträge unter **Unveröffentlicht** ergänzen — eine Zeile je Änderung,
so formuliert, dass ein Anwender sie versteht. Jeder Deploy macht daraus einen
Abschnitt mit dem Build-Zeitpunkt; der Text geht mit dem Binary ins
Release-Management des Cloud-Frontends und steht in der Konfigurationsseite
jeder Anlage.

## Unveröffentlicht

## 2026-09-25 13:23:47

- Konfigurationsseite: Ist die installierte Version neuer als die im Kanal freigegebene, steht dort nicht mehr fälschlich „Update verfügbar“.
- PegelWatch wird jetzt als Debian-Paket aus einer signierten Paketquelle verteilt. Updates bringen damit auch Dienst-Einstellungen, Dashboards, Dokumentation und die InfluxDB-Selbstheilung mit — auch auf Anlagen ohne SSH-Zugang.
- Neue Anlagen lassen sich mit einem Befehl selbst einrichten: curl -fsSL https://gsandreas.github.io/pegelwatch-dist/install.sh | sudo sh
- Updates werden per apt mit Signaturprüfung installiert; kommt der Dienst danach nicht hoch, wird automatisch die vorherige Version wiederhergestellt.

## 2026-09-25 12:15:04

- Auto-Update installiert nur noch neuere Versionen; eine per Deploy aufgespielte neuere Version wird nicht mehr zurückgesetzt. Ein Rollback geht über den Update-Befehl.
- Cloud-Frontend: Die stable-Version wird nie automatisch festgelegt, nur durch den Admin.

## 2026-09-25 12:07:09

- Pumpwerk: Nullpunktkalibrierung korrigiert. Die Korrektur wuchs bisher bei jeder Kalibrierung weiter an (bis 111 mV ≈ 165 mm); jetzt wird gegen den Kalibrier-Nullpunkt gerechnet, nur ein stabiler Messwert übernommen und ein unplausibler Wert verworfen und gemeldet.
- Pumpwerk: Die Nullpunkt-Korrektur bleibt über Neustarts erhalten und verfällt nur bei einer neuen Kalibrierung.
- Pumpwerk: Die Kalibrierfahrt endet, sobald die Pumpe Luft zieht — erst dann ist die Staudruckglocke sicher frei.
- Pumpwerk: Neuer Schutz gegen Luftansaugen/Trockenlauf über den Leistungsabfall (Standard: Abschaltung unter 1008 W, 20 % unter 1260 W, nach 10 s). Die Maximallaufzeit bleibt als Rückfallschutz (Standard jetzt 300 s).
- Updates: Release-Kanäle „stable“ und „daily“. Jede Anlage wählt in der Konfiguration, welchen Kanal sie bezieht; freigegeben wird im Cloud-Frontend.
- Konfigurationsseite: zeigt installierte Version, Änderungsprotokoll und das im Kanal verfügbare Update.
- Updates aus dem Cloud-Frontend werden nicht mehr mitten im Pumpenlauf installiert; die Anlage wartet, bis die Pumpe steht.

## 2026-09-24 22:34:35

- Datenbank-Ausfallalarm: Nimmt InfluxDB länger als 15 Minuten keine Messwerte an, kommt eine Mail, bei Wiederherstellung eine Entwarnung.
- InfluxDB-Selbstheilung erkennt auch genullte Protokolldateien nach einem Stromausfall und wird bei jedem Deploy aktualisiert.
