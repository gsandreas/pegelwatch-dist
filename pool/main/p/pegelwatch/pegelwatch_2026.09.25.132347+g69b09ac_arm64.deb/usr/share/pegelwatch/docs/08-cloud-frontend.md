# PegelWatch — Öffentliches Frontend (Cloud-Anbindung)

Ein öffentlich erreichbares Frontend auf Shared-Webhosting zeigt den Status
**aller** PegelWatch-Anlagen an einer Stelle und kann je Anlage zwei Befehle
auslösen: **Update** und **Erstelle Bericht**. Alles hinter Anmeldung, mit
Admin-Freigabe und Pi-Zuteilung je Benutzer.

Die Pis sitzen hinter NAT. Es gibt **kein VPS, kein VPN, keinen Router-Eingriff
und keinen Tunnel**. Deshalb gilt durchgehend ein einziges Prinzip:

> **Das Frontend ruft nie einen Pi. Jede Verbindung geht vom Pi ausgehend per
> HTTPS.**

Der Pi meldet seinen Status und fragt dabei „liegt etwas für mich an?”. Das
Frontend antwortet mit einer Befehlsliste. Der Pi arbeitet sie ab und liefert
die Ergebnisse mit dem nächsten Kontakt.

---

## Umsetzungsstand (Stand: 2026-07-20)

Live unter **https://pegelwatch.gatecs.de**. Frontend-Deploy: `deploy-web.ps1`
(explizites FTPS, Host `cp232.sp-server.net` — NICHT das Panel-Label
`ftp.andreasgassner.de`). Pi-Deploy: `deploy.ps1`.

**Fertig, deployt, verifiziert:**
- **Phase 1** — `internal/cloud`-Agent: ausgehende Statusmeldung (Ingest),
  Enrollment mit Admin-Freigabe, Backoff, Erreichbarkeitsanzeige auf der
  Pi-Startseite. Frontend: `enroll.php`, `ingest.php`, SQLite-Schema.
- **Phase 2** — Login/Registrierung/Logout (Sessions, CSRF, Rate-Limit; erstes
  Konto = Admin), Rechte/Zuteilung (`user_pi`, sehen/steuern), Admin-Bereich
  (`admin.php`: Konten/Anlagen freigeben/sperren/umbenennen, Zuteilung),
  pro-Nutzer-Dashboard, Pi-Detailseite (`pi.php`). Basic-Auth abgelöst.
- **Füllgrad gegen Sollwert** — je Sensor `full_level_mm` (Konfig-UI); Referenz
  in der Reihenfolge explizit → Aufbau-3-Primaersensor Pump-Start-Pegel →
  Hochwasser-Schwelle; >100 % = überfüll (Payload-Feld `fill_pct`).
- **Config-Backup** — Pi pusht geheimnisfreie `config.toml` (Hash im Ingest →
  `want_config` → `/api/config.php` → `data/pi-configs/<slug>.toml`, portabel);
  Aktualitäts-Check + Download (`config-download.php`) auf der Detailseite.

**Fertig (Code), noch nicht auf dem Pi verifiziert:**
- **Phase 3 — „Erstelle Bericht” + Kiosk-Snapshot.** Befehls-Warteschlange
  vollständig: `ingest.php` liefert offene `commands` und markiert sie `taken`;
  der Agent (`internal/cloud`) arbeitet sie ab und meldet Ergebnis + Artefakte
  per multipart an `result.php` (Prüfsumme je Datei, Dateiname serverseitig
  vergeben). Der `report`-Befehl erzeugt über den **bestehenden**
  `report.Generator` das PDF **und** einen Kiosk-Snapshot
  (`web.Server.KioskSnapshot`, `internal/web/snapshot.go`): die unveränderte
  `kiosk.html`/`kiosk2.html` plus vorangestellten Shim
  (`templates/snapshot-shim.js`), der EventSource/`fetch` durch die
  aufgezeichnete Momentaufnahme ersetzt (SSE aus `SSEHub.Retained`, `/api/config`,
  `/api/history`, `/api/aufbau2/period`). Der **erzwingende Test**
  (`snapshot_test.go`) hält die Endpunktliste (`snapshotHandledEndpoints`) mit
  den Kiosks synchron. Frontend: Button „Erstelle Bericht” + Auftrags-/Artefakt-
  liste in `pi.php`, Auslieferung über `artifact.php` (PDF-Download; Snapshot nur
  in `<iframe sandbox="allow-scripts">` **plus** `Content-Security-Policy: sandbox
  allow-scripts`). Aufräumen (`expired`, alte Artefakte) deckt `cron/prune.php`
  bereits ab.
- **Phase 4 — „Update” (Variante A + Root-Installer per systemd-path-unit).**
  Pi (`internal/cloud`): der `update`-Befehl holt `GET /api/binary.php?info`,
  vergleicht mit dem eigenen `buildTime` („bereits aktuell” → sofort `done`),
  lädt sonst `?download`, verifiziert die Prüfsumme, legt
  `pegelwatch.new` + `.sha256`-Beileger in `/var/lib/pegelwatch/update`, hinterlegt
  `cloud.update_pending` (cmd_id + erwarteter Build) in `state.db` und setzt den
  Trigger. Der **neue** Prozess meldet nach dem Neustart das tatsächliche
  Ergebnis (`finishPendingUpdate` in `Run()`) — Wahrheit statt Absicht. Neues
  `--version`-Flag (Testlauf des Root-Installers). Optionales `auto_update`
  (vergleicht bei jedem Kontakt, cmd_id 0). Root-Installer + `pegelwatch-update.path`
  /`.service` installiert `deploy.ps1` (`Install-UpdateUnits`, idempotent bei
  jedem Deploy) mit Prüfsummen-Recheck, `--version`-Testlauf und Rollback auf
  `pegelwatch.bak` bei Fehlstart (90 s). Frontend: `api/binary.php` (`?info`/
  `?download`, API-Key), `binaries`-Tabelle wird per JSON-Beileger
  (`data/binaries/current.json`) selbstheilend gefüllt (`app/binaries.php`, da
  über FTPS kein SQL läuft); Update-Knopf + Versionsvergleich in `pi.php`.
  `deploy-web.ps1` baut das arm64-Binary und lädt es samt Beileger nach
  `data/binaries/`. **Auf dem Pi noch nicht verifiziert.**
- **Phase 5 — OS-Update (apt) + Versionsanzeige.** Der Agent meldet im Ingest
  schlank `os` (OS-Name, Kernel, ausstehende apt-Updates, Reboot-Flag;
  `cmd/pegelwatch/osinfo.go`, alle 30 min ermittelt, `apt-check`/`apt-get -s`).
  `pi.php` zeigt das an und bietet — mit `may_cmd` — den Knopf **„Systemupdate
  ausführen"** (`os_update`-Befehl). Wie beim Binary-Update darf der Agent kein
  `apt`: er setzt nur `/var/lib/pegelwatch/osupdate/trigger`, die Root-Unit
  `pegelwatch-osupdate.path`/`.service` (von `deploy.ps1` mitinstalliert) führt
  `apt-get update && upgrade` aus und legt `result.json` ab; der Agent meldet das
  Ergebnis daraus beim nächsten Kontakt (`finishPendingOSUpdate`, Timeout 30 min).
  **Bewusst KEIN automatischer Reboot** (Reboot bleibt Handaktion — wegen der
  InfluxDB-Reboot-Korruption). apt prüft Paketsignaturen selbst, daher kein
  Supply-Chain-Risiko über das Frontend. **Auf dem Pi noch nicht verifiziert.**

**Angebunden:** PumpWatch (192.168.0.106, Aufbau 3, Hebewerk) meldet live.

**Offen:**
- **Neuer Pi PEGELWatch** (192.168.0.56) im Register (`deploy/devices.psd1`),
  Config vorbereitet (`deploy/PEGELWatch/`), aber **noch nicht deploybar**:
  SSH-Key noch nicht auf dem Pi autorisiert (Permission denied). Onboarding:
  `deploy.ps1 -PiHost 192.168.0.56 -ConfigDir deploy\PEGELWatch`.

**Betriebshinweise:** Zugangsdaten lokal in `deploy/.netrc` (gitignored);
Frontend-Secrets in `frontend/config.local.php` (gitignored, oberhalb des
Docroots). Pi-Deploy **ohne** `-UpdateConfig` = nur Binary (Produktiv-Config
bleibt). Netzzugriff aus der Tool-Sandbox braucht `dangerouslyDisableSandbox`.

---

## Inhalt

1. [Überblick](#überblick)
2. [Entscheidungen](#entscheidungen)
3. [Datenspeicher](#datenspeicher)
4. [Protokoll zwischen Pi und Frontend](#protokoll-zwischen-pi-und-frontend)
5. [Anmeldung der Pis (Enrollment)](#anmeldung-der-pis-enrollment)
6. [Benutzer und Rechte](#benutzer-und-rechte)
7. [Ablauf „Erstelle Bericht“ und der Kiosk-Snapshot](#ablauf-erstelle-bericht-und-der-kiosk-snapshot)
8. [Ablauf „Update“](#ablauf-update)
9. [Erreichbarkeitsanzeige auf dem Pi](#erreichbarkeitsanzeige-auf-dem-pi)
10. [Konfiguration auf dem Pi](#konfiguration-auf-dem-pi)
11. [Aufbau im Webspace und Umzug](#aufbau-im-webspace-und-umzug)
12. [Deploy-Integration](#deploy-integration)
13. [Sicherheit](#sicherheit)
14. [Umsetzung in Phasen](#umsetzung-in-phasen)

---

## Überblick

```
   Pi (SEPWatch)          Pi (PUMPWatch)         Pi (RIVERWatch)
        │                       │                       │
        │  ausgehend HTTPS, API-Key je Pi               │
        └───────────┬───────────┴───────────┬───────────┘
                    │                       │
                    ▼                       ▼
        POST /api/ingest            (Antwort: offene Befehle)
                    │
        ┌───────────┴───────────────────────────────────┐
        │  Frontend (PHP 8.3, Shared-Hosting, HTTPS)    │
        │                                               │
        │   pegelwatch.sqlite  ← genau EINE Datendatei  │
        │   config.local.php   ← Secrets, nicht im Git  │
        └───────────┬───────────────────────────────────┘
                    │  Anmeldung, Rechte, Zuteilung
                    ▼
              Browser (Nutzer / Admin)
```

Zwei getrennte Welten mit getrennter Authentifizierung:

| | Wer | Womit | Wozu |
|---|---|---|---|
| **Maschinenseite** | Pi | API-Key je Pi (Header) | Status melden, Befehle holen, Ergebnisse liefern |
| **Menschenseite** | Nutzer/Admin | Session (Login, `password_hash`) | Dashboard ansehen, Befehle auslösen, verwalten |

Beide teilen sich nur die eine SQLite-Datei. Kein Pi kann auf die
Menschenseite, kein Nutzer bekommt einen API-Key zu sehen.

---

## Entscheidungen

Die vier offenen Punkte sind entschieden — hier festgehalten, damit später
nachvollziehbar ist, **warum** es so ist:

| Punkt | Entscheidung | Grund |
|---|---|---|
| **Binary-Bezug** | **A — über das Frontend** | Kein GitHub-PAT auf den Pis. Der Pi hat mit seinem API-Key bereits ein Zugangssystem; ein zweites (GitHub) wäre ein zweites Geheimnis mit eigener Ablaufzeit. Das Binary wandert beim Umzug mit der Datendatei mit. Es wird **nicht** in den Git-Tree committet. |
| **Kiosk-Snapshot** | **Shim, `kiosk.html` bleibt byte-identisch** — abgesichert durch einen erzwingenden Test | Erfüllt „Kiosk-Ansichten bleiben unverändert“ wörtlich. Der Test schließt die einzige Schwachstelle der Variante (siehe unten). |
| **Update-Weg** | **Root-Installer per systemd path-unit** | Die Härtung der Unit bleibt vollständig erhalten, der Agent bekommt nie Root. Siehe [Ablauf „Update“](#ablauf-update). |
| **Telemetrie** | **Schlank (~400 B), Snapshot nur auf Klick** | Webspace und Datenvolumen bleiben klein; das Frontend ist eine Statusampel, Details holt man sich gezielt. |
| **Pi-Anmeldung** | **Selbstregistrierung mit Admin-Freigabe** | Ein neuer Pi meldet sich selbst an und wartet auf Freigabe — kein manuelles Key-Verteilen. |

---

## Datenspeicher

**Genau eine Datendatei**, getrennt vom Code:

```
data/pegelwatch.sqlite      ← ALLE Daten (Pis, Nutzer, Befehle, Status)
data/artifacts/             ← gelieferte Snapshots/PDFs (Dateien, in der DB indiziert)
data/binaries/              ← das arm64-Binary (Variante A)
config.local.php            ← Secrets, NICHT versioniert
```

SQLite über **PDO** (`pdo_sqlite`, bei serverprofis vorhanden). Keine MariaDB —
sie wäre nicht mit einer Datei umziehbar und ist für eine Handvoll Pis
überdimensioniert.

> **Warum liegen Artefakte als Dateien daneben und nicht in der DB?**
> Ein Kiosk-Snapshot ist ~100 KB, ein PDF ~1 MB. In SQLite würde jede Abfrage
> über eine aufgeblähte Datei laufen und die Datei selbst schlecht
> handhabbar werden. Die DB hält den Index (Name, Prüfsumme, Größe, Zeit), das
> Verzeichnis den Inhalt. Der Umzug bleibt „Ordner kopieren“.

### Schema

```sql
-- Anlagen -------------------------------------------------------------
CREATE TABLE pis (
  id            INTEGER PRIMARY KEY,
  slug          TEXT NOT NULL UNIQUE,   -- stabile Kennung, z.B. "sepwatch-01"
  name          TEXT NOT NULL,          -- Anzeigename
  hostname      TEXT,
  aufbau        INTEGER,
  api_key_hash  TEXT NOT NULL,          -- sha256(Key), NIE der Key selbst
  status        TEXT NOT NULL,          -- pending | active | disabled
  enroll_ip     TEXT,
  created_at    INTEGER NOT NULL,
  approved_at   INTEGER,
  last_seen_at  INTEGER,                -- letzter erfolgreicher Ingest
  last_status   TEXT                    -- JSON der letzten Statuszeile
);

-- Nutzer --------------------------------------------------------------
CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  pass_hash     TEXT NOT NULL,          -- password_hash(), PASSWORD_DEFAULT
  role          TEXT NOT NULL,          -- admin | user
  status        TEXT NOT NULL,          -- pending | active | disabled
  created_at    INTEGER NOT NULL,
  approved_at   INTEGER,
  last_login_at INTEGER
);

-- Zuteilung: welcher Nutzer darf welchen Pi sehen/steuern ------------
CREATE TABLE user_pi (
  user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pi_id    INTEGER NOT NULL REFERENCES pis(id)   ON DELETE CASCADE,
  may_cmd  INTEGER NOT NULL DEFAULT 0,  -- 0 = nur sehen, 1 = auch Befehle
  PRIMARY KEY (user_id, pi_id)
);

-- Befehls-Warteschlange ----------------------------------------------
CREATE TABLE commands (
  id          INTEGER PRIMARY KEY,
  pi_id       INTEGER NOT NULL REFERENCES pis(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,            -- update | report
  params      TEXT,                     -- JSON, z.B. {"hours":24}
  state       TEXT NOT NULL,            -- queued | taken | done | failed | expired
  created_by  INTEGER REFERENCES users(id),
  created_at  INTEGER NOT NULL,
  taken_at    INTEGER,
  done_at     INTEGER,
  result      TEXT,                     -- JSON-Ergebnis des Pi
  error       TEXT
);
CREATE INDEX idx_cmd_open ON commands(pi_id, state);

-- Gelieferte Artefakte (Snapshot/PDF) --------------------------------
CREATE TABLE artifacts (
  id          INTEGER PRIMARY KEY,
  pi_id       INTEGER NOT NULL REFERENCES pis(id) ON DELETE CASCADE,
  command_id  INTEGER REFERENCES commands(id) ON DELETE SET NULL,
  kind        TEXT NOT NULL,            -- kiosk_snapshot | report_pdf
  filename    TEXT NOT NULL,            -- in data/artifacts/
  sha256      TEXT NOT NULL,
  bytes       INTEGER NOT NULL,
  created_at  INTEGER NOT NULL
);

-- Verfügbares Binary (Variante A) ------------------------------------
CREATE TABLE binaries (
  id          INTEGER PRIMARY KEY,
  build_time  TEXT NOT NULL,            -- "2026-07-16 09:12:18 (b4b8010)"
  git_hash    TEXT NOT NULL,
  filename    TEXT NOT NULL,            -- in data/binaries/
  sha256      TEXT NOT NULL,
  bytes       INTEGER NOT NULL,
  uploaded_at INTEGER NOT NULL
);

-- Schlanker Statusverlauf (für "Auffälligkeiten", 7 Tage) ------------
CREATE TABLE status_log (
  id        INTEGER PRIMARY KEY,
  pi_id     INTEGER NOT NULL REFERENCES pis(id) ON DELETE CASCADE,
  at        INTEGER NOT NULL,
  payload   TEXT NOT NULL               -- dieselbe schlanke Zeile
);
CREATE INDEX idx_status_log ON status_log(pi_id, at);

-- Rate-Limiting (Login, Ingest, Enroll) ------------------------------
CREATE TABLE attempts (
  id      INTEGER PRIMARY KEY,
  bucket  TEXT NOT NULL,                -- "login:<ip>", "enroll:<ip>", ...
  at      INTEGER NOT NULL
);
CREATE INDEX idx_attempts ON attempts(bucket, at);
```

Ein Cronjob (Hoster-Funktion) räumt täglich auf: `status_log` älter als 7 Tage,
`attempts` älter als 1 Tag, `commands` im Endzustand älter als 30 Tage samt
Artefakten, und er markiert überfällige Befehle als `expired`.

> **Zum Verlauf:** `status_log` ist bewusst klein gehalten und ist **keine**
> zweite Zeitreihendatenbank. Der echte Verlauf liegt weiterhin in der
> InfluxDB auf dem Pi. Hier geht es nur darum, „seit wann offline“ und
> „wann war der Alarm zuletzt aktiv“ beantworten zu können.

---

## Protokoll zwischen Pi und Frontend

Schema-Version in jedem Payload (`v`), damit ein alter Pi und ein neues
Frontend sich nicht missverstehen. Das Frontend akzeptiert die aktuelle und die
vorherige Version, sonst `409`.

### Der Kern: ein Endpunkt

```
POST /api/ingest.php
Header: X-PW-Key: <api-key>   Content-Type: application/json
```

Der Pi meldet seinen Status **und** bekommt in derselben Antwort seine offenen
Befehle. Ein Request pro Intervall statt zwei — schont den Shared-Hoster und
halbiert die Verbindungen.

**Request** (~400 Byte):

```json
{
  "v": 1,
  "slug": "sepwatch-01",
  "ts": 1768553538,
  "build": "2026-07-16 09:12:18 (b4b8010)",
  "uptime_s": 84321,
  "cpu_c": 52.3,
  "gpu_c": 51.8,
  "aufbau": 2,
  "sensors": [
    {"id": "t1", "mm": 1240.5, "ok": true, "liters": 812.0}
  ],
  "alarms": ["t1:high"],
  "pump": {"mode": "auto", "running": false, "cycles": 143},
  "services": {"influx": true, "grafana": true, "smtp": true}
}
```

Die Felder stammen 1:1 aus dem bereits vorhandenen `report.Situation` /
`report.LiveSensor` (`internal/report/situation.go`), das `main.go` ohnehin
laufend über `rt.SetLive(...)` fortschreibt. **Es entsteht kein zweites
Datenmodell** — der Cloud-Agent liest dieselbe Momentaufnahme, die auch der
Lagebericht nutzt, und dampft sie auf die schlanke Zeile ein.

**Antwort**:

```json
{
  "ok": true,
  "server_time": 1768553539,
  "commands": [
    {"id": 42, "kind": "report", "params": {"hours": 24}},
    {"id": 43, "kind": "update"}
  ]
}
```

Leere Liste = nichts zu tun. Damit ist der „Poller“ kein eigener Mechanismus,
sondern die Antwort auf den Status-POST.

**Folge:** Ein Klick im Frontend wirkt erst beim nächsten Kontakt, also nach
höchstens `status_interval_s` (Standard 60 s). Das ist für „Update“ und
„Bericht“ angemessen — beides ist keine Echtzeit-Aktion. Die UI sagt das auch:
*„Befehl eingereiht — der Pi holt ihn sich beim nächsten Kontakt (max. 60 s).“*

### Ergebnisse liefern

```
POST /api/result.php?id=42
Header: X-PW-Key: <api-key>   Content-Type: multipart/form-data
```

| Feld | Inhalt |
|---|---|
| `meta` | JSON: `{"v":1,"state":"done","message":"…","artifacts":[{"kind":"kiosk_snapshot","sha256":"…"}]}` |
| `file[]` | die Artefakte (Snapshot-HTML, Bericht-PDF) |

Das Frontend prüft: gehört der Befehl diesem Pi? Ist er in `taken`? Stimmt die
Prüfsumme? Nur dann wird gespeichert und `state=done` gesetzt.

### Alle Endpunkte

| Endpunkt | Auth | Zweck |
|---|---|---|
| `POST /api/enroll.php` | Enrollment-Token | Neuer Pi meldet sich an, bekommt seinen Key (Status `pending`) |
| `POST /api/ingest.php` | API-Key | Status melden + offene Befehle abholen |
| `POST /api/result.php` | API-Key | Befehlsergebnis + Artefakte liefern |
| `GET /api/binary.php?info` | API-Key | Metadaten des verfügbaren Binaries |
| `GET /api/binary.php?download` | API-Key | Das Binary (Variante A) |

Alle Maschinen-Endpunkte liegen unter `/api/`, sind **ausschließlich** per
API-Key erreichbar und liefern nie HTML — bei Fehlern JSON mit passendem
Statuscode.

| Code | Bedeutung für den Pi |
|---|---|
| `204` | angenommen |
| `401` | Key unbekannt/falsch → Agent stoppt und meldet in der Pi-UI „nicht angemeldet“ |
| `403` | Pi bekannt, aber `pending`/`disabled` → Pi-UI zeigt „wartet auf Freigabe“ |
| `409` | Schema-Version zu alt → Pi-UI zeigt „Update nötig“ |
| `429` | zu häufig → Agent verdoppelt sein Intervall (Backoff bis max. 15 min) |

---

## Anmeldung der Pis (Enrollment)

Ein neuer Pi meldet sich **selbst** an und wartet auf Freigabe:

```
1. Pi startet mit [cloud].url + enroll_token (aus secrets.toml)
        │
        ▼
2. POST /api/enroll.php {enroll_token, slug, hostname, aufbau}
        │
        ▼
3. Frontend: neuer Eintrag in pis, status = "pending"
   Antwort: {"api_key": "<einmalig>"}       ← nur hier je sichtbar
        │
        ▼
4. Pi speichert den Key in secrets.toml (config.SaveSecrets)
   und meldet ab jetzt mit dem Key statt mit dem Enrollment-Token
        │
        ▼
5. Ingest liefert 403 "pending" → Pi-UI: "wartet auf Freigabe"
        │
        ▼
6. Admin klickt "Freigeben" → status = "active" → Pi ist online
```

Der Pi darf `/etc/pegelwatch` schreiben (`ReadWritePaths` in der Unit), kann
seinen Key also selbst dauerhaft ablegen — dasselbe Muster wie SMTP-Passwort
und InfluxDB-Token heute. `config.SecretsInput` bekommt dafür zwei Felder
(`cloud_enroll_token`, `cloud_api_key`).

**Absicherung des Enrollment-Endpunkts** — er ist der einzige, der ohne
Pi-Key erreichbar ist:

* Der Enrollment-Token ist ein gemeinsames Geheimnis, das **nur** beim Deploy
  auf den Pi kommt; Vergleich per `hash_equals`.
* Strenges Rate-Limit je IP (z. B. 5/Stunde) — Enrollment passiert pro Pi
  genau einmal.
* Ein neuer Pi ist immer `pending` und liefert **keine** Daten, bevor der Admin
  ihn freigibt. Ein gestohlener Enrollment-Token erzeugt also höchstens einen
  Eintrag in einer Freigabeliste, keinen Zugriff.
* Der Admin bekommt eine E-Mail („Neue Anlage möchte sich anmelden“).
* Meldet sich derselbe `slug` erneut (z. B. nach Neuinstallation), wird **kein**
  neuer Key ausgegeben; der Vorgang landet als Hinweis beim Admin, der den Pi
  bewusst zurücksetzen muss. Sonst könnte jemand mit dem Enrollment-Token den
  Key eines bestehenden Pi überschreiben.

---

## Benutzer und Rechte

```
Selbstregistrierung  →  status "pending"  →  E-Mail an Admin  →  Freigabe
                                                                    │
                                             Zuteilung: welche Pis? ┘
```

| Rolle | Darf |
|---|---|
| **Admin** | alles: alle Pis sehen und steuern, Konten freigeben/sperren, Pis freigeben/umbenennen, Zuteilungen ändern |
| **Nutzer** | nur die ihm zugeteilten Pis — sehen, und steuern nur mit `may_cmd = 1` |

**Nicht zugeteilte Pis sind unsichtbar**: sie erscheinen weder im Dashboard,
noch in Auswahllisten, noch in URLs. Der Zugriff auf `/pi.php?id=7` ohne
Zuteilung liefert `404` (nicht `403` — `403` würde die Existenz des Pi
bestätigen).

Die Rechteprüfung ist **eine** Funktion, die jede Ansicht und jeder Befehl als
erste Zeile aufruft:

```php
// app/auth.php — die einzige Stelle, die "darf ich?" beantwortet
function require_pi(int $piId, bool $needCmd = false): array {
    $u = require_login();                     // sonst → /login.php
    $pi = pi_for_user($u, $piId, $needCmd);   // Admin: alle; sonst user_pi
    if (!$pi) { http_404(); }                 // unsichtbar, nicht "verboten"
    return $pi;
}
```

Kein Handler darf selbst Rechte interpretieren. Wer einen Pi anfasst, ruft
`require_pi()` — sonst kommt er nicht an die Daten.

Der erste registrierte Account wird Admin (sonst gäbe es niemanden, der
freigibt). Jeder weitere ist `pending`.

---

## Ablauf „Erstelle Bericht“ und der Kiosk-Snapshot

Der Befehl `report` liefert **zwei** Artefakte:

1. **den Bericht** — erzeugt von der **bestehenden** Implementierung
   (`report.Generator.Generate`, `reportController.Create` in `main.go`, siehe
   `docs/07-lagebericht.md`). Der Cloud-Agent ruft dieselbe Funktion wie der
   📄-Knopf im Kiosk. Kein zweiter Berichtsweg.
2. **den Kiosk-Snapshot** — die Kiosk-Seite als selbsttragendes HTML.

### Warum der Snapshot nicht trivial ist

Die Kiosk-Seiten enthalten **keine Daten**. Sie sind leere Hüllen, die sich im
Browser live füllen:

```
kiosk.html  ──►  new EventSource('/api/sse')      → measurement, shelly, pump
                 fetch('/api/config')             → Sensornamen, Schwellwerte
                 fetch('/api/history?hours=50')   → Diagramm
```

Ein Snapshot ist deshalb: **dieselbe Hülle + aufgezeichnete Daten**.

### Die Lösung: Shim, Template unangetastet

Der Pi baut die Snapshot-Datei so zusammen:

```
snapshot.html
┌─────────────────────────────────────────┐
│ <script>                                │  ← Shim, vom Pi erzeugt
│   window.EventSource = ReplaySource;    │     ersetzt die Live-Quellen
│   window.fetch       = cannedFetch;     │     durch die Aufzeichnung
│   /* Daten: SSE-Events, config, history */
│ </script>                               │
├─────────────────────────────────────────┤
│ …kiosk.html, BYTE-IDENTISCH aus embed.FS│  ← unverändert
└─────────────────────────────────────────┘
```

Weil das Shim **vor** dem Seiten-Code läuft, benutzt `kiosk.html` unbemerkt die
Attrappen statt der echten Verbindungen. Der Seiten-Code wird nicht angefasst —
Layout, Gauge, Diagramm, Farben sind zwangsläufig identisch, weil es
**dieselbe Datei** ist. Ändert sich der Kiosk, ändert sich der Snapshot mit.

**Der ehrliche Haken** — und wie er geschlossen wird:

Das Shim muss wissen, welche Endpunkte die Seite abruft. Fügt später jemand ein
`fetch('/api/neu')` in `kiosk.html` ein, bliebe dieser Teil im Snapshot leer —
**und niemand würde es merken**, weil die lokale Ansicht ja weiter funktioniert.
Genau die stille Divergenz, die die „eine Quelle“-Vorgabe verhindern soll, käme
so durch die Hintertür zurück.

Deshalb gehört zu dieser Variante zwingend ein Test:

```go
// internal/web/snapshot_test.go
// Durchsucht kiosk.html/kiosk2.html nach fetch('…') und new EventSource('…')
// und schlaegt fehl, sobald ein Endpunkt auftaucht, den das Shim nicht kennt.
// Damit kann der Snapshot nicht still veralten: wer den Kiosk erweitert,
// bekommt sofort einen roten Test statt Monate spaeter einen leeren Snapshot.
func TestSnapshotShimKenntAlleKioskEndpunkte(t *testing.T) { … }
```

Das Projekt hat mit `internal/web/jssyntax_test.go` bereits einen Test, der die
Templates statisch prüft — der neue Test reiht sich dort ein.

### Ablauf

```
Frontend: Klick "Erstelle Bericht"  →  commands(kind=report, params={hours:24})
                                              │
Pi (nächster Ingest, ≤ 60 s)  ────────────────┘
  │
  ├─ 1. report.Generator.Generate(…)      → bericht_….pdf   (bestehender Code)
  ├─ 2. web.KioskSnapshot(ctx)            → snapshot.html
  │        ├─ Momentaufnahme aus runtimeState  (dieselbe wie im Lagebericht)
  │        ├─ /api/config  (geheimnisfrei — Tokens sind `json:"-"`)
  │        ├─ /api/history (nur Aufbau 3)
  │        └─ kiosk.html bzw. kiosk2.html je nach Aufbau, unverändert
  │
  └─ 3. POST /api/result.php?id=42  (multipart: meta + beide Dateien)
                                              │
Frontend: Artefakte ablegen, Prüfsummen prüfen, state=done
          Dashboard zeigt "Bericht vom 16.07. 09:12" + "Kiosk-Ansicht"
```

Der Snapshot wird im Frontend **nur in einem `sandbox`-iframe** angezeigt,
niemals in das Dashboard-DOM eingefügt — siehe [Sicherheit](#sicherheit).

### Wo der Code hingehört

| Was | Wohin | Warum |
|---|---|---|
| Snapshot bauen | `internal/web` (neu: `snapshot.go`) | nur dort liegt `templateFS` mit den Kiosk-Templates |
| Shim (JS) | `internal/web/templates/snapshot-shim.js` (neu, eigene Datei) | wird `kiosk.html` vorangestellt, ohne sie zu berühren |
| Cloud-Agent | `internal/cloud` (neu) | Reporter + Poller + Update; hängt von `web`/`report` ab, nicht umgekehrt |
| Verdrahtung | `cmd/pegelwatch/main.go` | wie alle anderen Adapter auch (`SetReportController`, …) |

---

## Ablauf „Update“

### Das Problem

Die systemd-Unit (`deploy.ps1`) härtet den Dienst bewusst:

```ini
User=andreas
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/pegelwatch /etc/pegelwatch
```

Damit kann der Dienst `/usr/local/bin/pegelwatch` **weder schreiben** (nicht in
`ReadWritePaths`, und ihm gehört die Datei nicht) **noch per `sudo` ersetzen**
(`NoNewPrivileges=true` macht setuid wirkungslos — `sudo` scheitert dort
grundsätzlich, nicht nur mangels Passwort).

### Die Lösung: der Dienst lädt, Root installiert

Der Agent lädt nur dorthin, wo er ohnehin schreiben darf. Ein **separater
Root-Dienst** übernimmt den Tausch. Die Härtung bleibt unangetastet, und der
Agent bekommt zu keinem Zeitpunkt Root.

```
Agent (User andreas, ungehärtet-frei nur in /var/lib/pegelwatch)
  │
  ├─ GET /api/binary.php?info      → {build_time, git_hash, sha256, bytes}
  │     └─ gleich wie main.buildTime?  → "bereits aktuell", fertig
  │
  ├─ GET /api/binary.php?download  → /var/lib/pegelwatch/update/pegelwatch.new
  ├─ sha256 prüfen                 → stimmt nicht? abbrechen, Datei löschen
  ├─ Vermerk in state.db: update_pending = {cmd_id, erwarteter build}
  └─ touch /var/lib/pegelwatch/update/pegelwatch.trigger
                    │
                    ▼
   pegelwatch-update.path (root)  ──triggert──►  pegelwatch-update.service
                                                  (root, Type=oneshot)
                                                    ├─ sha256 erneut prüfen
                                                    ├─ Testlauf: --version
                                                    ├─ Sicherung: pegelwatch.bak
                                                    ├─ install -m755 → /usr/local/bin/
                                                    ├─ Trigger + .new entfernen
                                                    └─ systemctl restart pegelwatch
                                                             │
   Neuer Prozess startet ◄────────────────────────────────────┘
     ├─ liest update_pending aus state.db
     ├─ Build stimmt?  → POST result: done  ("jetzt auf <build>")
     └─ Build stimmt nicht (Rollback)? → POST result: failed
```

**Warum der Umweg über `state.db`?** Der Prozess, der das Update auslöst,
stirbt beim Neustart — er kann sein eigenes Ergebnis nicht mehr melden. Also
hinterlegt er vor dem Neustart, was er erwartet; der **neue** Prozess meldet,
was tatsächlich läuft. Das Frontend erfährt so nicht „Update wurde angestoßen“,
sondern „Pi läuft jetzt auf Build X“ — die Wahrheit statt der Absicht.
`state.Set`/`state.Get` gibt es dafür bereits.

**Rollback:** Der Root-Installer prüft vor dem Tausch die Prüfsumme und startet
das neue Binary einmal mit `--version`. Scheitert das, oder kommt der Dienst
nach dem Neustart nicht binnen 90 s wieder hoch (`systemd is-active`), wird
`pegelwatch.bak` zurückgespielt. Ein kaputtes Binary darf keinen Pi lahmlegen,
der nur remote erreichbar ist.

**Neue Dateien** (von `deploy.ps1` mit installiert):

| Datei | Inhalt |
|---|---|
| `/etc/systemd/system/pegelwatch-update.path` | `PathExists=/var/lib/pegelwatch/update/pegelwatch.trigger` |
| `/etc/systemd/system/pegelwatch-update.service` | `Type=oneshot`, root, `ExecStart=/usr/local/sbin/pegelwatch-update` |
| `/usr/local/sbin/pegelwatch-update` | das Installskript (root, ~40 Zeilen sh) |

**Auto-Update** (optional, `[cloud].auto_update = true`): derselbe Ablauf, nur
ohne Befehl — der Agent vergleicht bei jedem Kontakt `?info` mit seinem
`buildTime` und aktualisiert bei Abweichung selbsttätig. Standard ist `false`:
ein Update soll normalerweise ein bewusster Klick sein.

### Release-Kanäle (stable / daily), Paketquelle und Änderungsprotokoll

*(Stand 2026-09-25 — ersetzt den früheren Weg „Binary auf dem Webspace“.)*

**Verteilung über eine signierte apt-Paketquelle auf GitHub.** PegelWatch ist
ein Debian-Paket (`pegelwatch`, arm64). Es enthält alles, was früher
`deploy.ps1` per SSH einrichtete: Programm, systemd-Units, Root-Helfer für
Paket- und OS-Update, polkit-Regel, Abschaltanzeige, Grafana-Dashboards,
Dokumentation, InfluxDB-Selbstheilung, Startkonfiguration. So bekommen auch
Anlagen **ohne SSH-Zugang** bei jedem Update den vollständigen Stand.

```
Deploy-PC ──deploy-fleet.ps1──► Pis im eigenen Netz (SSH, apt install ./paket.deb)
    │
    └─ gh release create build-… (privates Repo gsandreas/PEGELWatch, Paket als Anhang,
       │                          Änderungsprotokoll als Text)
       ▼
GitHub Actions (.github/workflows/publish-apt.yml, privates Repo)
    │  signiert mit APT_SIGNING_KEY, Aufbewahrung 5 daily / 3 stable
    ▼
gsandreas/pegelwatch-dist (öffentlich), Branch gh-pages → GitHub Pages
    https://gsandreas.github.io/pegelwatch-dist/   dists/{stable,daily}, pool/, releases.json,
                                                   install.sh, setup/, Schlüssel
    ▲                                   ▲
    │ apt (signaturgeprüft)             │ releases.json (Anzeige, Kanal-Stand)
Anlagen (pegelwatch-update, root) ◄── Cloud-Frontend (Update-Befehl, Freigabe stable)
```

| Kanal | Inhalt | Für |
|---|---|---|
| `daily` | das zuletzt veröffentlichte Paket — jeder Deploy | Test-/Pilotanlagen |
| `stable` (Standard) | die zuletzt in **Releases** freigegebene Version | Produktivanlagen |

**Ablauf:**

1. **Deploy** (`deploy-fleet.ps1`) baut Binary und Paket einmal
   (`packaging/build-deb.ps1`, nfpm), installiert es per SSH auf den Pis im
   eigenen Netz und legt — nur wenn dort alles geklappt hat — ein Release im
   privaten Repo an. Der Workflow stellt das Paket als **daily** in die
   Paketquelle (1–2 min). `-SkipPublish` unterdrückt das (reiner LAN-Test).
2. Der Admin wählt in **Releases** eine Version und gibt sie als **stable**
   frei. Das startet den Workflow erneut (`action=promote`), der die Indizes
   neu signiert. Eine ältere Version freizugeben ist ein **Rollback**.
3. **Auto-Update** installiert nur **neuere** Stände (Vergleich über den
   Zeitstempel im Build-Label). Update-Befehle (einzeln auf der Anlagenseite
   oder gesammelt in Releases) installieren jede Version — auch einen
   Rollback. Installiert wird erst, wenn die Pumpe steht (Update-Sperre im
   Agenten, bis zu 2 h Wartezeit).

**Auf der Anlage:** Der Agent fragt `GET /api/binary.php?info&channel=…`,
bekommt Paketversion, Build-Label und Änderungsprotokoll und schreibt nur
`version=<Paketversion>` in den Trigger. Der Root-Helfer
`/usr/sbin/pegelwatch-update` aktualisiert ausschließlich die
PegelWatch-Quelle (`/etc/apt/sources.list.d/pegelwatch.list`), installiert die
Version per apt (Signaturprüfung durch apt), setzt `apt-mark hold` und prüft,
ob der Dienst binnen 90 s läuft — sonst Rollback auf die vorherige Version.
Sein Ergebnis steht in `/var/lib/pegelwatch/update/result.json`; ein
Fehlschlag ohne Neustart meldet der laufende Agent ans Frontend. `apt-mark
hold` sorgt dafür, dass der OS-Update-Knopf (allgemeines `apt upgrade`)
PegelWatch nicht anfasst.

**Signatur:** Schlüssel `811C 0B63 D3FB FEDA 059C 008F 5CFB FAA9 8605 8508`
(ed25519, gültig bis 2031). Der private Teil liegt nur als Actions-Secret
`APT_SIGNING_KEY` im privaten Repo und als Sicherung unter
`%LOCALAPPDATA%\PegelWatch\signing` auf dem Deploy-PC. Das Paket bringt den
öffentlichen Schlüssel mit (`/usr/share/keyrings/pegelwatch-archive-keyring.gpg`),
`install.sh` prüft zusätzlich den Fingerprint. Veröffentlichen darf der
Workflow nur über `DIST_DEPLOY_KEY` (SSH-Deploy-Key mit Schreibrecht allein
auf `pegelwatch-dist`).

**Freigabe aus dem Frontend:** `config.local.php` braucht
`github_dispatch_token` — ein fein granulierter GitHub-Token nur für
`gsandreas/PEGELWatch` mit „Actions: Read and write“. Er kann ausschließlich
vorhandene, signierte Pakete freigeben.

**Änderungsprotokoll:** `CHANGELOG.md` im Repo. Neue Einträge stehen unter
`## Unveröffentlicht`; der Deploy macht daraus den Abschnitt
`## <Build-Zeitpunkt>` (`deploy/changelog.ps1`). Der Text steht im Commit, im
Binary (`go:embed`, Anzeige in der Konfigurationsseite auch offline), im
GitHub-Release und damit in `releases.json` — Releases-Seite und Anlagenseite
zeigen „Änderungen gegenüber dem installierten Stand“.

**Dienstbenutzer:** Neue Anlagen laufen unter dem Benutzer, der
`install.sh` aufruft (nötig für den Kiosk in der Desktop-Sitzung), sonst als
Systembenutzer `pegelwatch`. Bestandsanlagen behalten ihren Benutzer
(`/etc/systemd/system/pegelwatch.service.d/10-user.conf`).

---|---|---|
| `daily` | das zuletzt hochgeladene Binary — jeder Deploy landet sofort hier | Test-/Pilotanlagen |
| `stable` (Standard) | das Binary, das ein Admin in **Releases** (`releases.php`) freigegeben hat | Produktivanlagen |

**Ablauf:**

1. **Deploy** (`deploy-fleet.ps1` / `deploy.ps1`) wirkt wie bisher direkt per
   SSH auf die lokalen Pis und lädt das Binary über `deploy-web.ps1` auf den
   Webspace. Dort ist es zunächst **daily**.
2. Der Admin wählt in **Releases** per Radio-Button ein Release und gibt es als
   **stable** frei. Ein älteres Release zu wählen ist ein **Rollback** — die
   Anlagen installieren es (der Agent installiert jeden *anderen* Build, nicht
   nur neuere).
3. Anlagen mit **Auto-Update** holen den Stand ihres Kanals beim nächsten
   Kontakt selbst. Die übrigen bekommen ihn per Update-Befehl — einzeln auf der
   Anlagenseite oder gesammelt in **Releases** („Update an N Anlage(n) im
   Kanal … senden“).

**Änderungsprotokoll:** `CHANGELOG.md` im Repo. Neue Einträge stehen unter
`## Unveröffentlicht` (eine Zeile je Änderung, für Anwender formuliert). Der
Deploy macht daraus VOR Commit und Build den Abschnitt `## <Build-Zeitpunkt>`
(Hilfsfunktionen in `deploy/changelog.ps1`); fehlen Einträge, fragt er
interaktiv nach oder nimmt `-Changelog "…"`. Der Text landet
- im **Commit** (Nachrichtentext),
- im **Binary** (`go:embed`, Paket `pegelwatch` im Repo-Wurzelverzeichnis) —
  die Konfigurationsseite jeder Anlage zeigt ihn auch offline,
- im **JSON-Beileger** des Binaries (`data/binaries/<binary>.json`) und damit
  in **Releases** und auf der Anlagenseite („Änderungen gegenüber dem
  installierten Stand“ — alle Releases dazwischen zusammengefasst).

**Protokoll:** `ingest.php` antwortet zusätzlich mit `release`
(`channel`, `build_time`, `sha256`) für den gemeldeten Kanal der Anlage. Weicht
der Build vom gemerkten ab, holt der Agent `GET
/api/binary.php?info&channel=…&installed=<eigener Build>` (mit
Änderungsprotokoll) und zeigt es in der Konfigurationsseite (`GET
/api/release`). Der Download läuft über `?download&channel=…&sha256=…` —
genau das Binary, dessen Metadaten geprüft wurden. Ohne `channel` gilt
`stable` (Anlagen mit älterer Software).

**Beileger je Binary:** Früher überschrieb jeder Deploy `current.json`; zwei
Deploys ohne zwischenzeitlichen Import ließen ein Release verschwinden. Jetzt
hat jedes Binary einen eindeutigen Namen (`pegelwatch-arm64-<Zeitstempel>-<hash>`)
und einen eigenen Beileger, der **nach** dem Binary hochgeladen wird.
`stable` wird **nie automatisch** belegt — ausschließlich der Admin gibt frei.
**Auto-Update installiert nur neuere Builds** (Vergleich über den Zeitstempel
im Build-Label); ein Rollback per älterem stable-Release erreicht Anlagen mit
Auto-Update nur über einen ausdrücklichen Update-Befehl. Hintergrund
(Vorfall 25.09.2026): Eine automatische Erstbelegung von stable griff, während
der Flotten-Deploy die Pis schon aktualisiert, das neue Binary aber noch nicht
hochgeladen hatte — PUMPWatch fiel per Auto-Update auf den Vortagesstand
zurück.

---

## Erreichbarkeitsanzeige auf dem Pi

Der Agent merkt sich den letzten erfolgreichen Kontakt. Die Pi-eigene UI zeigt
ihn an:

```
Frontend: ● erreichbar (letzter Kontakt vor 12 s)
Frontend: ● nicht erreichbar (letzter Kontakt vor 14 min)
Frontend: ● wartet auf Freigabe durch den Admin
Frontend: ○ nicht konfiguriert
```

| Zustand | Bedingung |
|---|---|
| `disabled` | `[cloud].enabled = false` |
| `enrolling` | noch kein API-Key |
| `pending` | Ingest liefert `403` |
| `ok` | letzter Ingest erfolgreich und jünger als 3 × Intervall |
| `stale` | letzter Ingest älter als 3 × Intervall |
| `error` | letzter Versuch scheiterte (mit Fehlertext) |

Umgesetzt wie alle optionalen Bausteine im `web`-Paket: ein Interface
(`CloudStatusProvider`), per `SetCloudStatus(...)` registriert, `nil` =
Anzeige entfällt. Neuer Endpunkt `GET /api/cloud/status`, eingebunden in
`index.html` und `config.html`.

> Die **Kiosk-Seiten bekommen diese Anzeige nicht** — sie sind unverändert zu
> lassen, und der Kiosk ist die Betriebsansicht, nicht die Wartungsansicht.

---

## Konfiguration auf dem Pi

`config.toml` (portabel, geheimnisfrei):

```toml
[cloud]
enabled           = true
url               = "https://pegel.example.de"
slug              = "sepwatch-01"   # leer = Hostname
status_interval_s = 60              # Status melden + Befehle holen
auto_update       = false
channel           = "stable"        # Release-Kanal: stable | daily
```

`secrets.toml` (nie im Git, `chmod 600`):

```toml
[cloud]
enroll_token = "…"   # nur für die Erstanmeldung nötig
api_key      = ""    # wird nach dem Enrollment automatisch eingetragen
```

Damit folgt die Cloud-Anbindung exakt dem bestehenden Muster (SMTP-Passwort,
InfluxDB-Tokens). `config.toml.example` und `secrets.toml.example` bekommen die
Abschnitte, `config.SecretsInput` die zwei Felder.

**Kein aktivierter `[cloud]`-Abschnitt = alles bleibt wie heute.** Der Agent
startet dann nicht, und keine Anlage telefoniert nach außen, ohne dass es
jemand eingeschaltet hat. Wie bei InfluxDB/Shelly gilt: eine unvollständige
Cloud-Konfiguration ist **kein** fataler Fehler — der Agent bleibt aus, die
Anlage läuft und misst weiter.

---

## Aufbau im Webspace und Umzug

```
<subdomain-docroot>/          ← nur das ist öffentlich
    index.php                 Dashboard
    login.php  register.php  logout.php
    pi.php                    Detailansicht + Buttons
    admin.php                 Freigaben, Zuteilung
    artifact.php              liefert Snapshot/PDF (nach Rechteprüfung!)
    api/
        enroll.php  ingest.php  result.php  binary.php
    assets/

<oberhalb des docroot>/
    app/                      Logik: db.php, auth.php, csrf.php, ratelimit.php, mail.php
    data/
        pegelwatch.sqlite     ← DIE Datendatei
        artifacts/
        binaries/
    config.local.php          ← Secrets (Enrollment-Token, Mail, Pfade)
    cron/prune.php
```

Datei und Code sind getrennt: `data/` enthält **nur** Daten, kein PHP.

### Hosting-Befund serverprofis (per Sonde bestätigt 2026-07-18)

Auf dem Zielsystem verifiziert — **Variante A umgesetzt**: der Docroot wurde in
einen `html/`-Unterordner verlegt, dadurch ist die FTP-Jail-Wurzel selbst
„oberhalb des Docroots" und der FTP-User bleibt eng auf Pegelwatch gejailt.

| | Wert |
|---|---|
| Öffentliche URL | `https://pegelwatch.gatecs.de` |
| FTPS-Host (Deploy) | `cp232.sp-server.net`, Port 21, explizites FTPS (voll zertifikatsgeprüft — Cert lautet auf `cp232.sp-server.net`, **nicht** auf das Panel-Label `ftp.andreasgassner.de`, das gar nicht auflöst) |
| Docroot | `/home/andrea11/webs/de.gatecs.pegelwatch/html` |
| Privat (oberhalb Docroot) | `/home/andrea11/webs/de.gatecs.pegelwatch/` = FTP-Jail-Wurzel — von PHP les-/schreibbar, `open_basedir` nicht gesetzt, von außen **404** (bestätigt) |
| PHP | 8.3.31 (LiteSpeed); `pdo_sqlite`, `openssl`, `mbstring`, `session` vorhanden |

Konkrete Aufteilung:

```
/home/andrea11/webs/de.gatecs.pegelwatch/   ← FTP-Jail = PRIVAT (oberhalb Docroot)
├── app/                 PHP-Logik
├── data/                pegelwatch.sqlite, artifacts/, binaries/
├── config.local.php     Secrets
├── cron/                prune.php
└── html/                ← Docroot (öffentlich): index.php, api/, assets/, artifact.php
```

Der FTP-Deploy-User bleibt auf `/home/andrea11/webs/de.gatecs.pegelwatch` gejailt
und erreicht damit **nur** Pegelwatch (keine anderen Seiten unter `webs/`), aber
sowohl die private Ebene (Jail-Wurzel) als auch den Docroot (`html/`). Eine
`webs/`-Freigabe ist dadurch **nicht** nötig. Zugangsdaten liegen lokal in
`deploy/.netrc` (gitignored), niemals im Repo.

> **Falls der Hoster kein Verzeichnis oberhalb des Docroots erlaubt:** `app/`,
> `data/` und `config.local.php` wandern unter den Docroot, aber jeweils mit
> `.htaccess` (`Require all denied`) und zusätzlich zufälligem Verzeichnisnamen.
> Das ist die schlechtere Variante — die Auslieferung der SQLite-Datei hinge
> dann an einer korrekt greifenden `.htaccess`. Beim Einrichten wird geprüft,
> welche Variante der Tarif hergibt; **oberhalb des Docroots ist die erste
> Wahl**.

### Umzug

```
1. PHP-Dateien kopieren       (public/ + app/ + cron/)
2. data/ kopieren             (die eine .sqlite + artifacts/ + binaries/)
3. config.local.php kopieren  (Pfade prüfen)
4. [cloud].url auf den Pis umstellen  → fertig
```

Keine Datenbank-Migration, kein Dienst-Umzug, kein Export/Import. Läuft auf
jedem Hoster mit PHP ≥ 8.1 und `pdo_sqlite`. Sogar Schritt 4 entfällt, wenn die
Subdomain mitgenommen wird.

---

## Deploy-Integration

Ein **eigenes** Skript, im Stil von `deploy.ps1` (PowerShell 7, `Write-Step` /
`Write-Ok` / `Write-Warn` / `Write-Fail`, nicht-fatale Nebenschritte, deutsche
Kommentare):

```powershell
.\deploy-web.ps1 -WebHost sftp.serverprofis.net -WebUser <user>
```

| Schritt | Verhalten |
|---|---|
| Voraussetzungen (`ssh`, `sftp`/`rsync`) | fatal |
| PHP-Dateien übertragen | fatal |
| Schema anlegen/migrieren (`cron/prune.php --migrate`) | fatal |
| **Binary hochladen** (Variante A) + `binaries`-Eintrag | nicht-fatal → `Write-Warn` |
| Rechte setzen (`data/` 0700, `config.local.php` 0600) | nicht-fatal |
| Erreichbarkeit prüfen (`GET /api/binary.php?info`) | nicht-fatal |

`deploy.ps1` bleibt der Weg auf den Pi und bekommt nur zwei kleine Ergänzungen:
die Update-Units + das Installskript, und den `[cloud]`-Abschnitt beim
`-UpdateConfig`-Lauf.

Das Binary wird **nicht** ins Git committet (`.gitignore` deckt `/pegelwatch`
bereits ab) — es geht per SFTP in den Webspace und liegt dort in `data/binaries/`.

---

## Sicherheit

| Thema | Umsetzung |
|---|---|
| **Transport** | Ausschließlich HTTPS (Let's Encrypt). `http://` in `[cloud].url` wird vom Agent **abgelehnt** — sonst wandert der API-Key im Klartext. HSTS-Header. |
| **Pi-Auth** | API-Key je Pi (32 Byte aus `random_bytes`, Base64url), im Header `X-PW-Key`. Gespeichert wird nur `sha256(Key)`. |
| **Warum kein `password_hash` für Keys?** | `password_hash` schützt *raterbare* Geheimnisse. Ein 256-Bit-Zufallskey ist nicht raterbar; ein bcrypt-Vergleich bei jedem Ingest wäre nur teuer. Vergleich per `hash_equals` gegen `sha256`. |
| **Nutzer-Passwörter** | `password_hash(PASSWORD_DEFAULT)`, Prüfung mit `password_verify` + `password_needs_rehash`. |
| **Sessions** | `httponly`, `secure`, `samesite=Lax`, `session_regenerate_id(true)` beim Login. |
| **CSRF** | Token je Session, Pflichtfeld in **jedem** POST der Menschenseite, `hash_equals`. Die Maschinen-Endpunkte sind ausgenommen (kein Cookie, kein Browser). |
| **Rate-Limiting** | Login 5/15 min je IP+Konto; Enroll 5/h je IP; Ingest 120/h je Key (Backoff-Signal `429`). Tabelle `attempts`, vom Cron geräumt. |
| **Rechte** | Serverseitig bei **jeder** Ansicht und **jedem** Befehl über `require_pi()`. Nicht zugeteilte Pis → `404`. Auch `artifact.php` prüft — ein Bericht ist ein Betriebsdokument. |
| **Snapshot-Anzeige** | Der Snapshot ist **fremdes HTML vom Pi**. Auslieferung nur über `artifact.php` mit `Content-Security-Policy`, `X-Content-Type-Options: nosniff`, `Content-Disposition` und Anzeige ausschließlich in `<iframe sandbox="allow-scripts">` **ohne** `allow-same-origin`. Damit kommt Snapshot-JS nie an die Session. Niemals ins Dashboard-DOM einfügen. |
| **Uploads** | Größe begrenzt (Snapshot 2 MB, PDF 20 MB), Dateiname **serverseitig** vergeben (nie aus dem Request), Prüfsumme verifiziert, Ablage außerhalb des Docroots. |
| **SQL** | Ausschließlich Prepared Statements (PDO, `ATTR_EMULATE_PREPARES = false`). |
| **Secrets** | `config.local.php` außerhalb des Docroots, `0600`, nicht versioniert. Auf dem Pi: `secrets.toml`, wie gehabt. |
| **Fehlermeldungen** | `display_errors = off`, Log-Datei außerhalb des Docroots. Nach außen nie Pfade, SQL oder Stacktraces. |
| **Root-Installer** | Prüft Prüfsumme **selbst** noch einmal (traut dem Agent nicht), Testlauf vor dem Tausch, Rollback bei Fehlstart. |

**Was ein gestohlener Pi-API-Key erlaubt:** falsche Statuszeilen für **einen**
Pi zu melden und dessen Befehle abzuholen — kein Zugriff auf andere Pis, keine
Nutzerdaten, kein Login. Der Admin kann den Pi jederzeit auf `disabled` setzen;
der Key ist dann sofort wertlos.

**Was das Frontend nicht kann:** einen Pi erreichen. Es gibt keinen eingehenden
Port, keinen Tunnel, keine Fernsteuerung. Selbst ein vollständig übernommenes
Frontend kann einem Pi nur *anbieten*, ein Binary zu laden — und das prüft der
Pi gegen die Prüfsumme, und der Root-Installer prüft sie erneut.

> **Die verbleibende Vertrauensstellung, klar benannt:** Wer das Frontend
> übernimmt, kann ein manipuliertes Binary hinterlegen, das die Pis bei einem
> Update ziehen. Die Prüfsummen schützen gegen *Transportfehler*, nicht gegen
> einen kompromittierten Absender — sie stammen ja von derselben Quelle. Das
> ist der Preis von Variante A, und Variante B (GitHub-Release) hätte
> dieselbe Eigenschaft, nur mit GitHub als Absender. Wirksam dagegen wäre nur
> eine Signatur mit einem Schlüssel, der **nicht** im Webspace liegt
> (z. B. Signieren beim Build, öffentlicher Schlüssel auf den Pis). Das ist
> für diese Anlage bewusst **nicht** vorgesehen — bei Bedarf nachrüstbar, ohne
> das Protokoll zu ändern: nur ein Feld `signature` mehr in `?info`.

---

## Umsetzung in Phasen

Jede Phase ist **eigenständig lauffähig** und liefert für sich genommen Nutzen.

### Phase 1 — Status sehen (read-only)

* **Pi:** `internal/cloud` mit Reporter (Status-POST, Backoff, `[cloud]`-Konfig),
  Enrollment, Erreichbarkeitsanzeige in der Pi-UI.
* **Frontend:** `enroll.php`, `ingest.php`, Dashboard **ohne** Login (nur
  vorübergehend, per Basic-Auth des Hosters geschützt), SQLite-Schema.
* **Ergebnis:** Alle Pis melden sich, das Dashboard zeigt online/offline, Pegel,
  Temperatur, Build-Stand. Der Pi zeigt, ob das Frontend erreichbar ist.

### Phase 2 — Anmeldung und Rechte

* Registrierung, Login, Sessions, CSRF, Rate-Limiting.
* Admin-Bereich: Konten freigeben, Pis freigeben, Zuteilung.
* Registrierungs-Mail an den Admin.
* Basic-Auth aus Phase 1 fällt weg.
* **Ergebnis:** Mehrbenutzerbetrieb; jeder sieht nur seine Pis.

### Phase 3 — Bericht + Kiosk-Snapshot

* Befehls-Warteschlange (`commands`, Antwort im Ingest, `result.php`).
* Pi: Befehlsausführung, `report`-Befehl über den **bestehenden**
  `report.Generator`.
* `web.KioskSnapshot` + Shim + **der erzwingende Test**.
* Frontend: Button „Erstelle Bericht“, Artefakt-Anzeige im Sandbox-iframe.
* **Ergebnis:** Bericht und Kiosk-Ansicht jeder Anlage aus der Ferne abrufbar.

### Phase 4 — Update

* `binaries`-Tabelle, `binary.php`, `deploy-web.ps1`.
* Root-Installer + systemd-Units, von `deploy.ps1` installiert.
* Pi: `update`-Befehl, `update_pending` in `state.db`, Ergebnis nach Neustart.
* Optionales Auto-Update.
* **Ergebnis:** Jeder Pi ist per Knopfdruck aus dem Frontend aktualisierbar.

---

## Was bewusst NICHT gebaut wird

| Nicht gebaut | Warum |
|---|---|
| Zweite Kiosk-Implementierung fürs Frontend | Harte Vorgabe. Der Snapshot benutzt `kiosk.html` selbst. |
| Live-Ansicht / Reverse-Proxy / Tunnel | NAT, kein Router-Eingriff, kein VPS. Der Snapshot ist die Antwort auf „ich will sehen, was der Kiosk zeigt“. |
| MariaDB | Der Umzug soll „Dateien kopieren“ bleiben. |
| Zeitreihen im Frontend | Dafür gibt es die InfluxDB auf dem Pi. `status_log` ist nur für „seit wann offline“. |
| Fernkonfiguration der Anlagen | Nicht beauftragt. Die Konfigurations-UI bleibt lokal — und damit bleibt der Schaden eines übernommenen Frontends begrenzt. |
| Binary im Git-Tree | Ausdrücklich ausgeschlossen. |
