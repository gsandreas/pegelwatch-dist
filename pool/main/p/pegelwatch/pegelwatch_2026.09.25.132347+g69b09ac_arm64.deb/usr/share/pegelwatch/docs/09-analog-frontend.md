# PegelWatch — Analog-Front-End (Sensorplatine)

Erklärung von **Schaltung und Layout** der Sensor-Vorstufe
`PegelV2Evo_AnalogFrontEnd_V4` (Eagle 7.7, `.sch` + `.brd`).

Diese Seite beschreibt, **wie die Platine funktioniert**. Die reine
Pin-/Klemmenbelegung für den Anschluss steht in
[docs/04-verdrahtung.md](04-verdrahtung.md); dort ist auch die
ratiometrische Formel im Kontext des Codes dokumentiert.

---

## Was die Baugruppe macht

Das Analog-Front-End (AFE) ist die Vorstufe zwischen bis zu **4 Drucksensoren**
und dem digitalen Teil. Signalfluss in einem Satz:

```
Drucksensor → RC-Tiefpass → Impedanzwandler (OPV) → ESD-Schutz → ADS1115 (16 Bit) → I²C
```

Die Platine liefert außerdem eine **stabilisierte, rauscharme 5-V-Referenz**,
gegen die sowohl die Sensoren versorgt als auch (über einen mitgemessenen
Referenzkanal) ratiometrisch kompensiert werden.

**Eckdaten Platine (`.brd`):** zweilagig, ca. **90 × 76 mm**, beidseitig
bestückt (86 Bauteile, davon 37 auf der Unterseite, SMD 1206/0805/1210).
Kupferflächen: `+5V` und `5V_REG` als Fläche oben, `AGND` und `5V_FILTER`
als Fläche unten — kurze, niederohmige Versorgung und eine ruhige analoge
Massefläche direkt unter der Sensorik.

---

## Bestückungsvarianten und „DNP"

Die Platine kennt **zwei Bestückungsvarianten** (Eagle-`variantdef`):
**`Raspberry`** und **`ESP32`** — je nachdem, ob die Digitalisierung on-board
über den ADS1115 (→ Raspberry Pi via I²C) oder extern (z. B. durch den ADC
eines ESP32) erfolgt.

Mehrere Bauteile tragen im Wert den Zusatz **`(DNP)` = *Do Not Place***. Das ist
eine Anweisung an den Leiterplattenfertiger, diese Teile **nicht automatisch zu
bestücken**; sie werden später **nach Bedarf von Hand** eingelötet. Betroffen
sind (im vorliegenden Stand):

| Ref | Bauteil | Warum DNP / von Hand |
|-----|---------|----------------------|
| **REF11** | ADS1115-Modul | ist ein fertiges **Modul, das gesteckt** wird (kein SMD-Automatikteil) |
| **IC1–IC4** | MPXV5050DP | **große, bedrahtete** Drucksensoren, **von Hand** gelötet; ein Kanal, der als **Referenzkanal** dient, bekommt gar keinen Sensor |
| **U1** | P82B715P (I²C-Bustreiber) | **gesockelt** (kann durchbrennen → tauschbar); Sockel wird von Hand eingelötet |
| **J5** | Pin-Header (SSQ-110) | Steckverbinder, **von Hand** bestückt |
| **R1–R8** | R0805 | optionale **Spannungsteiler** (siehe unten), nur bei Bedarf bestückt |

> Merksatz: DNP heißt **nicht** „gehört nicht dazu", sondern „wird bewusst erst
> beim Aufbau der konkreten Variante/Bestückung gesetzt".

---

## 1. Stromversorgung & Präzisionsreferenz

```
+5V (Leiterplattenversorgung)
  └─ L1 (Sumida CDRH127) + FB1 (Ferritperle) + C16/C17/C20 (3× 1000 µF)  → 5V_FILTER
       └─ U2, U3 (2× LT1461, 5-V-Referenz, ~SHDN = aktiv)                → 5V_REG
```

- **L1 + FB1 + die drei 1000-µF-Elkos** bilden ein LC-/Pi-Filter und säubern
  die 5-V-Versorgung, die von außen (Leiterplattenversorgung) kommt.
- **U2 und U3 (LT1461CIS8-5)** sind **Spannungsreferenzen**: sie **stabilisieren
  die 5 V** der Versorgung zu einer präzisen `5V_REG`. Zwei Stück **parallel**
  (beide Ausgänge liegen auf demselben Netz), um genug Strom für 4 Sensoren +
  ADC + Operationsverstärker zu liefern.
- **`5V_REG` versorgt alles Analoge**: die Sensor-`VS`-Pins (IC1–IC4), das
  ADS1115-`VDD` und den OPV. Weil die MPXV5050DP **ratiometrisch** arbeiten
  (ihr Ausgang skaliert mit ihrer Versorgung), macht die stabile Referenz die
  Messung driftarm — und ein Kanal misst `5V_REG` **mit**, sodass die Software
  Restschwankungen ratiometrisch herausrechnet.

---

## 2. Signalaufbereitung je Kanal (4× identisch)

Am Beispiel Kanal 1 (Sensor IC1):

1. **MPXV5050DP** (IC1–IC4): differenziell, 0–50 kPa, ratiometrisch. Ausgang
   ca. **0,20 V (0 kPa) … 4,52 V (50 kPa)**. 50 kPa entsprechen **~5,097 m
   Wassersäule** — die physikalische Obergrenze je Sensor.
2. **RC-Tiefpass**: Serienwiderstand **R9–R12 = 750 Ω** + Kondensator gegen AGND
   **C9–C12 = 0,47 µF**. Grenzfrequenz:

   ```
   f_c = 1 / (2π · R · C) = 1 / (2π · 750 Ω · 0,47 µF) ≈ 451 Hz
   ```

   Dieser Tiefpass filtert **sowohl die Sensorsignale als auch die
   AD-Referenzspannung** (der Referenzkanal ist genauso beschaltet).
3. **Impedanzwandler**: ein **LMV324 (IC7)**, ein **Quad-Operationsverstärker**,
   je Kanal als **Spannungsfolger** (Verstärkung 1, `−IN` mit `OUT` verbunden).
   Er entkoppelt Sensor/Filter vom ADC: hochohmiger Eingang belastet die
   Sensoren praktisch nicht, niederohmiger Ausgang treibt den ADS1115. Damit
   ist der **Fan-Out der Sensoren auf ein Minimum** begrenzt.
4. → **ADS1115**-Analogeingang A0…A3.

### Kanal-→-Stecker-Zuordnung

| ADS1115 | OPV (LMV324) | Filter-Netz | Sensor | Klemme (Phoenix) |
|---------|--------------|-------------|--------|------------------|
| A0 | OPV1 | CH1_OUT | IC1 | **J4** (Wert „CH1") — typischer **Referenzkanal** |
| A1 | OPV2 | CH2_OUT | IC2 | **J3** („CH2") |
| A2 | OPV3 | CH3_OUT | IC3 | **J1** („CH3") |
| A3 | OPV4 | CH4_OUT | IC4 | **J2** („CH4") |

Das entspricht der Software-Konvention **„Kanal 0 = Referenz, Kanal 1 = erster
Drucksensor"** (siehe [docs/04-verdrahtung.md](04-verdrahtung.md)).

---

## 3. Referenzkanal und optionale Spannungsteiler

Jeder Kanal lässt sich per Lötbrücke (SJ1–SJ9) so verdrahten, dass statt eines
Sensors die **Versorgungs-/Referenzspannung** auf den ADC gelegt wird. In der
Standardnutzung ist das **Kanal 1 / J4 / A0**: er misst `5V_REG` als
ratiometrische Referenz (dort wird dann kein MPXV5050DP bestückt).

**R1–R8 als Spannungsteiler (Hardware-Option, DNP):** Die Widerstände bilden in
Zweiergruppen (**R7+R8, R5+R6, R3+R4, R1+R2**) je einen **Spannungsteiler**.
Zweck: Ist ein Kanal ein Referenzkanal **und** liegt die zu messende Spannung
über dem AD-Eingangsbereich (Gefahr der **Vollaussteuerung**/Übersteuerung),
kann die Eingangsspannung mit dem Teiler heruntergeteilt werden.

> **Wichtig:** Das ist **nur eine Hardware-Bestückoption**. In der Software ist
> ein solcher Teiler-Faktor **derzeit nicht vorgesehen** — die ratiometrische
> Rechnung geht von einem **ungeteilten** Referenzkanal aus. Wer den Teiler
> bestückt, muss den Faktor also anderweitig berücksichtigen. Im
> Standardaufbau bleiben R1–R8 **unbestückt** (DNP), der Referenzkanal misst
> `5V_REG` direkt.

---

## 4. ADS1115, Adressierung und I²C

- **ADS1115** (REF11): 4-Kanal-16-Bit-ADC, I²C. Der PGA ist so gewählt, dass
  der 0–5-V-Bereich sicher abgedeckt ist (siehe Kalibriermathematik in der
  Projektnotiz/`internal/adc`).
- **Adresse per Lötbrücken SJ18 + SJ20:** damit wird die I²C-Adresse des
  AD-Wandlermoduls eingestellt (**0x48–0x4B**), sodass mehrere Boards in einem
  Stapel unterscheidbar sind.
- **P82B715P (U1):** **I²C-Bustreiber/-Extender** für längere Kabelwege zum Pi.
  Die gepufferten Leitungen treiben zugleich die **Aktivitäts-LEDs** — U1
  **zeigt so aktive Kommunikation auf dem I²C-Bus an**. U1 ist **gesockelt**
  (kann bei Fehlanschluss durchbrennen und ist dann einzeln tauschbar).
- **J5:** Steck-Header als Schnittstelle zum Pi/ESP32 (SDA, SCL, +5 V, Massen,
  sowie die vier ALERT-Leitungen).
- **ESD-Schutz IC5/IC6 (DZ23C20):** Doppel-Z-Dioden an den ADC-Eingangspaaren
  gegen Überspannung/ESD (IC5 = A0/A1, IC6 = A2/A3).

---

## 5. Trennung analog/digital

`AGND` (analoge Masse) und `GND` (digitale Masse) sind getrennt geführt; die
`AGND`-Fläche liegt auf der Unterseite direkt unter der Sensorik. Das hält
digitales Schaltrauschen von den empfindlichen mV-Sensorsignalen fern.

---

## Änderungen gegenüber V3

| | V3 | **V4** |
|---|---|---|
| ESD-Dioden IC5/IC6 | DZ23C3V0 (3 V) | **DZ23C20** (20 V) |
| ADS1115-Adresse | SJ19 | **SJ18 + SJ20** |
| Bestückungsvarianten | — | **Raspberry / ESP32** |

Funktional gleich geblieben: LT1461-Referenz, MPXV5050DP, LMV324-Impedanzwandler,
750 Ω/0,47 µF-Filter, P82B715P-Bustreiber, Kanalzuordnung.

---

## Quellen

- `PegelV2Evo_AnalogFrontEnd_V4.sch` / `.brd` (Eagle 7.7) im Repo-Wurzelverzeichnis.
- Anschluss/Pinbelegung im Systemkontext: [docs/04-verdrahtung.md](04-verdrahtung.md).
