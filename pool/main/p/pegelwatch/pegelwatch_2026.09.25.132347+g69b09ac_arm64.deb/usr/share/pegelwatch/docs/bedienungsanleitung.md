# Bedienungsanleitung — PEGELWatch / SEPWatch / PUMPWatch

**Wasserstands-Messung und Pumpensteuerung auf dem Raspberry Pi**

Diese Anleitung führt Sie Schritt für Schritt von „Ich habe nur den Quellcode
aus dem Internet" bis „Meine Anlage läuft, ich kann sie ablesen, bedienen und
warten". Sie brauchen dafür **keine** Elektronik- oder Programmierkenntnisse.
Sie sollten einen Windows-PC bedienen, Kabel nach Bild stecken und Text im
Terminal per Kopieren/Einfügen ausführen können. Mehr nicht.

> 💡 **Tipp: So lesen Sie diese Anleitung.**
> - Jeder **Handlungsschritt ist nummeriert**. Es steht immer dabei, *was* Sie
>   tun, *wo* Sie klicken und *woran Sie erkennen*, dass es geklappt hat.
> - **Farbige Kästen** heben Wichtiges hervor: ⚠️ Warnung (Gefahr oder
>   Datenverlust), 💡 Tipp (Abkürzung), ✅ Erfolgskriterium.
> - **Fachbegriffe** werden beim ersten Vorkommen in Klammern erklärt und noch
>   einmal im [Glossar](#20-glossar) am Ende gesammelt.
> - Sie müssen nicht alles lesen. Finden Sie in [Kapitel 1](#1-das-ziel-vor-augen--welcher-aufbau-ist-meiner)
>   heraus, **welcher der drei Aufbauten Ihrer ist**, und folgen Sie dann dem
>   gemeinsamen Teil plus dem Abschnitt für genau Ihren Aufbau.

---

## Inhaltsverzeichnis

0. [Willkommen — was macht dieses Gerät?](#0-willkommen--was-macht-dieses-gerät)
1. [Das Ziel vor Augen — welcher Aufbau ist meiner?](#1-das-ziel-vor-augen--welcher-aufbau-ist-meiner)
2. [Was Sie brauchen (Checkliste)](#2-was-sie-brauchen-checkliste)
3. [Den Quellcode holen](#3-den-quellcode-holen)
4. [Die Software bauen (Windows)](#4-die-software-bauen-windows)
5. [Den Raspberry Pi vorbereiten](#5-den-raspberry-pi-vorbereiten)
6. [Hardware anschließen](#6-hardware-anschließen)
7. [Software aufspielen (Deployment)](#7-software-aufspielen-deployment)
8. [Der erste Start](#8-der-erste-start)
9. [Grundeinrichtung in der Weboberfläche](#9-grundeinrichtung-in-der-weboberfläche)
10. [Ohne Hardware üben: der Testsensor](#10-ohne-hardware-üben-der-testsensor)
11. [Kalibrieren — der wichtigste Bedienschritt](#11-kalibrieren--der-wichtigste-bedienschritt)
12. [Ihren Aufbau bedienen](#12-ihren-aufbau-bedienen)
13. [Die Anzeigen verstehen](#13-die-anzeigen-verstehen)
14. [Grafana](#14-grafana)
15. [Alarme und E-Mail](#15-alarme-und-e-mail)
16. [Berichte](#16-berichte)
17. [Cloud-Frontend — die Anlage von unterwegs sehen](#17-cloud-frontend--die-anlage-von-unterwegs-sehen)
18. [Alltag und Wartung](#18-alltag-und-wartung)
19. [Wenn etwas nicht geht (Störungshilfe / FAQ)](#19-wenn-etwas-nicht-geht-störungshilfe--faq)
20. [Glossar](#20-glossar)
21. [Kurz-Spickzettel](#21-kurz-spickzettel)

> ⚠️ **Wichtig zu den Namen.** Die Software heißt je nach Aufbau anders. Der
> Name, den die Weboberfläche tatsächlich anzeigt, kommt aus dem Programm selbst:
> **Aufbau 1 = PEGELWatch, Aufbau 2 = SEPWatch, Aufbau 3 = PUMPWatch.** In der
> älteren Entwickler-Dokumentation heißt Aufbau 1 an manchen Stellen noch
> „RIVERWatch" — das ist derselbe Aufbau, nur ein alter Name. Verbindlich ist,
> was die Weboberfläche zeigt: **PEGELWatch** für Aufbau 1.

> 💡 Diese Anleitung wird **bei jedem Neu-Kompilieren automatisch neu erzeugt**
> (Text, Screenshots, HTML und PDF) — siehe [Abschnitt 18.7](#187-so-entsteht-diese-anleitung-für-technisch-interessierte).
> Sie ist damit immer auf demselben Stand wie die Software.

---

## 0. Willkommen — was macht dieses Gerät?

Diese Anlage misst, **wie hoch das Wasser in einem Behälter steht**. Ein kleiner
Drucksensor am Boden des Behälters spürt den Wasserdruck; die Software rechnet
daraus die Höhe des Wasserspiegels in Millimetern (mm) aus und zeigt sie an —
auf einem Bildschirm, in einer Weboberfläche und in schönen Diagrammen. Je nach
Ausbaustufe **steuert die Anlage zusätzlich eine Pumpe** und **schlägt bei
Leckagen oder Störungen per E-Mail Alarm**.

**Für wen ist diese Anleitung?** Für die Person, die die Anlage in Betrieb
nimmt und im Alltag bedient. Sie ist bewusst so einfach geschrieben, dass man
ihr auch ohne Vorwissen folgen kann.

Das Herz der Anlage ist ein **Raspberry Pi** (ein kleiner, handtellergroßer
Computer). Darauf läuft die Mess- und Steuerungssoftware, eine Datenbank für
den Verlauf und eine Diagramm-Anzeige. Alles zusammen läuft im lokalen Netz —
Sie öffnen die Bedienung einfach in einem normalen Internet-Browser.

---

## 1. Das Ziel vor Augen — welcher Aufbau ist meiner?

Dieselbe Software bedient **drei Ausbaustufen** („Aufbauten"). Welcher Aufbau
aktiv ist, wird später in der Weboberfläche eingestellt und bestimmt auch den
angezeigten Namen.

![Platzhalter: Foto der drei fertigen Aufbauten nebeneinander](bilder/platzhalter-aufbauten.png)

| Aufbau | Name (in der Software) | Das ist Ihrer, wenn … |
|:---:|---|---|
| **1** | **PEGELWatch** | Sie **einen** Behälter mit **einem** Sensor haben und nur den Pegel (und optional das Volumen) ablesen wollen. Keine Pumpe. |
| **2** | **SEPWatch** | Sie **mehrere** Behälter gleichzeitig überwachen (Füllstand, Volumen, Durchsatz) und vor **Leckagen** gewarnt werden wollen. Die Pumpen sind extern und werden **nicht** von der Software gesteuert. |
| **3** | **PUMPWatch** | Sie ein **Pumpwerk** mit einer **Drehstrompumpe** haben, die die Software automatisch ein- und ausschaltet, samt **Strommessung** (Shelly 3EM) und **Relaiskarte**. |

> 💡 **Entscheidungshilfe „Welcher bin ich?"**
> - Nur eine Zahl ablesen, ein Behälter → **Aufbau 1 (PEGELWatch)**.
> - Mehrere Behälter, Mengen/Durchsatz, Leck-Warnung, aber keine Pumpe von der
>   Software gesteuert → **Aufbau 2 (SEPWatch)**.
> - Eine große Pumpe, die von selbst an- und ausgeht → **Aufbau 3 (PUMPWatch)**.

Der **gemeinsame Teil** dieser Anleitung (Kapitel 2–11, 13–21) gilt für alle
drei. Nur [Kapitel 12](#12-ihren-aufbau-bedienen) ist in drei Abschnitte
geteilt — lesen Sie dort den zu **Ihrem** Aufbau.

---

## 2. Was Sie brauchen (Checkliste)

### 2.1 Für alle Aufbauten

- [ ] Ein **Raspberry Pi 4 oder Pi 5**, empfohlen mit **mindestens 4 GB
  Arbeitsspeicher (RAM)**. Der RAM ist der Kurzzeit-Speicher des Computers.
- [ ] Eine **SD-Speicherkarte** (empfohlen Typ „A2") oder eine SSD-Festplatte,
  auf der das Betriebssystem liegt.
- [ ] Ein passendes **Netzteil** für den Pi.
- [ ] Ein **Netzwerk** (LAN-Kabel oder WLAN), in dem Pi und Ihr PC hängen.
- [ ] Ein **Windows-PC** zum Bauen und Aufspielen der Software.
- [ ] Ein **Drucksensor MPXV5050DP** je Messstelle (misst 0–50 kPa, das
  entspricht bis ca. **5,10 m Wassersäule**).
- [ ] Ein **AD-Wandler ADS1115** je Messplatine (wandelt die Sensor-Spannung in
  eine Zahl um; hängt am I²C-Bus, der Datenleitung zu den Messplatinen).
- [ ] Eine **Präzisions-Referenzspannung LT1461** (5,0 V), damit die Messung
  auch bei Spannungsschwankungen stabil bleibt.
- [ ] Optional ein **7-Segment-Display** (die kleine, rote Zahlenanzeige) und/oder
  ein **HDMI-Bildschirm** (1024×600) für die große Kiosk-Anzeige.

### 2.2 Zusätzlich für Aufbau 2 (SEPWatch)

- [ ] Mehrere Sensoren/Messplatinen (bis zu **15 Sensoren je Stapel**, mit einem
  zweiten Stapel bis zu **30**).

### 2.3 Zusätzlich für Aufbau 3 (PUMPWatch)

- [ ] Eine **Waveshare RPi Relay Board (B)** — die 8-Kanal-Relaiskarte, die als
  Aufsteck-Platine („HAT") direkt auf den Pi kommt.
- [ ] Ein **Shelly 3EM** — ein Strommessgerät fürs Netzwerk, misst die drei
  Phasen der Drehstrompumpe.
- [ ] Die **Drehstrompumpe** samt **Schütz** und **Motorschutzschalter**.

### 2.4 Werkzeug

Schraubendreher, ggf. Lötkolben (falls Sie die Sensorplatine selbst bestücken),
ein Zollstock oder Maßband (fürs [Kalibrieren](#11-kalibrieren--der-wichtigste-bedienschritt)),
ein Eimer Wasser.

> ⚠️ **Netzspannung und Drehstrom nur durch eine Elektrofachkraft.** Aufbau 3
> schaltet eine echte Drehstrompumpe. Alles, was mit 230 V / 400 V zu tun hat,
> macht **ausschließlich eine ausgebildete Fachkraft**. Diese Anleitung ersetzt
> keine Elektroinstallation.

Tiefergehende Hardware-Details stehen in der Entwickler-Dokumentation:
[docs/04-verdrahtung.md](04-verdrahtung.md), [docs/09-analog-frontend.md](09-analog-frontend.md)
(Sensorplatine) und [docs/10-relaiskarte.md](10-relaiskarte.md).

---

## 3. Den Quellcode holen

Der „Quellcode" ist der Bauplan der Software. Sie holen ihn von der
Code-Plattform **GitHub**. Es gibt zwei Wege.

### 3.1 Weg A — als ZIP-Datei herunterladen (am einfachsten)

1. Öffnen Sie im Browser die Projektseite auf GitHub
   (`github.com/gsandreas/PEGELWatch`).
   → **Erfolg:** Sie sehen die Dateiliste mit Ordnern wie `docs`, `internal`,
   `cmd`.
2. Klicken Sie oben rechts auf den grünen Knopf **„Code"** und dann auf
   **„Download ZIP"**.
   → **Erfolg:** Ihr Browser lädt eine Datei wie `PEGELWatch-main.zip` herunter.
3. Entpacken Sie die ZIP-Datei an einen einfachen Ort, z. B.
   `C:\Pegelwatch\`. (Rechtsklick → „Alle extrahieren".)
   → **Erfolg:** Im Ordner liegen u. a. `build.ps1`, `deploy.ps1` und der
   Ordner `docs`.

### 3.2 Weg B — mit `git clone` (wenn Git installiert ist)

1. Öffnen Sie **PowerShell** (Windows-Taste drücken, „PowerShell" tippen,
   Enter).
2. Wechseln Sie in den Zielordner und holen Sie den Code:
   ```powershell
   cd C:\
   git clone https://github.com/gsandreas/PEGELWatch.git Pegelwatch
   cd C:\Pegelwatch
   ```
   → **Erfolg:** Der Ordner `C:\Pegelwatch` existiert und enthält den Code.

> 💡 Merken Sie sich diesen Ordner (im Beispiel `C:\Pegelwatch`). Alle
> folgenden Befehle führen Sie **in diesem Ordner** aus.

---

## 4. Die Software bauen (Windows)

„Bauen" (englisch: *build*) heißt: aus dem Bauplan (Quellcode) wird das fertige
Programm erzeugt — eine einzelne Datei, die auf dem Pi läuft. Das nennt man ein
**Binary**. Der Clou: Sie bauen auf **Windows** ein Programm für den Pi (dessen
Prozessor „arm64" heißt), ganz ohne extra Werkzeuge auf dem Pi. Das nennt man
**Cross-Compile** (über-Kreuz-Kompilieren).

**Voraussetzung:** Die Programmiersprache **Go** muss auf dem Windows-PC
installiert sein (von `go.dev` herunterladen und installieren). Prüfen mit:
```powershell
go version
```
→ **Erfolg:** Es erscheint eine Zeile wie `go version go1.23 windows/amd64`.

**Bauen:**

1. Öffnen Sie PowerShell im Projektordner (`C:\Pegelwatch`).
2. Führen Sie das Bau-Skript aus:
   ```powershell
   .\build.ps1
   ```
3. Warten Sie, bis der grüne Text erscheint.
   → **Erfolg:** Sie lesen `OK: pegelwatch (… Bytes)`. Im Ordner liegt jetzt die
   fertige Datei **`pegelwatch`** (ohne Dateiendung).

> 💡 Beim Bauen wird automatisch ein **Zeitstempel** (Datum + Uhrzeit) ins
> Programm eingebettet. Den sehen Sie später im Systemstatus der Anlage als
> „Software gebaut" — praktisch, um zu prüfen, ob eine Aktualisierung wirklich
> angekommen ist.

> 💡 Auf Wunsch wird beim Bauen auch **diese Bedienungsanleitung neu erzeugt** —
> dafür hängen Sie **`-BuildManual`** an den Aufruf an (siehe
> [18.7](#187-so-entsteht-diese-anleitung-für-technisch-interessierte)). Ohne
> diesen Zusatz bleibt sie, wie sie ist; das Bauen geht dann deutlich schneller.
> Fehlt ein Werkzeug dafür, sehen Sie nur eine gelbe Warnung — der Bau der
> Software selbst gelingt trotzdem.

---

## 5. Den Raspberry Pi vorbereiten

Jetzt bekommt der Pi sein Betriebssystem und wird für die Anlage vorbereitet.
Die ausführliche technische Fassung steht in [docs/01-installation.md](01-installation.md);
hier die bediengerechte Kurzform.

### 5.1 Betriebssystem installieren

1. Installieren Sie mit dem **Raspberry Pi Imager** (von `raspberrypi.com`) das
   Betriebssystem **Raspberry Pi OS Bookworm, 64-bit (arm64)** auf die
   SD-Karte. Aktivieren Sie im Imager unter den Einstellungen **SSH** und
   vergeben Sie einen Benutzernamen (in dieser Anleitung: `andreas`) und ein
   Passwort.
   → **Erfolg:** Der Pi startet mit der SD-Karte und ist im Netzwerk per SSH
   (Fernzugriff übers Terminal) erreichbar.

### 5.2 Pflicht-Einstellung für die Datenbank (4-KB-Seitengröße)

Die interne Datenbank (InfluxDB 3) stürzt auf manchen Pi-Kerneln ab, wenn nicht
der klassische Speichermodus erzwungen wird. Tun Sie das **immer**:

```bash
echo "kernel=kernel8.img" | sudo tee -a /boot/firmware/config.txt
sudo reboot
```
> ⚠️ Auf älteren Systemen liegt die Datei unter `/boot/config.txt` statt
> `/boot/firmware/config.txt`. Prüfen Sie, welcher Pfad existiert.

### 5.3 I²C (und ggf. SPI) einschalten

Der **I²C-Bus** ist die Datenleitung zu den Messplatinen. **SPI** ist die
Leitung zum 7-Segment-Display. Schalten Sie ein, was Sie brauchen:

```bash
sudo raspi-config nonint do_i2c 0    # I²C ein (immer nötig, außer reiner Testbetrieb)
sudo raspi-config nonint do_spi 0    # SPI ein (nur wenn Sie das 7-Segment-Display nutzen)
```

### 5.4 Den Rest macht das Deploy-Skript

Die restliche Grundeinrichtung — **Grafana** (die Diagramm-Anzeige) und
**InfluxDB 3** (die Verlaufs-Datenbank) — richtet das Skript aus
[Kapitel 7](#7-software-aufspielen-deployment) beim ersten Lauf **automatisch**
ein. Sie müssen dafür nichts von Hand installieren.

> 💡 **Zweiter Sensor-Stapel?** Nur wenn Sie mehr als 4 Messplatinen an *einem*
> Bus betreiben wollen (Aufbau 2 im Vollausbau), brauchen Sie einen zweiten
> I²C-Bus. Empfohlen ist `dtoverlay=i2c6` (Details in
> [docs/04-verdrahtung.md](04-verdrahtung.md)). Für die meisten Anlagen ist das
> **nicht** nötig.

---

## 6. Hardware anschließen

> ⚠️ **Reihenfolge und Sicherheit.** Schließen Sie die Hardware bei
> **ausgeschaltetem** Pi an. Prüfen Sie jede Leitung zweimal. Netzspannung und
> Drehstrom (Aufbau 3) **nur durch eine Elektrofachkraft**.

Der vollständige Verdrahtungsplan mit Pin-Nummern steht in
[docs/04-verdrahtung.md](04-verdrahtung.md). Hier die Kurzfassung je Aufbau.

### 6.1 Alle Aufbauten — die Messkette

Die Signalkette ist immer gleich:

```
Drucksensor (MPXV5050DP) → Filter → Verstärker → AD-Wandler (ADS1115) → I²C-Bus → Raspberry Pi
```

- Der **AD-Wandler ADS1115** wird über vier Leitungen an den Pi angeschlossen:
  Versorgung (3,3 V), Masse (GND) und die beiden I²C-Leitungen **SDA (GPIO2,
  Pin 3)** und **SCL (GPIO3, Pin 5)**.
- Die **Referenzspannung LT1461 (5,0 V)** versorgt den Drucksensor **und** wird
  auf einem eigenen AD-Kanal mitgemessen. So rechnet die Software
  Spannungsschwankungen wieder heraus (das nennt man **ratiometrische
  Kompensation**).
- **Konvention:** Der **erste Kanal (0) ist die Referenz**, der **zweite Kanal
  (1) der erste Drucksensor**.

![Platzhalter: Foto der verdrahteten Sensorplatine mit ADS1115 und Sensor](bilder/platzhalter-messkette.png)

> ⚠️ Versorgen Sie den MPXV5050DP **nie** mit mehr als 5,25 V. Führen Sie die
> Schläuche zum Sensor **knickfrei** — ein Knick verfälscht den Nullpunkt.

### 6.2 Aufbau 2 — mehrere Sensoren

Jeder weitere ADS1115 hängt am **gleichen** I²C-Bus, bekommt aber über den
ADDR-Pin eine andere Adresse: **0x48, 0x49, 0x4A, 0x4B** (maximal 4 Platinen je
Bus). Alle teilen sich SDA, SCL, Versorgung und Masse.

### 6.3 Aufbau 3 — Relaiskarte, Pumpe, Shelly

- Die **Relaiskarte** wird als HAT direkt auf die 40-polige Stiftleiste des Pi
  gesteckt — keine separate Verkabelung zum Pi nötig. Werkseinstellung:
  **CH1 = Pumpe (GPIO5)**, **CH2 = Alarm (GPIO6)**, **CH3 = Pneumatik (GPIO13)**;
  **CH4–CH8** sind frei (für Logik-Ausgänge).
- **Alle Lasten an den Kontakt „NO" (normally open) anschließen.** Grund:
  Stürzt der Pi ab oder verliert Strom, fällt das Relais in Ruhestellung und die
  Pumpe **stoppt automatisch** (das nennt man **Fail-Safe**, sicherer Zustand).
- Die **Drehstrompumpe** wird **nicht** direkt geschaltet, sondern über ein
  **Schütz** (der Relaiskontakt schaltet nur dessen Steuerkreis), mit
  vorgeschaltetem **Motorschutzschalter**.
- Der **Shelly 3EM** wird nach Herstelleranleitung in die Zuleitung der Pumpe
  eingebaut und ins Netzwerk gebracht. Gefunden wird er später per Knopfdruck in
  der Weboberfläche.

![Platzhalter: Foto Relaiskarte auf dem Pi und Schaltschrank mit Schütz](bilder/platzhalter-relaiskarte.png)

> ⚠️ Die Relais sind **aktiv-LOW** verdrahtet (Relais zieht an, wenn der Pin
> „LOW" ist). Darum kümmert sich die Software selbst — Sie denken in „an/aus",
> nicht in Spannungspegeln.

---

## 7. Software aufspielen (Deployment)

„Deployment" (Ausrollen) heißt: das gebaute Programm auf den Pi kopieren,
einrichten und starten. Das erledigt ein Skript für Sie.

### 7.1 Einen einzelnen Pi einrichten

1. Ermitteln Sie die **IP-Adresse** des Pi (z. B. im Router oder mit
   `hostname -I` auf dem Pi).
2. Führen Sie auf dem Windows-PC im Projektordner aus (ersetzen Sie die
   IP-Adresse durch die Ihres Pi):
   ```powershell
   .\deploy.ps1 -PiHost 192.168.0.106
   ```
   → **Erfolg:** Das Skript baut das Binary, kopiert es auf den Pi, richtet beim
   **allerersten** Mal Grafana + InfluxDB + den Systemdienst ein und startet
   alles. Am Ende steht eine Erfolgsmeldung.

### 7.2 Was `-UpdateConfig` bedeutet (sehr wichtig)

Ein **normales** `deploy.ps1 -PiHost …` tauscht **nur das Programm** aus. Ihre
Konfiguration (`config.toml`), Ihre Zugangsdaten (`secrets.toml`) und der
gespeicherte Betriebszustand (`state.db`) auf dem Pi **bleiben unangetastet**.

Nur wenn Sie den Schalter **`-UpdateConfig`** ausdrücklich anhängen, wird die
Konfiguration auf dem Pi überschrieben (mit Sicherheitsabfrage):

```powershell
.\deploy.ps1 -PiHost 192.168.0.106 -UpdateConfig
```

> ⚠️ Benutzen Sie `-UpdateConfig` nur, wenn Sie die Konfiguration wirklich vom
> PC aus ersetzen wollen. Ein **normales Update überschreibt Ihre Einstellungen
> und Kalibrierung nie** — genau so ist es gewollt.

### 7.3 Mehrere Geräte auf einmal

Wenn Sie mehrere Anlagen betreiben, sind sie in einem Geräte-Register
(`deploy/devices.psd1`) mit Namen hinterlegt. Dann geht auch:

```powershell
.\deploy-fleet.ps1 -List                       # zeigt alle registrierten Geräte
.\deploy-fleet.ps1 -Device PUMPWatch           # ein Gerät aktualisieren
.\deploy-fleet.ps1 -Device PEGELWatch,PUMPWatch  # mehrere
.\deploy-fleet.ps1 -Device all                 # alle eingerichteten
```

Jedes Gerät hat sein **eigenes** Konfigurationsverzeichnis — so bekommt keine
Anlage versehentlich die Einstellungen einer anderen.

---

## 8. Der erste Start

Nach dem Deployment läuft die Anlage. Jetzt schauen Sie sie das erste Mal an.

### 8.1 Die Weboberfläche öffnen

1. Öffnen Sie auf einem PC oder Handy im **gleichen Netzwerk** einen Browser.
2. Geben Sie die Adresse der Anlage ein: `http://<IP-des-Pi>:8080/` — also
   z. B. **`http://192.168.0.106:8080/`**. Die `8080` ist der Standard-Port
   (die „Türnummer" der Weboberfläche).
   → **Erfolg:** Es erscheint die **Startseite** mit blauem Kopfbalken und
   Live-Messwerten.

> 💡 Es gibt **kein Passwort**. Die Weboberfläche ist bewusst für das lokale
> Netz gedacht und braucht keine Anmeldung. (Das öffentliche Cloud-Frontend aus
> [Kapitel 17](#17-cloud-frontend--die-anlage-von-unterwegs-sehen) hat eines.)

### 8.2 Was die Startseite zeigt

![Startseite mit Live-Messwerten, Server-Status und der Seitenliste](bilder/startseite.png)

- **Live-Messwerte:** je Sensor eine Kachel mit dem aktuellen Pegel in mm, der
  Sensorspannung in mV und der Anzeige des Abtastzyklus (⏩ schnell / 🐢 langsam,
  siehe [Kapitel 11.4](#114-schnell-und-langsam-adaptives-polling)). Die Werte
  aktualisieren sich **von selbst** über einen Datenstrom — kein Neuladen nötig.
- **Pumpe** (nur Aufbau 3): drei Knöpfe **AUTOMATIK / EIN / AUS** und eine
  Statusanzeige, ob die Pumpe gerade läuft.
- **Cloud-Frontend:** ob dieser Pi das öffentliche Frontend erreicht (nur
  sichtbar, wenn eingerichtet).
- **Verfügbare Seiten:** eine Liste (Sitemap) aller Seiten mit voller Adresse —
  inklusive der Kiosk-Ansichten.
- Kacheln **Live-Server-Status** (laufen alle Dienste?) und **Raspberry Pi**
  (CPU-/GPU-Temperatur).

### 8.3 Die Navigation

Im blauen Kopfbalken jeder Seite gibt es drei Links: **Übersicht** (die
Startseite `/`), **Konfiguration** (`/konfiguration`) und **Handbuch**
(`/handbuch`, eine kurze Bedienhilfe direkt in der Oberfläche).

### 8.4 Der Systemstatus

Öffnen Sie **Konfiguration** und klappen Sie den Abschnitt **„Systemstatus"**
auf. Er zeigt alles, was für den Betrieb zählt:

- **Live-Server-Status** — sind InfluxDB, Grafana, SMTP (Mailserver) und (in
  Aufbau 3) der Shelly erreichbar? Grüner Punkt = ja, roter Punkt = nein.
- **Netzwerk** — welche Netzwerkschnittstelle die aktive Internetverbindung ist.
- **Gefundene Hardware** — welche ADS1115-Platinen der I²C-Scan auf welcher
  Adresse gefunden hat, dazu Aufbau, Pfade der Konfigurations- und
  Zustandsdatei, Go-Version und der Build-Zeitstempel („Software gebaut").
- **Angebotene Seiten** — dieselbe Sitemap wie auf der Startseite.
- **Abhängigkeiten** — fehlt ein benötigtes Programm, steht hier der fertige
  Installationsbefehl zum Kopieren (die Software führt ihn **nicht** selbst aus).

> ✅ **Alles bereit, wenn:** im Live-Server-Status alle genutzten Dienste grün
> sind und unter „Gefundene Hardware" Ihre Messplatinen mit der erwarteten
> Adresse (z. B. `0x48`) auftauchen.

---

## 9. Grundeinrichtung in der Weboberfläche

Jetzt stellen Sie die Anlage auf Ihren Fall ein. Alles geschieht auf der Seite
**Konfiguration** (`/konfiguration`).

![Die Konfigurationsseite mit der oben angehefteten Aktionsleiste und den einklappbaren Abschnitten](bilder/konfiguration.png)

> 💡 **So funktioniert die Konfigurationsseite.**
> - Ganz oben klebt eine **Aktionsleiste**, die beim Scrollen sichtbar bleibt.
>   Darin: **💾 Speichern**, **⬇ Exportieren**, **⬆ Importieren**,
>   **🔑 Zugangsdaten speichern**, **🔄 Dienst neu starten**.
> - Die Abschnitte sind **eingeklappt**. Klicken Sie auf eine Überschrift, um
>   sie auf-/zuzuklappen.
> - Jedes Feld hat einen **Hilfstext** darunter, der erklärt, welcher Wert
>   erwartet wird.

> ⚠️ **Speichern ≠ wirksam.** Änderungen an **Sensoren, GPIO-Pins oder dem
> I²C-Bus** werden erst nach einem **Neustart des Dienstes** aktiv. Klicken Sie
> dafür nach dem Speichern auf **🔄 Dienst neu starten** (die Anlage fährt
> geordnet herunter, startet automatisch neu, die Seite verbindet sich von
> selbst wieder).

### 9.1 Abschnitt „Allgemein"

- **Aktiver Aufbau** — wählen Sie **1 – PEGELWatch**, **2 – SEPWatch** oder
  **3 – PUMPWatch**. Diese Wahl blendet die passenden weiteren Abschnitte ein.
- **Web-Port** — die Türnummer der Weboberfläche (Standard **8080**). Nur
  ändern, wenn 8080 belegt ist.
- **I²C-Bus** — die Busnummer der Messplatinen, am Pi normalerweise **1**.
- **Grafana-URL** — Adresse der Diagramm-Anzeige (z. B.
  `http://localhost:3000`), nur für die Erreichbarkeitsprüfung.
- Darunter die **Polling-** und **Durchsatz-Feinparameter** — die
  Standardwerte passen fast immer (siehe
  [Kapitel 11.4](#114-schnell-und-langsam-adaptives-polling)).

### 9.2 Abschnitt „Sensoren"

Ein Eintrag je Drucksensor. Klicken Sie **„+ Sensor hinzufügen"**. Je Sensor:

- **ID** — kurze, eindeutige Kennung (z. B. `s1`); nach dem Speichern möglichst
  nicht mehr ändern.
- **Name** — Klartext für Anzeige und E-Mails (z. B. „Zisterne Nord").
- **Aktiv** — abgehakt = wird gemessen. Deaktivierte Sensoren werden nicht
  abgefragt.
- **I²C-Bus (0 = Standard)** — leer/0 nutzt den Standardbus; für einen zweiten
  Stapel z. B. `6`.
- **Board-Adresse** — hier bietet die Oberfläche **nur die beim Start
  tatsächlich gefundenen** Adressen an (mit „✓ gefunden"). Das verhindert
  falsche Adressen, bei denen dann „nichts angezeigt" wird. „Andere Adresse…"
  nur für noch nicht angeschlossene Hardware.
- **ADC-Kanal** — welcher der vier Eingänge (0–3) den Sensor misst
  (Konvention: 1 = erster Drucksensor).
- **Referenzkanal** / **Referenz-Board** — wo die Referenzspannung liegt
  (Konvention: Kanal 0). Für **„eine Referenz pro Stapel"** wählen Sie bei allen
  Sensoren dasselbe Referenz-Board — so bleiben bis zu 15 Kanäle für Sensoren
  frei.

Ganz oben im Abschnitt steht das **Kanal-Budget**: wie viele der maximal
4 Platinen / 16 Kanäle je Bus belegt sind. Wird es überschritten, warnt die
Anzeige und das Speichern schlägt fehl.

### 9.3 Behältergeometrie (für Volumen/Durchsatz)

Nur nötig, wenn die Anlage **Liter** (nicht nur mm) berechnen soll. Je Sensor im
Block **„Behälter"**:

- **Behälter-Vorlage** — wählen Sie einen **Standardbehälter** (siehe unten),
  dann muss man nichts eintippen; oder **„eigene Geometrie"** für individuelle
  Maße.
- Bei eigener Geometrie: **Form** (Zylinder / Quader / Kegelstumpf) und die
  zugehörigen Maße. **Wichtig:** Die **Füllhöhe** ist die maßgebliche Höhe der
  Mengenrechnung, nicht zwingend die Bauhöhe.
- **Volumen in InfluxDB schreiben** — abhaken, damit das Volumen zusätzlich
  gespeichert und in Grafana sichtbar wird.

**Standardbehälter** verwalten Sie zentral im Abschnitt **„Standardbehälter"**.
Eingebaut und sofort wählbar sind u. a. **IBC-Container** (300/600/640/800/1000 l),
**Schnelleinsatzbehälter** (30.000/50.000/75.000 l) und der **Abrollbehälter
Zwischenlager**. Passt eine Vorlage fast, aber die Höhe stimmt nicht? Kopieren
Sie sie mit **„⧉ Als eigene Vorlage kopieren"** und passen Sie sie an.

### 9.4 InfluxDB (Verlaufs-Datenbank)

- **Lokal (Pflicht)** — URL (z. B. `http://localhost:8086`), Datenbankname
  (`pegelwatch`) und das **Token** (Zugangsschlüssel). Das Token tragen Sie ins
  Feld „Token" ein und speichern es über **🔑 Zugangsdaten speichern**.
- **API-Version** — **v3** ist Standard. **v2** nur als Rückfall auf einem
  Pi 4 mit nur 2 GB RAM; dann zusätzlich die Organisation angeben.
- **FHEM (optional)** — ein zweiter, bereits vorhandener InfluxDB-Server, an den
  die Messwerte zusätzlich geschickt werden.

### 9.5 Speichern und wirksam machen

1. **💾 Speichern** (Aktionsleiste oben).
   → **Erfolg:** grüne Meldung „Gespeichert. …".
2. Für Änderungen an Sensoren/GPIO/I²C: **🔄 Dienst neu starten**, Rückfrage
   bestätigen.
   → **Erfolg:** „Dienst startet neu… Die Seite verbindet sich automatisch
   wieder".

> 💡 **Export/Import.** **⬇ Exportieren** lädt Ihre `config.toml` als Datei
> herunter — gut als Sicherung oder zum Übertragen auf eine andere Anlage.
> **⬆ Importieren** lädt eine solche Datei wieder ein. **Zugangsdaten (Passwort,
> Tokens) reisen dabei NIE mit** — die liegen getrennt in `secrets.toml`. Beim
> Import auf **andere Hardware** warnt die Anlage, weil die Kalibrierung
> gerätespezifisch ist.

### 9.6 Gewässer-Querschnitt (für den Durchfluss)

Nur für **Messstellen in einem Bach oder Fluss** (Aufbau 1). Damit rechnet die
Anlage aus dem Pegel die **Wasserfläche** und den **Durchfluss** aus — und der
Fluss-Kiosk zeichnet den echten Querschnitt statt eines Symbols.

Je Sensor im Block **„Gewässer-Querschnitt"**:

1. **„⌁ Beispiel-Trapez einsetzen"** klicken — Sie bekommen einen typischen
   Bachquerschnitt, den Sie nur noch anpassen müssen. Oder **„+ Stützpunkt"**
   für jede Zeile einzeln.
2. Je Zeile: **Höhe über der Sohle** und die **Breite des Gewässers in dieser
   Höhe**. Die unterste Zeile muss auf **Höhe 0** stehen (das ist die Sohle) —
   eine Breite von 0 ergibt ein spitzes V-Profil.
3. **Rechts daneben sehen Sie sofort**, was Sie gerade bauen: der Querschnitt
   wird beim Tippen mitgezeichnet, darunter stehen die Fläche bei randvollem
   Profil und — wenn eine Geschwindigkeit hinterlegt ist — der überschlägige
   Durchfluss.

So entsteht der Querschnitt als **Stapel von Trapezen**: Zwischen zwei
Stützpunkten verläuft das Ufer gerade, die Fläche dazwischen ist ein Trapez.

**Fließgeschwindigkeit** (darunter, bestimmt den Durchfluss):

- **keine** — es wird nur die Fläche berechnet, kein Durchfluss.
- **Stützstellen: Pegel → Geschwindigkeit** — Sie tragen gemessene Werte ein
  (z. B. mit einem Messflügel bei niedrigem und bei hohem Wasser). Dazwischen
  rechnet die Anlage linear, außerhalb bleibt der äußerste Wert stehen. **Eine
  einzige** Stützstelle bedeutet: überall dieselbe Geschwindigkeit.
- **Formel von Manning-Strickler** — geschätzt aus zwei Werten:
  **Rauheitsbeiwert k** (Wiesenbach ≈ 25, Kies ≈ 30–35, glatter Beton ≈ 80) und
  **Sohlgefälle in ‰** (2 ‰ = 2 mm Höhenverlust je Meter Lauflänge).

> 💡 Ohne Querschnitt funktioniert alles andere unverändert weiter — Fläche und
> Durchfluss bleiben dann einfach leer.

### 9.7 Was der Bildschirm am Pi zeigt

Hängt am Raspberry Pi selbst ein Monitor, öffnet die Anlage dort beim Start
automatisch eine Vollbild-Ansicht. **Welche**, stellen Sie im Abschnitt
*Allgemein* unter **„Bildschirm am Pi zeigt"** ein:

- **automatisch** (Standard) — passend zum Aufbau: Aufbau 1 den Fluss-Kiosk,
  Aufbau 2 den Mehrkanal-Kiosk, Aufbau 3 den Hebewerk-Kiosk. In den allermeisten
  Fällen ist das genau richtig.
- **eine feste Seite** — wenn dieser Bildschirm etwas anderes zeigen soll.
- **kein Selbststart** — für Anlagen **ohne** Monitor. Dann wird gar kein
  Browser gestartet.

Über das Netzwerk erreichen Sie ohnehin **alle** Seiten, unabhängig von dieser
Einstellung. Sie wirkt nach **Speichern + Dienst neu starten**.

> 💡 Bleibt der Bildschirm schwarz, obwohl ein Monitor angeschlossen ist:
> Schauen Sie ins Protokoll (`journalctl -u pegelwatch`) nach Zeilen mit
> `[gui]`. Dort steht, ob Chromium fehlt (`sudo apt install chromium`) oder ob
> keine grafische Sitzung läuft.

### 9.8 7-Segment-Display

Im Abschnitt **„Allgemein"** ganz unten: **„LED-Display angeschlossen und
aktiv"**. Das kleine rote Zahlenmodul (MAX7219) zeigt den Pegel des ersten
aktiven Sensors in mm. Es hängt fest an **GPIO10, GPIO11 und GPIO8** — diese
drei Pins sind dann belegt und stehen nicht mehr für Logik-Ausgänge zur
Verfügung. Ist kein Modul angeschlossen, startet die Anlage trotzdem und
schaltet die Anzeige nur ab. Wirkt nach **Speichern + Dienst neu starten**.

---

## 10. Ohne Hardware üben: der Testsensor

Sie können die komplette Oberfläche **gefahrlos ausprobieren**, ohne einen
einzigen Sensor anzuschließen. Ein **Testsensor** (Simulation) erzeugt seinen
Pegel rein rechnerisch und durchläuft denselben Weg wie ein echter Sensor
(Kalibrierung, Alarme, Volumen, Pumpensteuerung).

1. Legen Sie einen Sensor an (**„+ Sensor hinzufügen"**).
2. Im Block **„Testsensor (Simulation ohne Messhardware)"** haken Sie
   **„Simulation aktiv"** an.
3. Stellen Sie **Grundpegel**, **Amplitude** (die Größe der Sinus-Schwingung um
   den Grundpegel) und **Periode** (Dauer eines Zyklus, Standard 300 s) ein.
4. **💾 Speichern** und **🔄 Dienst neu starten**.
   → **Erfolg:** Auf der Startseite bewegt sich der Pegel des Testsensors,
   obwohl keine Hardware angeschlossen ist.

> 💡 Ein Testsensor belegt **kein** Kanal-Budget. Sind **alle** Sensoren
> simuliert, startet die Anlage sogar **ganz ohne** I²C-Bus.

**Live steuern:** Im Systemstatus erscheint bei laufenden Testsensoren der
Abschnitt **„Testsensor-Steuerung"** mit einem **Schieberegler** je Sensor.
Damit verschieben Sie den Grundpegel sofort — ideal, um gezielt Alarmschwellen,
Pumpenschwellen oder die Leckage-Erkennung zu überfahren. Schiebereglerwerte
werden **nicht** gespeichert; nach einem Neustart gilt wieder der konfigurierte
Grundpegel. Mehr Szenarien: [docs/05-testsensor.md](05-testsensor.md).

---

## 11. Kalibrieren — der wichtigste Bedienschritt

Der Sensor liefert zunächst nur eine **Spannung** (in mV), keine Höhe. Beim
**Kalibrieren** zeigen Sie der Software einmal: „Bei dieser Spannung ist der
Behälter so-und-so-hoch gefüllt." Aus mehreren solcher **Stützstellen** rechnet
sie danach jede Spannung in eine echte Höhe um.

> ⚠️ **Ohne Kalibrierung keine gültigen Messwerte.** Ein Sensor ohne
> Kalibrierung zeigt nur eine Rohspannung, keinen brauchbaren Pegel.

### 11.1 Stützstellen aufnehmen

Je Sensor gibt es in der Sensorkarte den Block **„Kalibrierung"**.

1. Füllen Sie den Behälter auf eine bekannte Höhe (mit dem Zollstock messen).
2. Klicken Sie **„+ Stützstelle"**, tragen Sie den **Wasserstand (mm)** ein.
   Die dazugehörige **Spannung (mV)** lesen Sie aus dem aktuellen Messwert ab
   (Startseite/Live) und tragen sie ein.
3. Wiederholen Sie das für mehrere Höhen, verteilt über den ganzen Messbereich.
   → **Erfolg:** Unter der Tabelle erscheint **„Fit-Fehler: 0,00 mm
   (stückweise-linear — exakter Fit durch alle Punkte)."**

**Mindestens 2 Stützstellen** sind technisch nötig, **empfohlen sind
mindestens 10** über den gesamten Bereich. Speichern Sie mit weniger als 10,
fragt die Oberfläche noch einmal ausdrücklich nach.

> 💡 Der Sensor MPXV5050DP ist **linear**. Oberhalb der höchsten Stützstelle
> verlängert die Software die letzte Gerade automatisch (bis ~5,1 m). Es genügt
> also, z. B. nur die ersten 50 mm sauber zu vermessen — der Rest folgt
> derselben Geraden. Stützstellen **über ~5,1 m** sind physikalisch unzulässig
> und werden gewarnt.

### 11.2 Eine Kennlinie auf viele gleiche Sensoren übertragen

Sind mehrere Sensoren **baugleich**, müssen Sie nicht jeden einzeln vermessen.

- **★ Als Standard setzen** (in einer fertig kalibrierten Sensorkarte) — erhebt
  deren Kennlinie zur zentralen **Standard-Kalibrierung**.
- In jeder anderen Sensorkarte haken Sie dann **„Zentrale Standard-Kalibrierung
  verwenden"** an — der Sensor misst mit der zentralen Kennlinie. Ändern Sie die
  Standard-Kennlinie später, wirkt das (nach Neustart) auf **alle** so
  gebundenen Sensoren.
- Alternativ **⬇ Standard in eigene Kennlinie kopieren** — der Sensor bekommt
  eine **eigene Kopie**, die Sie danach individuell nachjustieren können.

Die zentrale Kennlinie pflegen Sie oben im Abschnitt **„Standard-Kalibrierung
(zentral)"**.

### 11.3 Schutz vor versehentlichem Löschen (doppelte Rückfragen)

Weil eine gelöschte Kalibrierung einen Sensor blind macht, ist das Löschen
mehrfach abgesichert:

| Aktion | Absicherung |
|---|---|
| **Einzelnen Kalibrierpunkt** löschen (`✕`) | Eine Rückfrage. |
| **Komplette Kalibrierung** eines Sensors löschen (**🗑 Kalibrierung komplett löschen**) | Zwei Rückfragen — die zweite verlangt, dass Sie die **Sensor-ID** eintippen. |
| **Standard-Kennlinie übernehmen** (⬇), überschreibt die eigene | Rückfrage **plus** Eintippen der Sensor-ID (wie beim Löschen). |
| **Standard-Kennlinie löschen** (🗑) | Rückfrage plus Eintippen von **`STANDARD`**. |

> ⚠️ Diese Rückfragen sind kein Schikane, sondern Ihr Schutz. Tippen Sie die
> geforderte Bestätigung nur ein, wenn Sie den Verlust wirklich wollen.

### 11.4 Schnell und langsam (adaptives Polling)

Die Anlage misst **adaptiv**: solange sich der Pegel kaum ändert, misst sie
**langsam** (Standard alle **20 s** — 🐢). Springt der Pegel, schaltet sie auf
**schnell** (Standard alle **250 ms** — ⏩) und wieder zurück, sobald er stabil
ist. Die Schwellen dafür (Sprungschwelle 10 %, Totband 2 mm, Fenster 100
Messwerte, Stabilität 1 %) stehen im Abschnitt „Allgemein" und passen fast
immer. Sie sehen den aktiven Zyklus auf der Startseite und in den Kiosks.

---

## 12. Ihren Aufbau bedienen

Lesen Sie **nur** den Abschnitt zu Ihrem Aufbau.

### 12.1 PEGELWatch (Aufbau 1) — einen Behälter ablesen

Das ist der einfachste Fall: ein Sensor, ein Behälter.

- Den **Pegel** lesen Sie auf der **Startseite** (Zahl in mm), am
  7-Segment-Display oder — falls angeschlossen — auf einem großen Bildschirm ab.
- Ist eine **Behältergeometrie** hinterlegt (siehe
  [9.3](#93-behältergeometrie-für-volumendurchsatz)), zeigt die Anlage
  zusätzlich das **Volumen in Litern** und schreibt es (bei „Volumen in InfluxDB
  schreiben") in die Datenbank für Grafana.
- Alarme (Hochwasser/Niedrigwasser) kommen **per E-Mail** — Aufbau 1 hat keinen
  Relaisausgang.
- Ist die Messstelle ein **Bach oder Fluss**, hinterlegen Sie den
  **Gewässer-Querschnitt** (siehe
  [9.6](#96-gewässer-querschnitt-für-den-durchfluss)). Der **Fluss-Kiosk**
  (`/fluss-kiosk`, siehe [13.4](#134-fluss-kiosk-aufbau-1)) zeigt dann den
  Querschnitt mit dem Wasserstand als blaue Fläche, dazu Querschnittsfläche und
  Durchfluss.

### 12.2 SEPWatch (Aufbau 2) — mehrere Behälter, Leckage

Aufbau 2 überwacht mehrere Behälter parallel. Die zentrale Betriebsansicht ist
der **Mehrkanal-Kiosk** (`/aufbau2-kiosk`, siehe [13.3](#133-mehrkanal-kiosk-aufbau-2)).

Je Behälter sehen Sie:
- **Füllstand** (mm) und einen Füllbalken,
- **aktuelles Volumen** (Liter),
- **Gefüllt (gesamt)** — die seit dem letzten Nullen kumuliert **eingefüllte**
  Menge,
- **Durchsatz (gesamt)** — die kumuliert **abtransportierte** Menge (was einmal
  drin war und schon wieder heraus ist).

Unten stehen **Gesamtvolumen** und **Durchsatz (Summe)** über alle Behälter.

**Behältersummen nullen:**
- Ein einzelner Behälter: Knopf **„BEHÄLTERSUMMEN NULLEN"** unter seiner Karte
  (mit Rückfrage).
- Alle auf einmal: Knopf **„ALLE SUMMEN NULLEN"** in der Fußzeile (mit
  Rückfrage).
  → **Erfolg:** „Gefüllt" und „Durchsatz" springen auf 0.

> ⚠️ **Leckage-Alarm verstehen.** Die externen Pumpen leeren die Behälter mit
> einem **bekannten, erwarteten** Gefälle. Fällt der Pegel **steiler** als der
> je Sensor eingestellte „Max. erwartete Entleer-Gradient (mm/s)", wertet die
> Anlage das als möglichen **Leckschaden/Riss** und schlägt Alarm (rote
> Markierung „⚠ LECKAGE" auf der Karte + E-Mail). Aktivieren Sie ihn nur, wenn es
> solche vorhersehbaren Entnahmepumpen gibt (Haken „Leckage-Alarm aktiv" +
> passenden Gradienten je Sensor einstellen).

**Auswertezeitraum:** Oben im Kiosk wählen Sie **1 Stunde / 24 Stunden / 7 Tage
/ 30 Tage** — je Behälter erscheint dann „Gefüllt" und „Durchsatz" für genau
diesen Zeitraum.

### 12.3 PUMPWatch (Aufbau 3) — Pumpwerk bedienen

Aufbau 3 steuert eine Drehstrompumpe automatisch. Die Betriebsansicht ist der
**Hebewerk-Kiosk** (`/pump-kiosk`, siehe [13.2](#132-hebewerk-kiosk-aufbau-3)).

**Betriebsmodus umschalten** (drei Knöpfe, auf Startseite, Kiosk und in
Grafana verlinkt):

| Knopf | Bedeutung |
|---|---|
| **AUTOMATIK** | Die Software entscheidet: Pumpe **EIN** bei hohem Pegel, **AUS** bei niedrigem. **Der Normalfall.** |
| **EIN** | Pumpe läuft dauerhaft, egal wie hoch das Wasser steht. |
| **AUS** | Pumpe bleibt aus, egal wie hoch das Wasser steht. |

> ⚠️ Schalten Sie **EIN** oder **AUS** nur, wenn Sie genau wissen, warum. Im
> Zweifel: **AUTOMATIK**. Jede Umschaltung wird per E-Mail gemeldet. Ein Wechsel
> **auf Automatik** übernimmt sofort den richtigen Zustand anhand des letzten
> Pegels (startet oder stoppt also ggf. sofort).

**Einstellungen** (Abschnitt „Aufbau 3 — Pumpe, Relais, Shelly"):

- **Pegel EIN (mm)** / **Pegel AUS (mm)** — die Schaltschwellen (Standard 3000 /
  500). Sind beide 0, setzt die Software sicherheitshalber 3000/500.
- **Offset (mm)** — wird auf den Pegel addiert, falls der Ansaugschlauch etwas
  über dem Boden endet.
- **Freifall-Spannung (mV)** — die Sensorspannung, unter der der Schlauch als
  „frei hängend, nicht im Wasser" erkannt wird (Standard **250 mV**). Grundlage
  der **Nullpunkt-Selbstkalibrierung**.
- **Selbstkal. alle N Vorgänge** — nach so vielen Pumpvorgängen fährt die Pumpe
  im nächsten Automatik-Lauf gezielt bis zum Freifall und setzt den Nullpunkt
  neu (Standard 10). Während dieser **Kalibrierfahrt** zeigt der Kiosk ein
  **rotes Vollbild-Popup** „NULLPUNKTKALIBRIERUNG AKTIV".
- **Max. Laufzeit (s, 0 = aus)** — Rückfallschutz: läuft die Pumpe
  länger am Stück, wird sie **zwangsabgeschaltet** und ein Alarm verschickt
  (Standard 300 s). „Nach Zwangsabschaltung": **Gesperrt bis Moduswechsel**
  (sicherste Variante) oder **Nach Abkühlzeit (5 min) wieder frei**.
- **Leistungsabfall (Luft / Trockenlauf)** — zieht die Pumpe Luft, sinkt ihre
  Leistung deutlich. **Referenzleistung** (Standard 1260 W), **Abschaltschwelle
  in %** (Standard 20 %, also unter 1008 W) und **Mindestdauer** (Standard 10 s):
  liegt die Leistung so lange darunter, wird die Pumpe **abgeschaltet** und ein
  Alarm verschickt; nach 5 min Abkühlzeit regelt die Automatik wieder normal.
- **Überstrom-Schwelle (A)** — ab diesem Phasenstrom sofort Pumpe aus **+ Alarm
  (E-Mail und Relais)**. Die **Überstrom-Karenz (s)** überbrückt den
  Anlaufstrom des Motors (Standard 8 s): Er liegt beim Start kurzzeitig weit
  über dem Betriebsstrom und würde die Pumpe sonst bei jedem Start abwürgen.
  Der Stromzähler wird nur alle 5 s gelesen — Werte **unter 6 s wirken nicht**.
  Ein negativer Wert schaltet die Karenz ab.
- **Unterstrom-Schwelle (A, 0 = aus)** — vermutet einen Phasenausfall, wenn der
  Strom zu klein ist. Nur aktiv, solange der Shelly erreichbar ist. Die
  **Unterstrom-Karenz (s)** wartet nach dem Start (Standard 3 s), damit der
  niedrige Anlaufstrom keinen Fehlalarm auslöst.

**Shelly 3EM finden und Strom messen:**
1. Im Block „Shelly 3EM" auf **🔍 Netz durchsuchen** klicken.
   → **Erfolg:** gefundene Geräte erscheinen als Knöpfe.
2. Auf **„✓ … übernehmen"** klicken — URL und Generation werden eingetragen.
3. **💾 Speichern**, **🔄 Dienst neu starten**.
   → **Erfolg:** im Live-Server-Status ist „Shelly 3EM" grün; im Kiosk erscheinen
   die drei Phasen (Strom/Spannung/Leistung).

**Laufbericht je Pumpenlauf:** Nach **jedem** Pumpenlauf verschickt PUMPWatch
automatisch eine E-Mail mit Start/Ende/Dauer, Abschaltgrund, Min/Mittel/Max je
Phase, dem Stromverlauf als Diagramm (L1 rot, L2 grün, L3 blau) und einem
Grafana-Link auf genau dieses Zeitfenster.

**Logik-Relaisausgänge (freie Kanäle CH4–CH8):** Sie können die freien
Relaiskanäle frei belegen. Beispiel: „Schalte CH4 ein, wenn die CPU-Temperatur
über 65 °C liegt." Im Abschnitt „Logik-Ausgänge":
1. **„+ Logik-Ausgang hinzufügen"**.
2. **Name**, **Relais-Kanal** (CH4–CH8), **Quellsignal** (mit Live-Wert in
   eckigen Klammern), **Vergleich** (`> >= < <= == !=`), **Festwert** (in der
   Einheit der Quelle) und **Totzeit (s)** einstellen. Die Totzeit verhindert
   Flattern: die Bedingung muss so lange ununterbrochen erfüllt sein.
   → **Sicherheit:** Liefert die Quelle keine Werte (mehr), fällt der Ausgang in
   den sicheren Aus-Zustand.

---

## 13. Die Anzeigen verstehen

Es gibt mehrere Wege, die Werte zu sehen.

### 13.1 Startseite und 7-Segment-Display

- Die **Startseite** (`/`) zeigt alle Sensoren als Live-Kacheln (Pegel in mm,
  Spannung in mV, Abtastzyklus ⏩/🐢).
- Das **7-Segment-Display** (die kleine rote Zahlenanzeige, falls angeschlossen)
  zeigt im Betrieb **nur den Pegel** des Hauptsensors in mm. Ist der Messwert
  ungültig, erscheinen `----`.
- Beim **Herunterfahren** wechselt es die Rolle: erst ein umlaufender
  **Ladekreis** („fährt herunter, bitte warten"), ganz zum Schluss **`AUS`** —
  erst dann darf der Strom getrennt werden (siehe
  [13.7](#137-die-anlage-geordnet-herunterfahren-)).

### 13.2 Hebewerk-Kiosk (Aufbau 3)

![Hebewerk-Kiosk: Pegel-Gauge mit Schwellen-Markern, Pumpenstatus, Phasenströme, Verlaufsdiagramm](bilder/hebewerk-kiosk.png)

Die bildschirmfüllende Betriebsansicht unter **`/pump-kiosk`** (in der Sitemap
„Hebewerk_Kiosk"), ausgelegt für **1024×600**:

- **Rundanzeige (Gauge)** — der Pegel. Die Skala richtet sich nach der Tankhöhe
  des Hauptsensors. Kleine **Pfeil-Marker** außen zeigen die Schwellen: **EIN**
  (grün), **AUS** (blau), **AL▲** Hochwasser (rot), **AL▼** Niedrigwasser
  (orange). Ist eine Behältergeometrie hinterlegt, steht darunter Volumen und
  Durchsatz.
- **Pumpenstatus** — ein Ring (dreht sich, wenn die Pumpe läuft), „PUMPE
  LÄUFT/AUS" und die Zeile **„Pumpvorgänge: N · Nullpunktkal. in M"**.
- **Phasen L1/L2/L3** — Strom (A), Spannung (V), Leistung (W) und die
  **Gesamtleistung**.
- **Verlaufsdiagramm** — Pegel, Ströme, Spannungen, Temperaturen. Über die
  Knöpfe **1 h / 6 h / 24 h / 50 h / 7 T** zoomen; auf einen Legendeneintrag
  klicken blendet die Kurve aus/ein.
- Fußzeile: **AUTO / EIN / AUS**.
- Kopfzeile: **MODUS**, **ZYKLUS**, Uhrzeit, **📄** (Bericht), **⛶** (Vollbild).

### 13.3 Mehrkanal-Kiosk (Aufbau 2)

![Mehrkanal-Kiosk: je Behälter eine Kachel mit Füllstand, Balken, Volumen und Durchsatz](bilder/mehrkanal-kiosk.png)

Unter **`/aufbau2-kiosk`** (in der Sitemap „Mehrkanal_Kiosk"): je Behälter eine
Kachel mit Füllstand, Füllbalken, Volumen, Gefüllt/Durchsatz und der
Leckage-Markierung; oben die Auswertezeitraum-Auswahl, unten die Summen und die
Nullen-Knöpfe (siehe [12.2](#122-sepwatch-aufbau-2--mehrere-behälter-leckage)).

### 13.4 Fluss-Kiosk (Aufbau 1)

![Fluss-Kiosk: Gewässerquerschnitt mit blauer Wasserfläche, Pegel, Querschnittsfläche, Durchfluss und Pegelverlauf](bilder/fluss-kiosk.png)

Unter **`/fluss-kiosk`** (in der Sitemap „Fluss_Kiosk"): die Ansicht für eine
**Messstelle in einem Bach oder Fluss**, im selben Layout wie der
Hebewerk-Kiosk und ebenfalls für **1024×600** ausgelegt.

**Links: der Querschnitt.** Das in der Konfiguration hinterlegte Profil des
Gewässers wird maßstäblich gezeichnet, der aktuelle Wasserstand als **blaue
Fläche** darin. Ist noch **kein Querschnitt** hinterlegt, zeichnet die Seite
ein **symbolisches Trapez** und schreibt „symbolisch" dazu — die Anzeige bleibt
also auch an einer frisch aufgebauten Messstelle ablesbar.

**Rechts: die Zahlen.**
- **Pegel** in mm (groß),
- **Querschnittsfläche** in m² — die vom Wasser benetzte Fläche,
- **Durchfluss** in l/s (ab 1.000 l/s in m³/s),
- **Fließgeschwindigkeit** in m/s.

Fläche und Durchfluss bleiben grau („—"), solange kein Querschnitt bzw. keine
Fließgeschwindigkeit hinterlegt ist (siehe
[9.6](#96-gewässer-querschnitt-für-den-durchfluss)).

**Darunter: der Pegelverlauf** als Diagramm, umschaltbar auf 1 h / 6 h / 24 h /
7 Tage. Die Werte kommen aus der InfluxDB — ohne Datenbank bleibt das Diagramm
leer.

**In der Fußzeile:** die Auswahl der Messstelle (bei mehreren Sensoren), die
Wasserspiegelbreite, die Sensorspannung und ob der Messwert gültig ist.

### 13.5 Das Betriebstagebuch im Kiosk (📜)

**In jedem Kiosk** gibt es in der Kopfzeile den Knopf **📜**. Er klappt von
unten das **Betriebstagebuch** auf: die letzten Ereignisse der Anlage, das
Neueste oben — Pumpenläufe, Alarme, Zwangsabschaltungen, Nullungen,
Konfigurationsänderungen, Dienststarts.

Jede Zeile ist **nach ihrem Inhalt eingefärbt**:

| Farbe | Bedeutung |
|---|---|
| 🔴 rot | Alarm — Hochwasser, Überstrom, Leckage, Phasenausfall, Fehler |
| 🟡 gelb | Warnung — Zwangsabschaltung, Maximallaufzeit, abgebrochene Kalibrierfahrt |
| 🟢 grün | Entwarnung — Alarm aufgehoben |
| 🔵 blau | Pumpenlauf |
| 🟣 violett | Bedienhandlung — Konfiguration gespeichert, Bericht erstellt, Nullung |
| ⚪ grau | System — Dienst gestartet/beendet |

Der Knopf **📜 färbt sich rot**, sobald Einträge mit Alarmbezug im Tagebuch
stehen — so ist auch bei zugeklapptem Fenster sichtbar, dass etwas vorgefallen
ist. Solange das Fenster offen ist, aktualisiert es sich alle 15 Sekunden;
**Schließen** oder die **Esc**-Taste klappt es wieder zu.

### 13.6 Vollbild und PDF-Knopf in allen Kiosks

Weil an einem Kiosk-Bildschirm kein Keyboard hängt (kein F11/ESC), gibt es in
der Kopfzeile:
- **⛶ Vollbild ein/aus** — schaltet den Vollbildmodus um.
- **📄** — öffnet das Popup für den Betriebsbericht (siehe
  [Kapitel 16](#16-berichte)).
- **📜** — klappt das Betriebstagebuch auf (siehe
  [13.5](#135-das-betriebstagebuch-im-kiosk-)).
- **⏻** — fährt die Anlage geordnet herunter (siehe
  [13.7](#137-die-anlage-geordnet-herunterfahren-)).

### 13.7 Die Anlage geordnet herunterfahren (⏻)

**Ziehen Sie nie einfach den Stecker.** Der Raspberry Pi schreibt laufend in
seine Messdatenbank; wird er mitten im Schreiben stromlos, kann die Datenbank
beschädigt zurückbleiben und die Anlage startet danach nicht mehr sauber.

Deshalb gibt es in **jedem Kiosk** oben den Knopf **⏻**:

1. **⏻** antippen → es erscheint eine rote Sicherheitsabfrage mit dem Hinweis,
   dass die Anlage danach nur noch **vor Ort** eingeschaltet werden kann.
2. **„Jetzt herunterfahren"** antippen. (**„Abbrechen"** oder die **Esc**-Taste
   schließen die Abfrage folgenlos.)
3. Der Bildschirm zeigt **„Die Anlage fährt herunter …"**.
4. **Warten, bis die grüne Leuchtdiode am Raspberry Pi dauerhaft aus ist** —
   **erst dann** darf die Stromversorgung getrennt werden.

Beim Herunterfahren beendet das Betriebssystem zuerst alle Dienste sauber: Die
Pumpensteuerung fährt die Relais in den sicheren Zustand, Zählerstände werden
gespeichert und die Datenbank ordentlich geschlossen.

**Am 7-Segment-Display** (falls angeschlossen) sehen Sie den Fortschritt:

| Anzeige | Bedeutung |
|---|---|
| umlaufender **Ladekreis** | Die Anlage fährt gerade herunter — **noch nicht** ausschalten. |
| **`AUS`** | Fertig. Jetzt darf die Stromversorgung getrennt werden. |

Das `AUS` erscheint erst im allerletzten Moment, nachdem alle Dateisysteme
sauber ausgehängt sind. Es bleibt stehen, bis der Strom wirklich weg ist.

### 13.8 Herunterfahren aus der Ferne (Cloud-Frontend)

Auf der Anlagenseite im Cloud-Frontend gibt es denselben Befehl. Er ist dort
**bewusst umständlicher**, weil Sie in diesem Fall meist **nicht** vor der
Anlage stehen:

1. Ein Haken bestätigt, dass Ihnen bewusst ist, dass die Anlage danach **nur vor
   Ort** wieder eingeschaltet werden kann.
2. Sie müssen **`HERUNTERFAHREN`** eintippen (wird auch auf dem Server geprüft).
3. Eine letzte Rückfrage erscheint.

Danach wird der Befehl **eingereiht** — die Anlage holt ihn beim nächsten
Kontakt (typischerweise innerhalb einer Minute) und fährt dann herunter.
Solange er noch nicht geholt wurde, können Sie ihn in der Auftragsliste
abbrechen.

> ⚠️ **Bitte vorher klären, wer die Anlage wieder einschaltet.** Ein Raspberry Pi
> lässt sich **nicht** aus der Ferne starten — es gibt kein Wake-on-LAN. Nach dem
> Herunterfahren gibt es keine Messwerte, keine Alarm-E-Mails und keinen
> Fernzugriff mehr, bis jemand vor Ort den Strom aus- und wieder einschaltet.

> 💡 Kommt stattdessen eine **rote Fehlermeldung**, konnte das Abschalten nicht
> ausgelöst werden — meist fehlt dem Dienst die Berechtigung dafür (siehe
> `docs/01-installation.md`, Abschnitt zu `sudo`). Die Anlage läuft dann
> unverändert weiter.

---

## 14. Grafana

**Grafana** ist die Diagramm-Anzeige auf dem Pi. Sie öffnen sie im Browser unter
`http://<IP-des-Pi>:3000` und finden im Ordner **„PegelWatch"** drei fertige
**Dashboards** (Diagramm-Sammlungen), je eines pro Aufbau. Details:
[docs/03-grafana.md](03-grafana.md).

- **Zeitbereich wählen:** oben rechts stellen Sie ein, welchen Zeitraum die
  Diagramme zeigen (z. B. „Last 6 hours").
- **Aufbau 3 – Pumpe aus Grafana schalten:** Grafana kann selbst **keine**
  Befehle an die Anlage senden. Das Dashboard **verlinkt** deshalb auf die
  PUMPWatch-Bedienung (Panel „Pumpensteuerung öffnen" / Dashboard-Link →
  `/pump-kiosk`). Betriebsmodus und Laufzustand zeigt es live aus der Datenbank.
  Sollte der Link auf die falsche Adresse zeigen, passen Sie die
  Dashboard-Variable **`pegelwatch_url`** an.

> 💡 Die Dashboards werden bei **jedem** Deploy automatisch mit auf den Pi
> gezogen und aktualisiert — Sie müssen nichts von Hand importieren.

---

## 15. Alarme und E-Mail

Die Anlage schickt **Warn-E-Mails**, wenn etwas Ungewöhnliches passiert.

### 15.1 SMTP-Zugang eintragen

„SMTP" ist der Postausgangs-Server für E-Mails. Im Abschnitt **„E-Mail (SMTP)"**:

1. **Host** (z. B. `smtp.gmail.com`), **Port** (**587** = STARTTLS üblich, 465 =
   direktes TLS), **Absender**, **Empfänger** (mehrere mit Komma), ggf.
   **Benutzername**.
2. **Passwort** eintragen und über **🔑 Zugangsdaten speichern** ablegen (landet
   getrennt in `secrets.toml`, wird nie exportiert).
3. Auf **✉ Testmail versenden** klicken.
   → **Erfolg:** grüne Meldung „Testmail versendet — bitte Posteingang der
   Empfänger prüfen." Kommt keine Mail an, prüfen Sie Host/Port/Passwort (die
   Fehlermeldung nennt oft die Ursache).

> 💡 **HELO-Name.** Meldet Ihr Server „550 Invalid HELO name", tragen Sie im
> Feld **„HELO-Name"** einen gültigen Namen (FQDN) ein. Leer = die Anlage
> verwendet die eigene IP.

### 15.2 Welche Alarme es gibt

| Alarm | Aufbau | Auslöser |
|---|:---:|---|
| **Hochwasser** | alle | Pegel über der Schwelle |
| **Niedrigwasser** | alle | Pegel unter der Schwelle |
| **Leckage** | 2 | Pegel fällt steiler als der erwartete Entleer-Gradient |
| **Überstrom / Unterstrom** | 3 | Pumpenstrom zu hoch bzw. Phasenausfall (auch als Relais) |
| **Luft / Trockenlauf** | 3 | Pumpenleistung fällt unter die Abschaltschwelle (Zwangsstopp) |
| **Max. Laufzeit** | 3 | Pumpe lief zu lange am Stück (Zwangsstopp) |

**Schwellen einstellen:** je Sensor in der Sensorkarte (Block „Alarme dieses
Sensors": Hochwasser/Niedrigwasser aktiv + Wert, Leckage-Gradient). Für Sensoren
**ohne** eigene Werte gibt es globale Rückfall-Schwellen im E-Mail-Abschnitt.

> 💡 Ein **Relaisausgang** als Alarmkanal existiert **nur in Aufbau 3**. In
> Aufbau 1/2 wird ausschließlich per E-Mail alarmiert. Nach einem Alarm folgt
> automatisch eine **Entwarnung**, sobald wieder alles normal ist (mit einer
> kleinen Hysterese, damit es nicht flattert).

---

## 16. Berichte

Die Anlage erstellt einen **PDF-Betriebsbericht** — aufgebaut wie ein
**Lagebericht für eine Einsatzleitung** (Kurzlage, Allgemeine/Eigene Lage,
Schadenslage mit Trend und Prognose, je Messstelle eine Seite, Bilanzen,
Einsatztagebuch). Vollständige Beschreibung: [docs/07-lagebericht.md](07-lagebericht.md).

### 16.1 Sofort einen Bericht erstellen

**Weg A — aus dem Kiosk:** Klicken Sie in der Kopfzeile auf **📄**. Im Popup
wählen Sie **Bilanzzeitraum (Stunden)** und **Empfänger**, dann:
- **Erstellen & Senden** — erstellt das PDF und schickt es per E-Mail.
- **Nur erstellen** — legt das PDF nur ab.

**Weg B — Seite „Berichte"** (`/berichte`): Knopf **„＋ Bericht jetzt
erstellen"**, Zeitraum und Empfänger wählen.
→ **Erfolg:** „Bericht erstellt …". Der neue Bericht taucht in der Liste auf.

### 16.2 Automatischer täglicher Versand

Im Abschnitt **„Betriebsbericht (PDF)"** stellen Sie **Standard-Empfänger**,
**tägliche Uhrzeit** (`HH:MM`, leer = kein Auto-Versand) und **Bilanzzeitraum**
(Standard 24 h) ein.

### 16.3 Alle Berichte ansehen

Auf **`/berichte`** stehen alle Berichte mit Erstellzeit, Zeitraum, Auslöser,
Empfängern und einer **Prüfsumme (SHA-256)** — daran ist erkennbar, ob ein PDF
nachträglich verändert wurde. Klick auf **„📄 öffnen"** zeigt das PDF. Berichte
werden **180 Tage** aufbewahrt.

> 💡 Die PDF-Erzeugung nutzt das auf dem Pi vorhandene **Chromium** (im
> Hintergrund, ohne Fenster). Fehlt es, hilft `sudo apt install chromium`.

---

## 17. Cloud-Frontend — die Anlage von unterwegs sehen

Optional gibt es ein **öffentliches Frontend** (`https://pegelwatch.gatecs.de`),
das den Status **aller** Anlagen an einer Stelle zeigt — hinter einer richtigen
Anmeldung. Die Anlagen stehen hinter dem heimischen Router (NAT): Es gibt
**keinen** Weg von außen hinein. Deshalb gilt: **Der Pi meldet sich immer selbst
nach außen** (ausgehende Verbindung), das Frontend ruft den Pi nie an.

### 17.1 Am Pi aktivieren

Im Abschnitt **„Cloud-Frontend"** der Konfiguration:
1. **Aktiv** anhaken, **Frontend-URL** eintragen (muss mit `https://` beginnen),
   optional **Anlagenkennung (slug)** und **Melde-Intervall** (Standard 60 s).
2. Das **Enrollment-Token** (gemeinsames Anmeldegeheimnis) eintragen und über
   **🔑 Zugangsdaten speichern** ablegen.
3. **🔄 Dienst neu starten**.
   → **Erfolg:** Auf der Startseite erscheint die Kachel „Cloud-Frontend" mit
   „● erreichbar" bzw. „● wartet auf Freigabe durch den Admin".

### 17.2 Freigabe und Bedienung

Ein neuer Pi meldet sich **selbst** an und ist zunächst **„pending"**. Ein
**Admin** gibt ihn im Frontend frei; danach ist die Anlage online sichtbar. Im
Frontend gibt es Registrierung/Login, Rechte je Nutzer (nur sehen / sehen +
steuern) und je Anlage eine Detailseite mit Sensor-Tabelle.

Was **live und geprüft** ist: Statusübersicht, Detailseite, Erreichbarkeits­anzeige,
Mehrbenutzer mit Rechten, **Config-Backup** (der Pi sichert seine
geheimnisfreie `config.toml` im Frontend).

> ⚠️ **Noch nicht abschließend geprüft.** Die Befehle **„Erstelle Bericht"**
> (samt Kiosk-Momentaufnahme), **„Update"** (Selbst-Aktualisierung des Binaries)
> und **„Systemupdate"** (Betriebssystem) sind zwar programmiert, aber laut
> [docs/08-cloud-frontend.md](08-cloud-frontend.md) **auf dem Pi noch nicht
> verifiziert**. Behandeln Sie diese Funktionen als „in Erprobung", nicht als
> fertig zugesichert.

Alle Details und der genaue Umsetzungsstand: [docs/08-cloud-frontend.md](08-cloud-frontend.md).

---

## 18. Alltag und Wartung

### 18.1 Konfiguration sichern und übertragen

**⬇ Exportieren** speichert Ihre `config.toml` als Datei (gute Sicherung).
**⬆ Importieren** lädt sie wieder ein. **Zugangsdaten reisen nie mit.** Beim
Import auf andere Hardware warnt die Anlage wegen der gerätespezifischen
Kalibrierung.

### 18.2 Software aktualisieren

Neues Programm bauen und aufspielen — **ohne** die Einstellungen anzutasten:
```powershell
.\deploy.ps1 -PiHost 192.168.0.106
```
Ein normales Deploy tauscht nur das Binary; `config.toml`, `secrets.toml` und
`state.db` bleiben. Prüfen Sie danach im Systemstatus „Software gebaut" — der
Zeitstempel sollte neu sein.

### 18.3 Dienst neu starten

Über die Konfigurationsseite: **🔄 Dienst neu starten** (Rückfrage bestätigen).
Die Anlage fährt geordnet herunter (in Aufbau 3 geht die Pumpe dabei kurz in den
sicheren Aus-Zustand), systemd startet sie automatisch neu, die Seite verbindet
sich selbst wieder. Auf dem Pi ginge es auch mit
`sudo systemctl restart pegelwatch`.

### 18.4 Verdrahtungstest der Relaisausgänge (Aufbau 3)

Nach der Montage prüfen, ob das richtige Relais klickt: Abschnitt
**„Verdrahtungstest der Relaisausgänge"**. Je Ausgang (Pumpe, Alarm, Pneumatik,
Logik) gibt es ein Kästchen, das das Relais **sofort** schaltet.

> ⚠️ Am Ausgang hängt echte Last! Stellen Sie vorher sicher, dass ein Anlaufen
> **gefahrlos** ist. Das **Pumpenrelais** lässt sich nur schalten, wenn die
> Pumpensteuerung auf **„Aus"** steht. Der rote Knopf **„⏻ Alle Ausgänge sofort
> aus"** schaltet im Zweifel alles ab. Die Automatik behält jederzeit die
> Oberhand und setzt ihren Ausgang beim nächsten Takt wieder.

### 18.5 Pneumatikpumpe (Drift-Kompensation)

Die **Pneumatikpumpe** drückt in festen Abständen Luft in die Sensorschläuche,
damit der Nullpunkt nicht wegdriftet. Im Abschnitt **„Pneumatikpumpe (alle
Aufbauten)"** stellen Sie **Intervall** (z. B. 3600 s) und **Laufzeit** (z. B.
30 s) ein. In Aufbau 1/2 läuft sie über eine eigene **GPIO-Leitung** (Standard
GPIO17), in Aufbau 3 über den Relaiskanal Pneumatik (CH3).

### 18.6 Werksreset

**⚠ Konfiguration auf Werkszustand zurücksetzen** (im roten Abschnitt
„Werksreset") setzt **nur die Konfiguration** auf Standardwerte zurück —
Zugangsdaten in `secrets.toml` bleiben erhalten.

> ⚠️ Folgenreich und nicht umkehrbar. Deshalb doppelt abgesichert: erst
> Rückfrage, dann müssen Sie **`WERKSRESET`** eintippen. Nur ausführen, wenn Sie
> wirklich bei Null anfangen wollen.

### 18.7 So entsteht diese Anleitung (für technisch Interessierte)

Diese Bedienungsanleitung wird **auf Anforderung** neu erzeugt: Hängen Sie
**`-BuildManual`** an `build.ps1`, `deploy.ps1` oder `deploy-fleet.ps1` an, zum
Beispiel `.\deploy.ps1 -PiHost 192.168.0.106 -BuildManual`. Das übernimmt dann
`tools/build-manual.ps1`:
1. Es startet kurz die **echte Weboberfläche** in einem reinen Testsensor-Betrieb
   (ohne Hardware) und macht mit einem headless-Browser **Screenshots** der
   Seiten nach `docs/bilder/`.
2. Es rendert `docs/bedienungsanleitung.md` zu **`docs/bedienungsanleitung.html`
   und `.pdf`**.

Weil die fertigen Dateien unter `docs/` liegen, zieht `deploy.ps1` sie **bei
jedem** Deploy mit auf den Pi (nach `/usr/local/share/pegelwatch`) — auch dann,
wenn sie in diesem Lauf nicht neu erzeugt wurden. Der Schritt ist
**nicht-fatal**: fehlt ein Werkzeug, gibt es nur eine Warnung, der Bau läuft
weiter.

> 💡 Warum nicht bei jedem Bau? Der Generator startet die echte Weboberfläche,
> fotografiert sie mit einem Browser und rendert HTML und PDF — das dauert um ein
> Vielfaches länger als das Bauen der Software selbst. Deshalb läuft er nur mit
> `-BuildManual`. Ziehen Sie die Anleitung nach, wenn Sie die Weboberfläche oder
> `docs/bedienungsanleitung.md` geändert haben.

---

## 19. Wenn etwas nicht geht (Störungshilfe / FAQ)

| Symptom | Wahrscheinliche Ursache | Was tun |
|---|---|---|
| **Weboberfläche nicht erreichbar** | Falsche Adresse; Pi/Dienst aus; anderes Netz | Adresse `http://<IP>:8080/` prüfen. Pi eingeschaltet? Auf dem Pi: `sudo systemctl status pegelwatch`. |
| **Ein Dienst rot im Live-Server-Status** | Dienst nicht gestartet/erreichbar | Im **Systemstatus → Abhängigkeiten** steht der Installations-/Startbefehl. Adresse (URL/Port) des Dienstes prüfen. |
| **Keine Messwerte / Sensor „—"** | Board nicht gefunden; falsche Adresse/Kanal; nicht kalibriert | „Gefundene Hardware" prüfen — steht dort Ihre Adresse (`0x48`…)? Board-Adresse/Kanal in der Sensorkarte korrigieren. Sensor **kalibriert**? |
| **InfluxDB startet nicht (nach Stromausfall)** | Harter Reboot hinterließ leere Katalog-/WAL-Dateien → Startschleife | Meist heilt die gehärtete Unit selbst. Sonst: `sudo systemctl reset-failed influxdb3 && sudo systemctl start influxdb3`. **Reboots immer geordnet** (`sudo reboot`), nie hart am Stecker. Details: [docs/07-lagebericht.md](07-lagebericht.md), [docs/01-installation.md](01-installation.md). |
| **Keine E-Mails** | SMTP falsch; Passwort fehlt | **✉ Testmail versenden** klicken und die Fehlermeldung lesen. „not permitted to relay" = meist Passwort/Benutzername falsch. Nach einem Fehlversuch wartet die Anlage 5 min bis zum nächsten Versuch. |
| **Shelly nicht gefunden** | Nicht im selben /24-Netz; anderes Modell | **🔍 Netz durchsuchen** erneut; Shelly-Erreichbarkeit prüfen; URL notfalls von Hand eintragen. |
| **Kiosk-Bildschirm bleibt schwarz** | Kiosk-Browser läuft nicht; Auflösung | Kiosk-Seite von einem anderen Gerät testen (`http://<IP>:8080/pump-kiosk` bzw. `/aufbau2-kiosk`). HDMI-Display auf **1024×600**? |
| **Pumpe läuft nicht an (Aufbau 3)** | Modus „Aus"; Schwellen; Zwangs-Sperre nach Max-Laufzeit | Modus auf **AUTOMATIK**? Pegel über „Pegel EIN"? Nach Zwangsabschaltung ggf. bewusster Moduswechsel nötig. |
| **Änderung wirkt nicht** | Nur gespeichert, nicht neu gestartet | Nach Sensor-/GPIO-/I²C-Änderungen **🔄 Dienst neu starten**. |

Logs ansehen (auf dem Pi): `sudo journalctl -u pegelwatch -f`.

---

## 20. Glossar

- **AD-Wandler (ADS1115)** — wandelt die analoge Sensorspannung in eine Zahl um.
- **Aufbau** — eine der drei Ausbaustufen (1 = PEGELWatch, 2 = SEPWatch,
  3 = PUMPWatch).
- **Binary** — das fertig gebaute Programm (eine Datei), das auf dem Pi läuft.
- **Cross-Compile** — auf Windows ein Programm für den Pi (arm64) bauen.
- **Dashboard** — eine Diagramm-Sammlung in Grafana.
- **Deployment** — das Aufspielen der Software auf den Pi.
- **Fail-Safe** — der definierte sichere Zustand bei Ausfall (Relais fällt ab,
  Pumpe stoppt).
- **GPIO** — die Anschluss-Pins des Pi zum Schalten/Messen.
- **Grafana** — die Diagramm-Anzeige (Port 3000).
- **HAT** — eine Aufsteck-Platine für den Pi (hier die Relaiskarte).
- **I²C-Bus** — die Datenleitung zu den Messplatinen (Leitungen SDA/SCL).
- **InfluxDB** — die Zeitreihen-Datenbank für den Messwert-Verlauf (Port 8086).
- **Kalibrieren** — dem Programm beibringen, welche Spannung welcher Höhe
  entspricht.
- **Kiosk** — die bildschirmfüllende Betriebsansicht (1024×600).
- **Polling** — das regelmäßige Abfragen des Sensors (adaptiv: schnell/langsam).
- **Ratiometrische Kompensation** — Spannungsschwankungen werden über einen
  mitgemessenen Referenzkanal herausgerechnet.
- **Relaiskarte** — schaltet über potenzialfreie Kontakte externe Lasten
  (Aufbau 3).
- **Shelly 3EM** — ein Netzwerk-Strommessgerät (drei Phasen, Aufbau 3).
- **SMTP** — der Postausgangs-Server für E-Mails.
- **SSH** — Fernzugriff auf den Pi über ein Terminal.
- **Stützstelle** — ein Kalibrierpunkt (Wasserstand ↔ Spannung).
- **systemd / Dienst** — verwaltet das automatische Starten der Software;
  `Restart=always` startet sie nach Absturz neu.
- **Testsensor / Simulation** — ein rechnerisch erzeugter Sensor zum Üben ohne
  Hardware.
- **7-Segment-Display** — die kleine rote Zahlenanzeige (nur Pegel).

---

## 21. Kurz-Spickzettel

**Adressen**
- Startseite: `http://<IP>:8080/` · Konfiguration: `…/konfiguration` ·
  Handbuch: `…/handbuch` · Berichte: `…/berichte`
- Hebewerk-Kiosk (Aufbau 3): `…/pump-kiosk` · Mehrkanal-Kiosk (Aufbau 2):
  `…/aufbau2-kiosk`
- Grafana: `http://<IP>:3000`

**Die wichtigsten Handgriffe**
- Speichern → immer über **💾 Speichern** oben; danach bei Sensor-/GPIO-/I²C-
  Änderungen **🔄 Dienst neu starten**.
- Pumpe (Aufbau 3): im Zweifel **AUTOMATIK**.
- Behältersummen (Aufbau 2) nullen: **BEHÄLTERSUMMEN NULLEN** (einzeln) /
  **ALLE SUMMEN NULLEN** (alle).
- Bericht sofort: **📄** im Kiosk oder **＋ Bericht jetzt erstellen** unter
  `/berichte`.
- E-Mail testen: **✉ Testmail versenden**.
- Shelly finden: **🔍 Netz durchsuchen** → **✓ übernehmen**.
- Vollbild am Kiosk: **⛶**.

**Sicherheits-Merksätze**
- Netzspannung/Drehstrom nur durch eine Elektrofachkraft.
- Kalibrierung löschen/übernehmen und Werksreset verlangen bewusst eine
  getippte Bestätigung — nur eingeben, wenn Sie es wirklich wollen.
- Reboots geordnet (`sudo reboot`), nie hart am Stecker (schützt die Datenbank).
- Ein normales Update überschreibt Ihre Einstellungen und Kalibrierung **nie**.

**Bei Störung**
1. Startseite → Live-Server-Status (was ist rot?).
2. Konfiguration → Systemstatus (Hardware gefunden? Abhängigkeiten?).
3. Auf dem Pi: `sudo journalctl -u pegelwatch -f`.
4. Sonst: [Kapitel 19](#19-wenn-etwas-nicht-geht-störungshilfe--faq).

---

*Diese Bedienungsanleitung wird mit `-BuildManual` neu erzeugt
(`tools/build-manual.ps1`) und gegen den Stand der Software abgeglichen.
Entwickler-Dokumentation: Ordner [docs/](.). Verbindlich sind bei Abweichungen
die Weboberfläche und der Quellcode.*

