# PegelWatch — Testsensor (Simulation ohne Messhardware)

Der Testsensor ist ein Sensor, der **wie ein normaler Drucksensor konfiguriert
wird** (Kalibrierung, Behältergeometrie, Alarme), seinen Pegel aber **rein
rechnerisch erzeugt** — es wird keine ADS1115-/I²C-Hardware angesprochen.

**Zweck:** Die komplette Funktionalität der Anwendung auf einem Raspberry Pi
prüfen, **ohne** Sensorplatine, ADS1115-Boards oder Drucksensoren
anzuschließen. Der Testsensor durchläuft denselben Signalweg wie ein echter
Sensor:

- adaptives Polling (SLOW/FAST-Umschaltung, §4),
- Kalibrierung (Spannung → Pegel, inkl. Fit-Anzeige),
- Volumen-/Durchsatzberechnung mit Behältergeometrie,
- Alarme (Hochwasser, Niedrigwasser, Leckage-Gradient) inkl. E-Mail,
- InfluxDB-Schreibpfad und Grafana-Dashboards,
- Startseite, Kiosk-Ansichten, 7-Segment-Display,
- Pumpensteuerung in Aufbau 3 (der Testsensor kann Primärsensor sein).

---

## Konfiguration

Ein Testsensor ist ein normaler `[[sensor]]`-Eintrag mit einem zusätzlichen
`[sensor.simulation]`-Block:

```toml
[[sensor]]
id   = "test1"
name = "Testsensor"

[sensor.simulation]
enabled      = true    # macht diesen Sensor zum Testsensor
mean_mm      = 1000.0  # Grundpegel (Startwert)
amplitude_mm = 800.0   # Sinus-Amplitude um den Grundpegel; 0 = konstant
period_s     = 300     # Dauer eines vollen Sinus-Zyklus (Standard: 300)

[[sensor.calibration]]
water_mm = 0.0
volts_mv = 210.0

[[sensor.calibration]]
water_mm = 5097.0
volts_mv = 4520.0
```

Der simulierte Pegel folgt der Formel:

```
Pegel(t) = Grundpegel + amplitude_mm · sin(2π · t / period_s)
```

begrenzt auf den physikalischen Bereich des MPXV5050DP (0 … 5097 mm).

**Eigenschaften:**

- `board_addr`, `channel`, `ref_channel` werden **ignoriert** und dürfen ganz
  weggelassen werden. Ein Testsensor belegt **kein Kanalbudget** — er darf
  neben 16 echten Kanälen existieren.
- Die **Kalibrierung wirkt wie beim echten Sensor**: aus dem simulierten Pegel
  wird über die *inverse* Kennlinie die Spannung (mV) berechnet, die dann den
  normalen Weg Spannung → Kalibrierung → Pegel durchläuft. Ohne Kalibrierung
  liefert der Testsensor (wie ein echter Sensor) nur Rohspannung und keine
  gültigen Pegelwerte.
- Sind **alle** aktiven Sensoren Testsensoren, startet die Anwendung auch ganz
  ohne I²C-Bus (reiner Simulationsbetrieb, z. B. auf einem nackten Pi).

---

## Warum ein Sinus?

Die adaptive Abtastung (§4) schaltet bei schnellen Pegeländerungen auf 250 ms
und bei konstantem Signal zurück auf 20 s. Beim Sinus ändert sich die
**Änderungsgeschwindigkeit kontinuierlich**: am Scheitel ist sie 0, am
Nulldurchgang maximal. Man kann daher im Log bzw. an der Messwertdichte in
Grafana direkt beobachten, **bei welcher Signalsteilheit** die Umschaltung
SLOW → FAST (und zurück) erfolgt — und die Schwellwerte `jump_pct`,
`jump_abs_mm`, `stable_window`, `stable_pct` gezielt abstimmen.

Faustformel für die maximale Steilheit des Sinus:

```
max. Änderungsrate ≈ 2π · amplitude_mm / period_s   [mm/s]
```

Beispiel: `amplitude_mm = 800`, `period_s = 300` → max. ≈ 16,8 mm/s.

---

## Schieberegler (Live-Steuerung)

Auf der Konfigurationsseite (`/konfiguration`) erscheint bei laufenden
Testsensoren der Abschnitt **„Testsensor-Steuerung"**:

- Ein **Schieberegler pro Testsensor** verschiebt den Grundpegel sofort — der
  konfigurierte Sinus schwingt um den neuen Wert weiter.
- Daneben wird der aktuell simulierte Pegel live angezeigt.
- Damit lassen sich gezielt **Alarmschwellen** überfahren (Hochwasser,
  Niedrigwasser), in Aufbau 3 die **Pumpenschwellen** (`on_level_mm`,
  `off_level_mm`) auslösen oder in Aufbau 2 durch schnelles Herunterziehen ein
  **Leckage-Alarm** provoziert werden.
- Schieberegler-Änderungen werden **nicht gespeichert** — nach einem Neustart
  gilt wieder `mean_mm` aus der Konfiguration.

API-Endpunkte (für Skripte/Tests):

```
GET  /api/sim                    # laufende Testsensoren + aktueller Grundpegel
POST /api/sim/level              # Form-Parameter: sensor=<ID>, level_mm=<Zahl>
```

---

## Typische Testszenarien

| Szenario | Konfiguration |
|---|---|
| Abtastumschaltung beobachten | `amplitude_mm > 0`, Periode variieren; Messwertdichte in Grafana ansehen |
| Alarm-Mails testen | `amplitude_mm = 0`, Schieberegler über `high_water_mm` ziehen |
| Pumpensteuerung (Aufbau 3) testen | Testsensor als ersten (Primär-)Sensor eintragen, Schieberegler über `on_level_mm` / unter `off_level_mm` ziehen |
| Leckage-Erkennung (Aufbau 2) testen | `leakage_alarm_enabled = true`, kleinen `max_drain_gradient_mm_per_s` setzen, Schieberegler schnell nach unten ziehen |
| Volumen/Durchsatz prüfen | Behältergeometrie am Testsensor konfigurieren, Sinus laufen lassen — Füll-/Durchsatzsummen wachsen zyklisch |
| Betrieb ganz ohne Hardware | alle Sensoren mit `simulation.enabled = true` — I²C wird nicht benötigt |

---

## Abgrenzung

Der Testsensor prüft die **Software-Kette**, nicht die Elektronik: I²C-Bus,
ADS1115, Analog-Front-End und ratiometrische Kompensation werden **nicht**
ausgeübt (die simulierten ADC-Rohwerte sind plausibel nachgebildet). Für die
Hardware-Inbetriebnahme bleibt der I²C-Scan im Systemstatus der
Konfigurationsseite das richtige Werkzeug.
