# PegelWatch — Installation

## Schnellweg: Installation mit einem Befehl (empfohlen)

Auf einem frisch eingerichteten **Raspberry Pi OS 64 bit** (Pi 4/5), als der
Benutzer, der später am Bildschirm angemeldet ist:

```bash
curl -fsSL https://gsandreas.github.io/pegelwatch-dist/install.sh | sudo sh
```

Das Skript richtet Grafana und InfluxDB 3 ein (`setup/pi-base-setup.sh`),
trägt die **signierte PegelWatch-Paketquelle** ein (prüft den Fingerprint
`811C 0B63 D3FB FEDA 059C 008F 5CFB FAA9 8605 8508`), installiert das Paket
`pegelwatch`, aktiviert I²C/SPI und legt Datenbank, Token und
Grafana-Datenquelle an. Danach die Anlage im Browser konfigurieren:
`http://<IP-des-Pi>:8080/konfiguration`.

Optionen (hinter `sudo sh -s --`): `--channel daily` (Testanlage),
`--user NAME` (anderer Dienstbenutzer), `--no-base` (ohne Grafana/InfluxDB).
Die 4-KB-Seitengröße (siehe unten) muss vorher eingestellt sein, sonst startet
InfluxDB nicht.

Updates kommen danach über den **Release-Kanal** (stable/daily, Konfiguration
→ Cloud-Frontend) — siehe [08-cloud-frontend.md](08-cloud-frontend.md). Die
folgenden Abschnitte beschreiben die Einzelschritte und den SSH-Deploy vom
Entwicklungsrechner (`deploy.ps1`), der dasselbe Paket installiert.

## Voraussetzungen

### Hardware

| Komponente | Anforderung |
|---|---|
| Einplatinenrechner | Raspberry Pi 4 oder Pi 5, **≥ 4 GB RAM empfohlen** (siehe InfluxDB-Hinweis unten) |
| Betriebssystem | Raspberry Pi OS **Bookworm, 64-bit (arm64)** |
| Drucksensor | MPXV5050DP (0–50 kPa, max. Pegelstand 5,09 m) |
| ADC | ADS1115 (16-bit, I²C, Adresse 0x48–0x4B) |
| Referenzspannung | LT1461 5,0 V (ratiometrische Kompensation) |
| Display (optional) | MAX7219CWG + 4-stellige 7-Segment-Anzeige, zeigt nur den Pegel |
| Display (optional, Kiosk) | Waveshare HDMI-Display, 1024×600 |
| Shelly 3EM (nur Aufbau 3) | Gen 1 oder Gen 2 |
| Relaisplatine (nur Aufbau 3) | 3-Kanal, 3,3-V-kompatibel |

### 4-KB-Speicherseitengröße erzwingen (Pflicht für InfluxDB 3 Core)

InfluxDB 3 Core stürzt auf manchen Raspberry-Pi-Kerneln mit 16-KB-Seitengröße
(insbesondere Pi 5) beim Start ab. Erzwinge daher **immer** den klassischen
4-KB-Kernel:

```bash
echo "kernel=kernel8.img" | sudo tee -a /boot/firmware/config.txt
sudo reboot
```

> Auf älteren Raspberry Pi OS Versionen liegt `config.txt` unter `/boot/config.txt`
> statt `/boot/firmware/config.txt` — prüfe, welcher Pfad existiert.

### Rückfall auf InfluxDB 2.x (Pi 4 mit nur 2 GB RAM)

InfluxDB 3 Core ist auf einem Pi 4 mit 2 GB RAM grenzwertig. In diesem Fall
statt InfluxDB 3 Core **InfluxDB 2.9.1** installieren (aktuelle 2.9.x-Version
zum Zeitpunkt dieser Doku — vor der Installation auf
[github.com/influxdata/influxdb/releases](https://github.com/influxdata/influxdb/releases)
prüfen, ob es eine neuere 2.9.x-Patch-Version gibt):

```bash
wget https://dl.influxdata.com/influxdb/releases/influxdb2-2.9.1-arm64.deb
sudo dpkg -i influxdb2-2.9.1-arm64.deb
sudo systemctl enable --now influxdb
influx setup --org pegelwatch --bucket pegelwatch --username admin --force
```

**Konfiguration:** Fuer den 2.x-Rueckfall in `config.toml` bei der jeweiligen
InfluxDB-Verbindung `api_version = "v2"` und `org = "pegelwatch"` setzen (siehe
[docs/02-konfiguration.md](02-konfiguration.md)) sowie das API-Token in
`secrets.toml` eintragen. PegelWatch nutzt dafuer einen eigenen, v2-kompatiblen
Schreib-Client (`internal/influx/v2client.go`, v2-Line-Protocol gegen
`/api/v2/write?bucket=...&org=...`) — dieser Pfad ist implementiert und
getestet, nicht nur dokumentiert.

### Reservierte GPIO-Pins

Folgende Pins sind durch I²C und SPI0/MAX7219 belegt und **dürfen nicht** als Relais-Pins verwendet werden:

- **GPIO2, GPIO3** — I²C (SDA, SCL)
- **GPIO8** — SPI0 CE0 (MAX7219 Chip-Select)
- **GPIO10** — SPI0 MOSI (MAX7219 DIN)
- **GPIO11** — SPI0 CLK (MAX7219 CLK)

---

## Raspberry Pi vorbereiten

### I²C aktivieren

```bash
sudo raspi-config nonint do_i2c 0
```

### Zweiter I²C-Bus (nur bei zweitem ADS1115-Stapel)

Die vier ADS1115-Adressen (0x48–0x4B) sind eine harte Grenze **je Bus**. Ein
zweiter Stapel läuft auf einem per Overlay aktivierten Zusatz-Bus —
Empfehlung **i2c6** (GPIO22/23, physische Pins 15/16), weil dort weder
Display, Relaiskarte noch der Standardbus betroffen sind (Details und
Alternativen: [docs/04-verdrahtung.md](04-verdrahtung.md)):

```bash
echo "dtoverlay=i2c6" | sudo tee -a /boot/firmware/config.txt
sudo reboot
# danach pruefen:
ls /dev/i2c-*          # /dev/i2c-1 und /dev/i2c-6 erwartet
i2cdetect -y 6         # zeigt die ADS1115 des zweiten Stapels (0x48-0x4B)
```

In `config.toml` erhalten die Sensoren des zweiten Stapels `i2c_bus = 6`
(siehe [docs/02-konfiguration.md](02-konfiguration.md)).

### SPI aktivieren (nur wenn MAX7219-Display verwendet)

```bash
sudo raspi-config nonint do_spi 0
```

### Verzeichnisse anlegen

```bash
sudo mkdir -p /etc/pegelwatch /var/lib/pegelwatch
sudo chown andreas:andreas /var/lib/pegelwatch
```

---

## Basis-Setup automatisiert (empfohlen)

Für einen frisch aufgesetzten Pi bündelt [`deploy/pi-base-setup.sh`](../deploy/pi-base-setup.sh)
die Fremddienste, auf denen pegelwatch aufsetzt — **Basis-Update, Grafana und
InfluxDB 3 Core** — in einem idempotenten Skript. Reihenfolge beim Neuaufsetzen:
erst die Basis, dann pegelwatch.

Von Windows aus richtet `deploy.ps1` das alles in einem Rutsch ein — bei der
Ersteinrichtung laufen Basis-Setup (Grafana + InfluxDB 3) und Provisionierung
automatisch, `-BaseSetup` erzwingt sie auch auf einem bereits eingerichteten Pi:

```powershell
.\deploy.ps1 -PiHost <ip>              # Erst-Einrichtung: Basis + pegelwatch
.\deploy.ps1 -PiHost <ip> -BaseSetup   # Fremddienste auf Bestand neu einrichten
```

Oder direkt auf dem Pi:

```bash
sudo ./pi-base-setup.sh
```

Das Skript …

- aktualisiert das Basissystem (`apt-get update` + `full-upgrade`);
- installiert **Grafana** aus dem offiziellen apt-Repo (`apt.grafana.com`) —
  künftige Updates laufen damit einfach über `apt upgrade`;
- installiert **InfluxDB 3 Core in einer gepinnten Version** (Binary + geprüfte
  SHA256) und richtet die gehärtete systemd-Unit ein (Start-Limit gegen
  Crash-Loops + Selbstheilung gegen leere/genullte Katalog/WAL-Dateien nach Stromausfall);
- fasst **weder** `config.toml`/`secrets.toml`/`state.db` **noch** ein
  bestehendes InfluxDB-Token/DB an.

> **Warum InfluxDB gepinnt statt apt:** InfluxDB 3 Core wird von InfluxData nur
> als Binary/Tarball bzw. über ein Installer-Skript verteilt, **nicht** über ein
> apt-Repository. Eine feste Version + Prüfsumme im Skript macht die Installation
> reproduzierbar; ein Update geschieht durch Anheben von `INFLUXDB3_VERSION` und
> `INFLUXDB3_SHA256` in `deploy/pi-base-setup.sh`. Grafana dagegen ist voll
> apt-verwaltet und folgt `apt upgrade`.

Die beiden folgenden Abschnitte (InfluxDB, Grafana) beschreiben dieselben
Schritte manuell — als Referenz bzw. für Einzelinstallationen.

---

## Binary deployen

### Cross-Compile auf Windows (PowerShell)

```powershell
$env:GOOS = "linux"
$env:GOARCH = "arm64"
$env:CGO_ENABLED = "0"
go build -o pegelwatch ./cmd/pegelwatch
```

Die fertige Binary nach `/home/andreas/pegelwatch/` kopieren (z.B. über Samba-Freigabe auf Laufwerk P:).

Dann auf dem Pi:

```bash
sudo install -m 0755 /home/andreas/pegelwatch/pegelwatch /usr/local/bin/pegelwatch
```

### Automatisiert mit deploy.ps1 (empfohlen)

```powershell
.\deploy.ps1 -PiHost 192.168.1.100
```

Baut die Binary, kopiert sie per SSH/SCP auf den Pi und startet den Dienst neu.
Bei der allerersten Einrichtung wird zusätzlich `config.toml`/`secrets.toml`
aus `deploy\` übertragen und der systemd-Dienst eingerichtet.

**Wichtig:** Ein normales `deploy.ps1 -PiHost ...` (ohne `-UpdateConfig`)
ersetzt **ausschließlich die Binary** — `config.toml`, `secrets.toml` und
`state.db` auf dem Pi bleiben unangetastet. Nur mit dem expliziten Schalter
`-UpdateConfig` (plus einer Sicherheitsabfrage) wird die Konfiguration auf dem
Pi überschrieben.

### Deployment per Raspberry Pi Connect — Prüfergebnis: nur Browser-Zugriff

[Raspberry Pi Connect](https://www.raspberrypi.com/software/connect/) wurde
gegen die [offizielle Connect-Dokumentation](https://www.raspberrypi.com/documentation/services/connect.html)
geprüft (Stand: Juli 2026, siehe Änderungshistorie Punkt 6). Ergebnis:
Connect bietet **ausschließlich eine Remote Shell im Browser** (WebRTC-basiert,
Zugriff über `connect.raspberrypi.com`, Button "Connect via" → "Remote shell").
Es gibt **keinen dokumentierten, skriptbaren `ssh <Ziel>`-Zugang** von einem
nativen SSH-Client (wie dem Windows-OpenSSH-Client) aus — die frühere Annahme
in diesem Dokument, ein Connect-Ziel ließe sich einfach als `-PiHost` an
`deploy.ps1` übergeben, war zum Zeitpunkt der Ursprungsformulierung unbestätigt
und ist damit **nicht umsetzbar**, solange Raspberry Pi Connect das nicht
anbietet.

**Praktische Konsequenz:** `deploy.ps1`/`deploy-fleet.ps1` bleiben
transportunabhängig — sie brauchen nur einen funktionierenden `ssh <Ziel>`-Aufruf,
egal ob das Ziel eine LAN-IP, ein `.local`-Hostname oder ein VPN-Hostname
(z. B. Tailscale) ist. **Raspberry Pi Connect kommt dafür heute nicht in
Frage.** Für automatisiertes/skriptbares Deployment außerhalb des lokalen
Netzes wird stattdessen ein normales VPN-/Tailscale-Setup empfohlen, das dem
Pi eine per SSH erreichbare Adresse gibt. Raspberry Pi Connect bleibt
weiterhin nützlich für den **manuellen Notzugriff per Browser** (z. B. wenn
gar keine andere Verbindung zum Pi besteht), einfach nicht als Deploy-Transport.

Sollte Raspberry Pi Connect zu einem späteren Zeitpunkt einen skriptbaren
SSH-Zugang anbieten: einfach den dann gültigen Zielwert in
`deploy\devices.psd1` als `PiHost` eintragen — am restlichen Workflow ändert
sich dadurch nichts.

### Mehrere Geräte auf einmal deployen: deploy-fleet.ps1

Für die drei Aufbauten/Geräte (RIVERWatch, SEPWatch, PUMPWatch) gibt es ein
Geräte-Register unter [`deploy\devices.psd1`](../deploy/devices.psd1)
(Name → `PiHost`/`PiUser`/`ConfigDir`) sowie `deploy-fleet.ps1`, das darüber
einzelne oder mehrere Geräte in einem einzigen Befehl aktualisiert:

```powershell
# Registrierte Geraete anzeigen
.\deploy-fleet.ps1 -List

# Ein einzelnes Geraet aktualisieren
.\deploy-fleet.ps1 -Device RIVERWatch

# Mehrere Geraete in einem Aufruf aktualisieren
.\deploy-fleet.ps1 -Device RIVERWatch,PUMPWatch

# Alle registrierten (und eingerichteten) Geraete aktualisieren
.\deploy-fleet.ps1 -Device all

# -UpdateConfig wird an jedes ausgewaehlte Geraet durchgereicht
.\deploy-fleet.ps1 -Device SEPWatch -UpdateConfig
```

Jedes Gerät hat sein eigenes Konfigurationsverzeichnis (`ConfigDir` in
`devices.psd1`, z. B. `deploy\SEPWatch\config.toml`), damit unterschiedliche
Aufbauten nicht versehentlich die falsche Konfiguration bekommen. Ein Gerät
ohne eingetragenen `PiHost` gilt als "noch nicht eingerichtet" und wird bei
`-Device all` automatisch übersprungen (mit Warnung).

---

## Konfigurationsdateien

### Verzeichnisstruktur

```
/etc/pegelwatch/
├── config.toml       # Hauptkonfiguration (kein Passwort, kein Token)
└── secrets.toml      # SMTP-Passwort, InfluxDB-Token (nur Dienst-Benutzer)
```

Verzeichnis und Dateien gehören dem **Dienst-Benutzer** (`User=` in der
systemd-Unit, hier `andreas`) — **nicht root**: der Dienst muss `secrets.toml`
lesen und beide Dateien über die Konfigurations-Weboberfläche schreiben
können. Der Schutz vor Mitlesen durch andere Benutzer kommt von `chmod 600`:

```bash
sudo chown -R andreas:andreas /etc/pegelwatch
sudo chmod 644 /etc/pegelwatch/config.toml
sudo chmod 600 /etc/pegelwatch/secrets.toml
```

### Minimalbeispiel config.toml

```toml
aufbau = 1

[i2c]
bus = 1

[[sensor]]
id         = "s1"
name       = "Hauptbehälter"
board_addr = 0x48
channel    = 1    # Kanal 1 = erster Drucksensor (§2-Konvention)
ref_channel = 0   # Kanal 0 = Referenz (gleicher Wert wie channel = kein Ref)

[[sensor.calibration]]
water_mm = 0.0
volts_mv = 210.0

[[sensor.calibration]]
water_mm = 5097.0
volts_mv = 4520.0

[web]
port = 8080
```

Die Weboberfläche hat bewusst kein Login-Passwort (siehe [docs/02-konfiguration.md](02-konfiguration.md#web)).

---

## systemd-Dienst einrichten

```bash
sudo nano /etc/systemd/system/pegelwatch.service
```

Inhalt:

```ini
[Unit]
Description=PegelWatch Wasserstandsmessung
After=network.target
Wants=network.target
# Schutz gegen Neustart-Schleifen: max. 5 Starts in 2 Minuten
StartLimitIntervalSec=120
StartLimitBurst=5

[Service]
Type=notify
User=andreas
ExecStart=/usr/local/bin/pegelwatch \
    --config /etc/pegelwatch/config.toml \
    --secrets /etc/pegelwatch/secrets.toml \
    --state-db /var/lib/pegelwatch/state.db
# Restart=always: der Neustart-Button der Konfigurations-UI beendet den
# Dienst geordnet und systemd startet ihn neu. "systemctl stop" bleibt stop.
Restart=always
RestartSec=3s
WatchdogSec=30
TimeoutStopSec=10

# Sicherheit
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
# WICHTIG: /etc/pegelwatch muss hier stehen, sonst kann die Konfigurations-
# Weboberflaeche nicht speichern ("read-only file system").
ReadWritePaths=/var/lib/pegelwatch /etc/pegelwatch

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now pegelwatch
sudo systemctl status pegelwatch
```

### Logs anzeigen

```bash
sudo journalctl -u pegelwatch -f
```

---

## Web-UI

Nach dem Start ist die Web-UI erreichbar unter:

```
http://<pi-ip>:8080/
```

Die Kiosk-Ansicht (Aufbau 3) unter:

```
http://<pi-ip>:8080/pump-kiosk
```

Die Mehrkanal-Kiosk-Ansicht (Aufbau 2) entsprechend unter `/aufbau2-kiosk`,
die Messstellen-Ansicht mit Gewässerquerschnitt und Durchfluss (Aufbau 1)
unter `/fluss-kiosk`.
Alle sind bewusst **nicht** auf Localhost beschränkt (bis vor kurzem war das
so) — sie lassen sich auch von einem anderen Gerät im selben Netzwerk
aufrufen, z. B. um die Kiosk-Ansicht ohne physischen Zugriff auf den
angeschlossenen Bildschirm zu prüfen. Ein zusätzlicher Sicherheitsgewinn durch
die Beschränkung bestand ohnehin nicht, da die zugehörigen Steuer-Endpunkte
(z. B. `/api/pump/mode`) bereits netzwerkweit erreichbar waren.

---

## InfluxDB 3 Core (optional)

Installation auf dem Pi oder einem separaten Server — **empfohlen** ist das
offizielle Installationsskript von InfluxData, das die passende Architektur
(arm64) automatisch erkennt und immer die aktuelle Version installiert:

```bash
curl -O https://www.influxdata.com/d/install_influxdb3.sh && sh install_influxdb3.sh
```

**Alternativ, mit gepinnter Version** (empfohlen wenn eine reproduzierbare,
getestete Version fest eingerichtet werden soll — **v3.10.0** ist die zum
Zeitpunkt dieser Doku aktuelle Version, vor der Installation auf
[github.com/influxdata/influxdb/releases](https://github.com/influxdata/influxdb/releases)
prüfen, ob es eine neuere gibt):

```bash
# ACHTUNG Dateinamens-Schema: _linux_arm64 mit Unterstrichen!
wget https://dl.influxdata.com/influxdb/releases/influxdb3-core-3.10.0_linux_arm64.tar.gz
tar xf influxdb3-core-3.10.0_linux_arm64.tar.gz
sudo install influxdb3-core-3.10.0/influxdb3 /usr/local/bin/
```

> Falls vorher versehentlich das alte Debian-Paket `influxdb` (Version 1.6!)
> installiert wurde: `sudo systemctl disable --now influxdb` — die 1.x-API
> ist mit PegelWatch nicht kompatibel.

Als Dienst einrichten (Port **8086**, damit die PegelWatch-Konfiguration und
Grafana die gewohnte Adresse verwenden — der influxdb3-Default wäre 8181):

```bash
sudo mkdir -p /var/lib/influxdb3 && sudo chown andreas:andreas /var/lib/influxdb3
sudo tee /etc/systemd/system/influxdb3.service > /dev/null <<'EOF'
[Unit]
Description=InfluxDB 3 Core (PegelWatch)
After=network.target
Wants=network.target
# Nicht endlos in denselben Startfehler loopen (SD-Kartenschonung): nach 5
# Fehlstarts in 300s gilt der Dienst als failed. Wiederanlauf danach:
#   sudo systemctl reset-failed influxdb3 && sudo systemctl start influxdb3
StartLimitIntervalSec=300
StartLimitBurst=5

[Service]
Type=simple
User=andreas
# Selbstheilung: raeumt vor dem Start leere/genullte Katalog-/WAL-Dateien
# beiseite, die ein unsauberer Shutdown (Stromverlust) hinterlaesst — sonst
# crasht influxdb3 beim Start endlos ("catalog buffer too short" bzw. WAL
# "AlreadyExists"). Nur Nullbytes = nie geschriebener Inhalt, kein Datenverlust.
# Quelle: deploy/influxdb3-heal.sh; hier nur einbinden, falls installiert:
ExecStartPre=/usr/local/bin/influxdb3-heal.sh /var/lib/influxdb3
ExecStart=/usr/local/bin/influxdb3 serve --node-id pumpwatch1 --object-store file --data-dir /var/lib/influxdb3 --http-bind 0.0.0.0:8086 --disable-telemetry-upload
Restart=always
RestartSec=5s
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload && sudo systemctl enable --now influxdb3
```

> Die gehärtete Unit oben (Start-Limit + Selbstheilung) entspricht dem, was
> [`deploy/pi-base-setup.sh`](../deploy/pi-base-setup.sh) automatisch einrichtet.
> Das `ExecStartPre`-Heal-Skript ist [`deploy/influxdb3-heal.sh`](../deploy/influxdb3-heal.sh);
> `deploy.ps1` spielt es bei **jedem** Deploy neu ein (nicht nur mit `-BaseSetup`).
> Bei rein manueller Installation:
> `sudo install -m 0755 influxdb3-heal.sh /usr/local/bin/` — oder die
> `ExecStartPre`-Zeile weglassen.

Admin-Token erzeugen und Datenbank anlegen (`--host` nicht vergessen — das
CLI erwartet sonst Port 8181):

```bash
influxdb3 create token --admin --host http://localhost:8086   # Token notieren!
influxdb3 create database pegelwatch --token "apiv3_..." --host http://localhost:8086
```

Das Token über die Konfigurations-Weboberfläche eintragen (InfluxDB →
"Token" → **Zugangsdaten speichern**, danach **Dienst neu starten**) — oder
direkt in `secrets.toml`:

```toml
[influx.local]
token = "apiv3_..."
```

---

## Grafana (optional)

Grafana auf dem Pi oder einem Server installieren, dann Datasource und die
drei vorbereiteten Dashboards **provisionieren** (empfohlen — kein manueller
Import nötig, Anleitung mit fertigen YAML-Schnipseln in
[docs/03-grafana.md](03-grafana.md)):

- `aufbau1_pegelstand.json` — RIVERWatch (Aufbau 1: Einzelsensor)
- `aufbau2_mehrkanal.json` — SEPWatch (Aufbau 2: Mehrkanal, Volumen/Durchsatz)
- `aufbau3_pumpensteuerung.json` — PUMPWatch (Aufbau 3: Pumpe + Shelly 3EM)

Die Dashboards erwarten eine InfluxDB-Datasource mit der festen UID
`pegelwatch-influx` (InfluxQL, `http://localhost:8086`, Header
`Authorization: Bearer <token>`).
