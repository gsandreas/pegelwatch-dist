# PegelWatch — Verdrahtung

Pinbelegung und Verkabelung für alle Aufbauten.

---

## Raspberry Pi GPIO-Header (40-polig)

```
        3,3 V  [ 1] [ 2]  5 V
 GPIO2 (I²C SDA) [ 3] [ 4]  5 V
 GPIO3 (I²C SCL) [ 5] [ 6]  GND
        GPIO4  [ 7] [ 8]  GPIO14
          GND  [ 9] [10]  GPIO15
       GPIO17  [11] [12]  GPIO18
       GPIO27  [13] [14]  GND
       GPIO22  [15] [16]  GPIO23
        3,3 V  [17] [18]  GPIO24
GPIO10 (MOSI)  [19] [20]  GND
 GPIO9 (MISO)  [21] [22]  GPIO25
 GPIO11 (CLK)  [23] [24]  GPIO8 (CE0)
          GND  [25] [26]  GPIO7 (CE1)
        GPIO0  [27] [28]  GPIO1
        GPIO5  [29] [30]  GND
        GPIO6  [31] [32]  GPIO12
       GPIO13  [33] [34]  GND
       GPIO19  [35] [36]  GPIO16
       GPIO26  [37] [38]  GPIO20
          GND  [39] [40]  GPIO21
```

---

## ADS1115 — I²C-ADC

Der ADS1115 hängt am I²C-Bus des Pi. Bis zu 4 Boards können gleichzeitig
betrieben werden, jedes mit einer anderen I²C-Adresse (bestimmt durch den
ADDR-Pin).

### Pinbelegung

| ADS1115-Pin | Verbinden mit | Raspberry Pi Pin# |
|---|---|---|
| VDD | 3,3 V | Pin 1 oder 17 |
| GND | GND | Pin 6, 9, 14, 20, 25 oder 39 |
| SCL | GPIO3 (SCL) | **Pin 5** |
| SDA | GPIO2 (SDA) | **Pin 3** |
| ADDR | → I²C-Adresse (siehe unten) | — |
| ALRT | nicht belegt | — |

### I²C-Adresse über ADDR-Pin

| ADDR verbunden mit | I²C-Adresse | config.toml `board_addr` |
|---|---|---|
| GND | 0x48 | `0x48` |
| VDD | 0x49 | `0x49` |
| SDA | 0x4A | `0x4A` |
| SCL | 0x4B | `0x4B` |

### Kanalzuweisung (Beispiel: 1 Sensor + Referenz)

Konvention aus §2 des Auftrags: **der erste Kanal (AIN0) ist die Referenz,
der zweite Kanal (AIN1) der erste Drucksensor.**

| ADS1115-Kanal | Signal | config.toml |
|---|---|---|
| AIN0 | LT1461 VOUT (Referenzspannung 5 V) | `ref_channel = 0` |
| AIN1 | MPXV5050DP VOUT (Sensorspannung) | `channel = 1` |
| AIN2 | frei oder weiterer Sensor | — |
| AIN3 | frei oder weiterer Sensor | — |

> Wenn `channel == ref_channel` (auf demselben Board) konfiguriert ist, wird
> **kein** Referenzkanal verwendet (dann direkte LSB-Umrechnung ohne
> ratiometrische Kompensation). Mit `ref_board_addr` kann der Referenzkanal
> auf einem anderen Board **desselben Stapels** liegen ("eine Referenz pro
> Stapel" — gibt bis zu 15 Messkanäle je Stapel frei).

---

## LT1461 — Präzisions-Spannungsreferenz 5,0 V

Die LT1461 liefert eine stabile 5,000-V-Referenz. Diese dient gleichzeitig
als Versorgungsspannung für den MPXV5050DP **und** als Messgröße auf dem
ADS1115-Referenzkanal (ratiometrische Kompensation).

### Pinbelegung

| LT1461-Pin | Verbinden mit |
|---|---|
| VIN (Pin 1) | 5 V (Pi Pin 2 oder 4) |
| GND (Pin 3) | GND |
| VOUT (Pin 8) | → ADS1115 AIN_ref (z.B. AIN1) |
| VOUT (Pin 8) | → MPXV5050DP Vs (Versorgung) |

> VOUT (5,000 V) geht also an **zwei** Stellen: an den Referenzkanal des ADS1115
> und an die Versorgung des Drucksensors. Das ist der Kern der ratiometrischen
> Kompensation: Schwankungen der Versorgungsspannung kürzen sich heraus.

### Ratiometrische Formel (intern im Code)

```
V_korrigiert [mV] = ADC_Sensor × 5000 / ADC_Referenz
```

---

## MPXV5050DP — Differenzdrucksensor

Misst Relativdruck 0–50 kPa, entspricht einem Wasserstand von 0–5.097 mm.

### Pinbelegung (SIP-Gehäuse, 6-polig)

| MPXV5050DP-Pin | Signal | Verbinden mit |
|---|---|---|
| Pin 1 | VOUT | ADS1115 AIN_sensor (z.B. AIN0) |
| Pin 2 | GND | GND |
| Pin 3 | Vs | LT1461 VOUT (5,000 V) |
| Pin 4 | V1 | nicht belegt |
| Pin 5 | V2 | nicht belegt |
| Pin 6 | VOUT2 | nicht belegt (identisch mit Pin 1) |

### Druckanschlüsse

| Anschluss | Funktion |
|---|---|
| P1 (obere Öffnung) | Luftseite — offen oder mit Schlauch zur Oberfläche |
| P2 (untere Öffnung) | Wasserseite — Schlauch ins Wasser |

Der Sensor misst `P2 − P1`. Bei offenem P1 und Wasserdruckanschluss an P2
ergibt sich die Wasserhöhe über dem Sensor direkt als Pegelstand.

### Ausgangsspannungen

| Druck | VOUT (bei Vs = 5 V) |
|---|---|
| 0 kPa (0 mm WS) | ≈ 200 mV |
| 50 kPa (5.097 mm WS) | ≈ 4.520 mV |

---

## Gesamtschaltbild — Aufbau 1 (Einzelsensor)

```
Raspberry Pi                  ADS1115 (0x48)
┌──────────────┐              ┌──────────────┐
│ Pin 1  3,3V  ├─────────────►│ VDD          │
│ Pin 3  GPIO2 ├─────────────►│ SDA          │
│ Pin 5  GPIO3 ├─────────────►│ SCL          │
│ Pin 6  GND   ├──────────────┤ GND ──┬──────┤
└──────────────┘              │ ADDR ─┘(GND) │
                              │              │
          LT1461              │ AIN0 ◄───────┼──── MPXV5050DP VOUT
    ┌─────────────┐           │ AIN1 ◄───────┼──┐
5V ─► VIN     VOUT ──────────►│ (Ref)        │  │
GND─► GND          │          └──────────────┘  │
    └─────────────┘│                             │
                   └─────────────────────────────┘
                   │         MPXV5050DP
                   └────────► Vs (Pin 3)
                              GND (Pin 2) ──── GND
                              VOUT (Pin 1) ─── ADS1115 AIN0
```

---

## MAX7219 — 7-Segment-Display (SPI0)

Pins sind **fest** durch SPI0 vorgegeben und können nicht geändert werden.

### Pinbelegung

| MAX7219-Pin | Signal | Verbinden mit | Pi Pin# |
|---|---|---|---|
| VCC | 5 V | Pi 5 V | Pin 2 oder 4 |
| GND | GND | Pi GND | Pin 6, 20, 25 oder 39 |
| DIN | Daten | GPIO10 (MOSI) | **Pin 19** |
| CLK | Takt | GPIO11 (CLK) | **Pin 23** |
| CS/LOAD | Chip-Select | GPIO8 (CE0) | **Pin 24** |
| DOUT | Ketten-Ausgang | nicht belegt | — |
| ISET | Strombegrenzer | 10-kΩ-Widerstand nach VCC | — |

> Der ISET-Widerstand bestimmt den maximalen Segmentstrom. 10 kΩ nach VCC ergibt
> bei den meisten 7-Segment-Modulen eine mittlere Helligkeit (ca. 20 mA/Segment).

### Konfiguration in config.toml

```toml
[display]
enabled = true
```

---

## Relaisplatine — nur Aufbau 3

Konkret verbaut: **Waveshare RPi Relay Board (B)**, 8 Kanäle. Quellen:
[Wiki](https://www.waveshare.com/wiki/RPi_Relay_Board_(B)),
[User Manual (PDF)](https://files.waveshare.com/upload/6/6f/RPi_Relay_Board_%28B%29_User_Manual_EN.pdf),
[Schaltplan (PDF)](https://files.waveshare.com/upload/d/db/RPi_Relay_Board_%28B%29_Schematic.pdf).

> **Korrektur:** Frühere Fassungen dieser Doku nannten GPIO17/27/22
> (physische Pins 11/13/15) als Relais-Pins. Diese Pins existieren auf der
> Platine **nicht** als Kanal-Standardbelegung — das war ein Dokumentationsfehler.
> Die folgende Tabelle stammt direkt aus dem Hersteller-Handbuch (Abschnitt
> „Interface").

### Kanal-Standardbelegung (aus dem Hersteller-Handbuch)

| Kanal | Pi-Pin # | wiringPi | BCM (GPIO) | In diesem Projekt |
|---|---|---|---|---|
| CH1 | 29 | P21 | **GPIO5**  | Pumpen-Relais → `pump_gpio = 5` |
| CH2 | 31 | P22 | **GPIO6**  | Alarm-Relais → `alarm_gpio = 6` |
| CH3 | 33 | P23 | **GPIO13** | Pneumatik-Relais → `pneumatic_gpio = 13` |
| CH4 | 36 | P27 | GPIO16 | frei → **Logik-Ausgang** (`gpio = 16`) |
| CH5 | 35 | P24 | GPIO19 | frei → **Logik-Ausgang** (`gpio = 19`) |
| CH6 | 38 | P28 | GPIO20 | frei → **Logik-Ausgang** (`gpio = 20`) |
| CH7 | 40 | P29 | GPIO21 | frei → **Logik-Ausgang** (`gpio = 21`) |
| CH8 | 37 | P25 | GPIO26 | frei → **Logik-Ausgang** (`gpio = 26`) |

Alle 8 Kanal-Standardpins (GPIO 5, 6, 13, 16, 19, 20, 21, 26) kollidieren
**nicht** mit I²C (GPIO2/3) oder SPI0/MAX7219 (GPIO8/10/11) — für dieses
Projekt ist daher **keine Jumper-Änderung nötig**, alle Kanäle bleiben in
Werkseinstellung.

Die freien Kanäle **CH4–CH8** lassen sich als **frei konfigurierbare
Logik-Ausgänge** nutzen: ein beliebiges Systemsignal (Temperatur, Strom,
Pegel, Alarmstatus …) schaltet nach einem Vergleich mit Festwert und Totzeit
das Relais. Konfiguration über `[[logic_output]]` bzw. die Konfigurations-UI
(siehe [docs/02-konfiguration.md](02-konfiguration.md)). Sie sind ebenfalls
aktiv-LOW; für die Last denselben NO/NC-Hinweis wie bei den festen Kanälen
beachten.

### Aktiv-LOW — wichtig für Software UND Verdrahtung

Jeder Kanal-Eingang hängt laut Schaltplan über einen Optokoppler (PC817) mit
Pull-up an 3,3 V. Der Pi-GPIO muss den Strom nach GND ableiten, um den
Optokoppler und darüber das Relais zu schalten:

- **GPIO = LOW (0 V) → Relais energisiert** (Wechsler zieht auf **NO**)
- **GPIO = HIGH (3,3 V) → Relais stromlos** (Wechsler in Ruhestellung **NC**) — das ist
  auch der Zustand, wenn der Pi ausgeschaltet ist, abstürzt oder die GPIO-Leitung
  noch nicht angefordert wurde.

PegelWatch (`internal/relay`) berücksichtigt das bereits: `SetPump(true)`,
`SetAlarm(true)`, `SetPneumatic(true)` usw. legen intern automatisch den
richtigen LOW-Pegel an — in der Konfiguration und im restlichen Betrieb denkst
du weiterhin in „an"/„aus", nicht in GPIO-Pegeln.

### Wechsler-Kontakt (NO/NC): welchen Kontakt anschließen

Jedes Relais hat drei Anschlüsse: **COM** (gemeinsam), **NO** (normally open,
öffnet im Ruhezustand) und **NC** (normally closed, schließt im Ruhezustand).
Für alle drei in diesem Projekt genutzten Kanäle **an NO anschließen**:

| Gerät | Anschluss | Warum NO (nicht NC) |
|---|---|---|
| Pumpenschütz-Steuerkreis | COM+NO | Pumpe läuft **nur**, wenn die Software es aktiv einschaltet. Stürzt der Pi ab oder verliert Strom, fällt das Relais in den Ruhezustand (NC) zurück → NO öffnet → Pumpe **stoppt automatisch** (Fail-Safe, siehe §3 des Auftrags). |
| Alarm-Signalleuchte/-summer | COM+NO | Alarm ertönt nur, wenn die Software ihn aktiv auslöst. (Kehrseite: ein abgestürzter Pi meldet sich dadurch *nicht* selbst per Alarmausgang — dafür ist der Watchdog/systemd-Neustart zuständig, nicht der Relaisausgang.) |
| Pneumatikpumpe | COM+NO | Gleiche Begründung wie oben — läuft nur bei aktiver, funktionierender Software. |

NC würde das jeweilige Verhalten umkehren (Gerät läuft **immer außer** wenn die
Software es aktiv abschaltet) — für keinen der drei Fälle hier sinnvoll.

### Jumper (Kanal-Pin wählbar)

Jeder Kanal hat einen eigenen 3-poligen Jumper, der zwischen dem
Standard-GPIO aus obiger Tabelle (Werkseinstellung, Signal kommt direkt vom
40-poligen Pi-Header) und einem **frei verdrahteten** Eingang über die
Schraubklemmen/den kompakten Zusatz-Pfostenstecker der Platine umschaltet.
Das ist nur relevant, wenn ein Kanal seinen Standard-GPIO **nicht** nutzen
kann (z. B. weil dieser GPIO anderweitig fest gebraucht wird) — dann Jumper auf
die freie/custom Position umstecken und den Kanal-Eingang stattdessen per
Kabel von einem beliebigen, freien Pi-GPIO aus verdrahten. Für die
Standardkonfiguration dieses Projekts (CH1–CH3, s. o.) ist das **nicht nötig**,
da keiner der genutzten Standardpins mit I²C/SPI kollidiert.

### Konfiguration frei wählbar

`internal/config` erzwingt für `relay.pump_gpio`/`alarm_gpio`/`pneumatic_gpio`
nur: gültiger GPIO-Bereich (1–27), keine Kollision mit I²C/SPI (GPIO2/3/8/10/11),
und dass alle drei Werte unterschiedlich sind. Jeder der 8 Kanäle (oder — nach
Jumper-Umsteckung — praktisch jeder freie GPIO — kann eingetragen werden.

### Verbindung Pi → Relaisplatine (Standardbelegung)

```
Pi GPIO5  (Pin 29) ──► CH1 (Pumpen-Relais)
Pi GPIO6  (Pin 31) ──► CH2 (Alarm-Relais)
Pi GPIO13 (Pin 33) ──► CH3 (Pneumatik-Relais)
```

Die Platine wird als HAT auf die 40-polige Buchsenleiste gesteckt (Stromversorgung
und Steuersignale laufen über den Header, keine separate VCC/GND-Verkabelung nötig).

---

## Vollständige Pin-Übersicht nach Aufbau

### Aufbau 1 — Pegelstand (Minimalverdrahtung)

| Pi-Pin | GPIO | Signal | Ziel |
|---|---|---|---|
| 1 | — | 3,3 V | ADS1115 VDD |
| 2 | — | 5 V | LT1461 VIN |
| 3 | GPIO2 | I²C SDA | ADS1115 SDA |
| 5 | GPIO3 | I²C SCL | ADS1115 SCL |
| 6 | — | GND | ADS1115 GND, LT1461 GND, MPXV5050DP GND |

### Aufbau 1 + Display (MAX7219 zusätzlich)

| Pi-Pin | GPIO | Signal | Ziel |
|---|---|---|---|
| 2 | — | 5 V | MAX7219 VCC |
| 6 | — | GND | MAX7219 GND |
| 19 | GPIO10 | SPI0 MOSI | MAX7219 DIN |
| 23 | GPIO11 | SPI0 CLK | MAX7219 CLK |
| 24 | GPIO8 | SPI0 CE0 | MAX7219 CS/LOAD |

### Aufbau 3 — zusätzlich Relais (Waveshare RPi Relay Board (B), Standardbelegung)

| Pi-Pin | GPIO | Signal | Ziel | Wechsler-Kontakt |
|---|---|---|---|---|
| 29 | GPIO5 | Pumpen-Relais (CH1) | Pumpenschütz-Steuerkreis | NO |
| 31 | GPIO6 | Alarm-Relais (CH2) | Alarm-Signalleuchte/-summer | NO |
| 33 | GPIO13 | Pneumatik-Relais (CH3) | Pneumatikpumpe | NO |

Die Platine wird komplett als HAT gesteckt — keine separate VCC/GND-Verkabelung
nötig. **Achtung Aktiv-LOW:** GPIO=LOW energisiert das jeweilige Relais (siehe
Abschnitt „Relaisplatine" oben) — das ist bereits in `internal/relay`
berücksichtigt und für den Konfigurationsbetrieb ohne Bedeutung.

---

## Pneumatikpumpe — Aufbau 1/2 (eigene GPIO-Leitung, keine Relaiskarte)

Aufbau 1/2 haben keine Relaiskarte (die ist nur in Aufbau 3 verbaut), die
Pneumatikpumpen-Drift-Kompensation (§5 des Auftrags) läuft dort aber trotzdem
mit — über eine **einzelne, dedizierte GPIO-Leitung** direkt am Pi.

| Pi-Pin | GPIO | Signal | Ziel | config.toml |
|---|---|---|---|---|
| 11 | GPIO17 | Pneumatikpumpen-Schaltung | Relais-/Treiberstufe der Pneumatikpumpe | `[pneumatic] gpio_line = 17` |

> Reservierte Pins (GPIO2/3/8/10/11) sind auch hier gesperrt — PegelWatch
> verweigert den Start bei Kollision. In Aufbau 3 wird stattdessen
> `relay.pneumatic_gpio` auf der Relaiskarte verwendet, diese eigene Leitung
> entfällt dann.

---

## Mehrere Sensoren (Aufbau 2)

Jeder weitere ADS1115 hängt am **gleichen** I²C-Bus (SDA/SCL), erhält aber
eine andere Adresse über den ADDR-Pin.

```
Pi GPIO2/GPIO3 ──► ADS1115 #1 (ADDR=GND → 0x48)  ── Sensor s1
                └─► ADS1115 #2 (ADDR=VDD → 0x49)  ── Sensor s2
                └─► ADS1115 #3 (ADDR=SDA → 0x4A)  ── Sensor s3
                └─► ADS1115 #4 (ADDR=SCL → 0x4B)  ── Sensor s4
```

Alle vier Boards teilen sich SDA, SCL, VDD und GND.

**Referenz-Modus:**
- *Pro Board:* jedes Board misst seine eigene LT1461 auf einem seiner Kanäle
  (`ref_board_addr` weglassen) → max. 12 Drucksensoren je Stapel.
- *Pro Stapel* (empfohlen bei gemeinsamer 5-V-Versorgung): **eine** LT1461,
  gemessen auf genau einem Kanal (z. B. Board 0x48/AIN0), alle Sensoren zeigen
  per `ref_board_addr = 0x48`, `ref_channel = 0` darauf → max. **15
  Drucksensoren je Stapel**. Die LT1461-VOUT versorgt dann alle MPXV5050DP
  des Stapels.

---

## Zweiter ADS1115-Stapel — zusätzlicher I²C-Bus

Die vier ADS1115-Adressen (0x48–0x4B) sind eine **harte Grenze je Bus**. Ein
zweiter Stapel (weitere 4 Boards = bis zu 15 zusätzliche Sensoren mit
Stapel-Referenz) läuft deshalb auf einem **zweiten I²C-Bus**, den der Pi per
Device-Tree-Overlay bereitstellt. Die Zuordnung erfolgt initial ("per
Jumper/Overlay konfigurierbar"): Overlay in `/boot/firmware/config.txt`
eintragen, ADDR-Jumper der neuen Boards setzen, in `config.toml` je Sensor
`i2c_bus` angeben — die Software prüft beim Start automatisch, dass die
gewählte Kombination mit Display, Relaiskarte und Pneumatik-Leitung
interferenzfrei ist (in **allen drei Aufbauten**, nicht nur im gerade aktiven).

### Overlay wählen (Pi 4 / BCM2711)

| Overlay (`config.txt`) | Gerät | GPIO (SDA/SCL) Standard | Alternative | Kollidiert mit |
|---|---|---|---|---|
| `dtoverlay=i2c3` | `/dev/i2c-3` | GPIO4/**5** | GPIO2/3 | **Relais CH1** (GPIO5, Pumpe!) bzw. i2c-1 |
| `dtoverlay=i2c4` | `/dev/i2c-4` | **GPIO8**/9 | GPIO**6**/7 | **SPI0-Display** (GPIO8) bzw. **Relais CH2** (GPIO6, Alarm) |
| `dtoverlay=i2c5` | `/dev/i2c-5` | GPIO12/**13** | GPIO**10/11** | **Relais CH3** (GPIO13, Pneumatik) bzw. **SPI0-Display** |
| `dtoverlay=i2c6` | `/dev/i2c-6` | **GPIO22/23** | GPIO0/1 | **nichts** ✓ (Alternative: HAT-EEPROM — nicht verwenden) |

**Empfehlung: `dtoverlay=i2c6` (GPIO22/23, physische Pins 15/16).** Das ist
die einzige Wahl, bei der **alle 8 Relaiskanäle**, das SPI0-Display und der
Standardbus uneingeschränkt nutzbar bleiben.

```
# /boot/firmware/config.txt — zweiter I²C-Bus für Stapel 2
dtoverlay=i2c6            # /dev/i2c-6 auf GPIO22 (SDA, Pin 15) / GPIO23 (SCL, Pin 16)
```

Auf dem **Pi 5** (RP1) heißen die Overlays anders (`i2c2-pi5`, `i2c3-pi5`, …)
und liefern andere Busnummern/Pins. In dem Fall die tatsächliche Belegung in
`config.toml` deklarieren, damit die Interferenzprüfung stimmt:

```toml
[i2c.bus_pins]
3 = [22, 23]   # Beispiel: i2c3-pi5,pins_22_23 → /dev/i2c-3 auf GPIO22/23
```

### Nutzbarkeit der Relaiskanäle je Bus-Wahl

Die Waveshare-Relaiskarte (B) belegt in Werkseinstellung GPIO 5, 6, 13, 16,
19, 20, 21, 26. Je nach gewähltem Zusatz-Bus wird davon **unbrauchbar**:

| Zusatz-Bus | Unbrauchbarer Relaiskanal | Ausweich-Empfehlung |
|---|---|---|
| **i2c6 (GPIO22/23) — Empfehlung** | **keiner** — alle CH1–CH8 nutzbar | — |
| i2c5 (GPIO12/13) | CH3 (GPIO13, Pneumatik) | Pneumatik auf CH4: Jumper belassen, `pneumatic_gpio = 16` |
| i2c4 mit `pins_6_7` (GPIO6/7) | CH2 (GPIO6, Alarm) | Alarm auf CH5: `alarm_gpio = 19` |
| i2c4 Standard (GPIO8/9) | — (kollidiert stattdessen mit dem **Display**) | nicht verwenden solange MAX7219 verdrahtet ist |
| i2c3 (GPIO4/5) | CH1 (GPIO5, **Pumpe**) | Pumpe auf CH6: `pump_gpio = 20` — wegen des Pumpenschützes nur wählen, wenn i2c6 nicht verfügbar ist |

PegelWatch lehnt eine kollidierende Kombination beim Start/Speichern mit einer
klaren Fehlermeldung ab (z. B. *"relay.pneumatic_gpio=GPIO13 kollidiert mit
I²C-Bus 5 (SDA/SCL)"*) — es kann also keine unbemerkte Doppelbelegung geben.

### Verdrahtung Stapel 2 (an i2c6)

```
Pi GPIO22 (Pin 15, SDA) ──► ADS1115 #5–#8 SDA (ADDR: GND/VDD/SDA/SCL → 0x48–0x4B)
Pi GPIO23 (Pin 16, SCL) ──► ADS1115 #5–#8 SCL
3,3 V / GND wie Stapel 1; eigene LT1461 + eigener Referenzkanal je Stapel!
```

Der zweite Stapel braucht **seine eigene Referenzmessung** (die Referenz gilt
je Stapel, `ref_board_addr`/`ref_channel` zeigen immer auf ein Board desselben
Busses). In `config.toml` je Sensor des zweiten Stapels:

```toml
[[sensor]]
id          = "s16"
i2c_bus     = 6      # /dev/i2c-6 = Stapel 2
board_addr  = 0x48   # Adressen zählen je Bus neu ab 0x48
channel     = 1
ref_channel = 0
ref_board_addr = 0x48
```

---

## Sicherheitshinweise

- **Nie** GPIO2, GPIO3, GPIO8, GPIO10 oder GPIO11 als Relais-Pins verwenden
  (I²C-1 + SPI0). Bei zusätzlichen I²C-Bussen kommen deren SDA/SCL-Pins zur
  Sperrliste hinzu (siehe Tabelle oben) — PegelWatch verweigert den Start,
  wenn ein kollidierender Pin in `config.toml` eingetragen ist, unabhängig
  vom gerade aktiven Aufbau.
- Die Pi-GPIOs liefern **maximal 16 mA** pro Pin. Für Relaismodule mit Optokoppler
  ist das ausreichend; direkt angesteuerte Relais ohne Treiber sind nicht zulässig.
- Den MPXV5050DP **nicht** mit mehr als 5,25 V versorgen (Absolute Maximum Rating).
- Schlauchverbindungen zum Sensor wasserdicht und knicksicher ausführen.
  Ein Knick im Schlauch führt zu einem falschen Nullpunkt.
