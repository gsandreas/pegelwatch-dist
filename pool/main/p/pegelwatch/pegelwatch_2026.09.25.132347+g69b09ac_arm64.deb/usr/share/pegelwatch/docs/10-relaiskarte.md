# PegelWatch — Relaiskarte (Waveshare RPi Relay Board (B))

Erklärung, **wie die Relaiskarte funktioniert** — als Ergänzung zur reinen
Pin-/Klemmenbelegung in [docs/04-verdrahtung.md](04-verdrahtung.md) (dort:
Kanal-→-GPIO-Tabelle, NO/NC-Wahl, Aktiv-LOW im Betrieb, Jumper). Diese Seite
beschreibt die **Baugruppen der Platine** in derselben Tiefe wie die
Sensorplatine in [docs/09-analog-frontend.md](09-analog-frontend.md).

Nur **Aufbau 3 (PUMPWatch)** verwendet die Relaiskarte.

**Hersteller-Quellen** (Schaltplan liegt nur als PDF vor, nicht maschinenlesbar):
[Wiki](https://www.waveshare.com/wiki/RPi_Relay_Board_(B)) ·
[User Manual (PDF)](https://files.waveshare.com/upload/6/6f/RPi_Relay_Board_%28B%29_User_Manual_EN.pdf) ·
[Schaltplan (PDF)](https://files.waveshare.com/upload/d/db/RPi_Relay_Board_%28B%29_Schematic.pdf).

---

## Was die Baugruppe macht

Eine **8-Kanal-Relaiskarte** als Raspberry-Pi-**HAT**: sie sitzt direkt auf der
40-poligen Stiftleiste und schaltet mit den GPIOs des Pi bis zu 8 **potentialfreie
Wechsler-Kontakte** (COM/NO/NC). Zwischen Pi-GPIO und Relais liegt je Kanal eine
**galvanische Trennung per Optokoppler** — der empfindliche Pi ist damit von der
Schaltlast (bis hin zu Netzspannung) entkoppelt.

Signalfluss je Kanal:

```
Pi-GPIO → Optokoppler (galvanische Trennung) → Treiber-Transistor → Relais-Spule → Kontakt (COM/NO/NC)
```

---

## 1. Eingangsstufe: Optokoppler und Aktiv-LOW

Jeder Kanaleingang hängt über einen **Optokoppler (PC817)** mit **Pull-up nach
3,3 V** an einem Pi-GPIO. Der Pi schaltet den Kanal, indem er den GPIO nach
Masse zieht und so den Optokoppler-LED-Strom fließen lässt — daraus folgt das
**Aktiv-LOW-Verhalten**:

- **GPIO = LOW (0 V) → Relais zieht an** (Kontakt geht auf **NO**).
- **GPIO = HIGH (3,3 V) → Relais stromlos** (Ruhestellung **NC**). Das ist auch
  der Zustand, wenn der Pi **aus** ist, **abstürzt** oder die Leitung noch nicht
  angefordert wurde → **definierter Fail-Safe**.

Die galvanische Trennung des Optokopplers bedeutet: ein Defekt auf der
Lastseite (Netzspannung) kann nicht direkt auf die GPIOs des Pi durchschlagen.

> Im Code ist das bereits berücksichtigt: `internal/relay` fordert die Leitungen
> mit **HIGH = sicher/stromlos** an und invertiert intern. `SetPump(true)` legt
> also automatisch LOW an. In Konfiguration und Betrieb denkt man weiter in
> „an/aus", nicht in GPIO-Pegeln. Siehe
> [internal/relay/driver_linux.go](../internal/relay/driver_linux.go)
> (`activeLowLevel`).

---

## 2. Treiber und Relais-Spule

Der Optokoppler-Ausgang steuert einen **Treiber-Transistor**, der die
**Relais-Spule** schaltet (die Pi-GPIOs selbst könnten den Spulenstrom nicht
liefern — max. 16 mA/Pin). Parallel zur Spule sitzt eine **Freilaufdiode**, die
die Abschalt-Spannungsspitze der Spule kurzschließt und den Transistor schützt.
Eine **Status-LED je Kanal** zeigt an, ob das Relais angezogen ist.

**Stromversorgung:** Spulen und LEDs werden über die **5-V-Schiene des
Pi-Headers** versorgt — die Karte als HAT braucht **keine separate VCC/GND-
Verkabelung**. Alle 8 Relais gleichzeitig ziehen spürbar Strom; das Netzteil
des Pi muss entsprechend dimensioniert sein.

---

## 3. Ausgangsstufe: Wechsler-Kontakt (COM/NO/NC)

Jedes Relais bietet einen **potentialfreien Wechsler**:

- **COM** — gemeinsamer Anschluss.
- **NO** (*normally open*) — im Ruhezustand **offen**, schließt bei angezogenem Relais.
- **NC** (*normally closed*) — im Ruhezustand **geschlossen**, öffnet bei angezogenem Relais.

In diesem Projekt werden alle genutzten Lasten an **COM+NO** angeschlossen,
damit ein abgestürzter/stromloser Pi die Last **abschaltet** (Fail-Safe).
Begründung je Gerät: siehe [docs/04-verdrahtung.md](04-verdrahtung.md),
Abschnitt „Wechsler-Kontakt (NO/NC)".

**Kontaktbelastbarkeit:** Die genaue zulässige Schaltlast (Spannung/Strom, AC/DC)
steht **verbindlich im Waveshare-Handbuch** (PDF oben). Die Relais sind für
Netzspannung ausgelegt; die konkreten Grenzwerte der verbauten Relais dem
Handbuch entnehmen und **nicht überschreiten**.

> ⚠️ **Netzspannung / Drehstrom nur durch eine Elektrofachkraft.** Die
> Drehstrompumpe wird nicht direkt über die Relaiskarte geschaltet, sondern über
> ein **Schütz** (der Relaiskontakt schaltet nur den **Steuerkreis** des
> Schützes) mit vorgeschaltetem **Motorschutzschalter**.

---

## 4. Kanalbelegung in diesem Projekt

Werkseinstellung der Karte: **CH1…CH8 = BCM GPIO 5, 6, 13, 16, 19, 20, 21, 26**
(keine Kollision mit I²C GPIO2/3 oder SPI0 GPIO8/10/11 → keine Jumper-Änderung
nötig). Zuordnung im Projekt:

| Kanal | GPIO | Verwendung | config.toml |
|-------|------|------------|-------------|
| CH1 | 5 | Schütz **Drehstrompumpe** (Steuerkreis) | `[relay] pump_gpio = 5` |
| CH2 | 6 | **Alarm**-Ausgang (Überstrom/Unterstrom/Pegel/Leckage) | `[relay] alarm_gpio = 6` |
| CH3 | 13 | **Pneumatikpumpe** (Drift-Kompensation) | `[relay] pneumatic_gpio = 13` |
| CH4–CH8 | 16,19,20,21,26 | frei → **Logik-Ausgänge** | `[[logic_output]] gpio = …` |

Die vollständige Tabelle (mit Pi-Pin-Nummern und wiringPi-Namen) sowie die
Jumper-Erklärung stehen in [docs/04-verdrahtung.md](04-verdrahtung.md).

### Freie Kanäle CH4–CH8: Logik-Ausgänge

Die freien Kanäle lassen sich als **frei konfigurierbare Logik-Ausgänge**
nutzen: ein beliebiges Systemsignal (Temperatur, Strom, Pegel, Alarmstatus …
aus `/api/signals`) wird mit einem Vergleichsoperator gegen einen Festwert
geprüft; ist die Bedingung länger als eine **Totzeit** erfüllt, schaltet das
Relais. Konfiguration über `[[logic_output]]` bzw. am einfachsten in der
Konfigurations-UI. Implementierung: `internal/logicout`, `internal/signals`,
`relay.LogicSwitch`. Diese Kanäle sind ebenfalls **aktiv-LOW**.

---

## 5. Fail-Safe im Zusammenspiel mit der Software

- **Aktiv-LOW + COM/NO** ⇒ Pi aus/abgestürzt ⇒ alle genutzten Relais fallen ab
  ⇒ Pumpe/Pneumatik/Alarm stromlos (definierter sicherer Zustand).
- Der `pegelwatch`-Dienst läuft mit **systemd-Watchdog** (`WatchdogSec=30`) und
  `Restart=always` — ein hängender Dienst wird neu gestartet.
- Beim geordneten Schließen setzt `internal/relay` alle Kanäle aktiv auf den
  sicheren Pegel zurück (`Close()`), bevor die GPIO-Leitungen freigegeben werden.

---

## Quellen

- Waveshare-Handbuch/Schaltplan (PDF-Links oben) — **maßgeblich** für Kontakt-
  belastbarkeit und Bauteilbestückung.
- Anschluss/Pinbelegung im Systemkontext: [docs/04-verdrahtung.md](04-verdrahtung.md).
- Software-Ansteuerung: [internal/relay/](../internal/relay/).
