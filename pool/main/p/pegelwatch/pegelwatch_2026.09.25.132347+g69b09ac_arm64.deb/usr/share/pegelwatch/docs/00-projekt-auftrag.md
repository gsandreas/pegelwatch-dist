# Projekt-Prompt für Claude Code: Wasserpegel- und Pumpensteuerung auf Raspberry Pi

> **Änderungshistorie:** Dieses Dokument ist der ursprüngliche Projekt-Auftrag,
> nachträglich korrigiert.
>
> 1. Fehlerhafte Angabe: Das Display war ursprünglich mit **480×800
>    (Hochformat)** spezifiziert — diese Auflösung ist **nicht mehr gültig**,
>    das tatsächlich verbaute Waveshare-HDMI-Display läuft mit **1024×600
>    (Querformat)**. Ergänzt wurde ausserdem, dass **zwei Displays parallel**
>    unterstützt werden: das 7-Segment-Display (nur Pegelanzeige) und das
>    HDMI-Display (Kiosk-Modus). Betroffene Stellen: §2, §10.
> 2. Zurückgenommene Anforderung: §9 forderte ursprünglich einen
>    **Passwortschutz** der Weboberfläche. Diese Anforderung wurde bewusst
>    gestrichen — die Anwendung braucht kein Login, sie läuft im lokalen Netz.
>    Stattdessen schützt die Konfigurations-UI gezielt vor versehentlichem
>    Löschen der **Sensor-Kalibrierung**, durch mehrfache Rückfrage (inkl.
>    Eintippen der Sensor-ID beim vollständigen Löschen). Das SMTP-Passwort
>    (Zugangsdaten zum externen Mailserver) ist davon nicht betroffen und
>    bleibt bestehen. Betroffene Stelle: §9.
> 3. Präzisierung: §10 lässt für die Aufbau-3-Bedienung in Grafana ausdrücklich
>    "einbetten **oder verlinken**" zu. Umgesetzt wurde **verlinken**
>    (Dashboard-Link + Text-Panel-Button, per Grafana-Variable
>    `pegelwatch_url` konfigurierbar) statt eines eingebetteten iframes, weil
>    Grafana HTML/iframes in Text-Panels standardmässig aus Sicherheitsgründen
>    saniert (serverseitige Einstellung `disable_sanitize_html`, die man nicht
>    voraussetzen sollte). Betroffene Stelle: §10.
> 4. Ergänzung: §7 nennt InfluxDB 2.x nur als dokumentierte Rückfalloption für
>    den 2-GB-Pi 4. Diese Rückfalloption ist inzwischen **tatsächlich
>    implementiert** (`api_version = "v2"` je InfluxDB-Ziel, eigener
>    v2-Line-Protocol-Schreib-Client ohne zusätzliche Abhängigkeit), nicht nur
>    dokumentiert. Betroffene Stelle: §7.
>
> 5. Ergänzung: Die Weboberfläche tritt jetzt je nach aktivem Aufbau unter
>    einem eigenen Produktnamen auf statt immer "PegelWatch": **Aufbau 1 =
>    RIVERWatch, Aufbau 2 = SEPWatch, Aufbau 3 = PUMPWatch**
>    (`config.AppNameForAufbau`, verwendet in Titel/Kopfzeile aller Seiten).
>    "PegelWatch" bleibt nur als neutraler Fallback (z.B. Repository-/Binary-Name).
>
> 6. Korrektur (nach Prüfung gegen die offizielle Dokumentation, wie in §13
>    gefordert): **Raspberry Pi Connect bietet keinen skriptbaren
>    `ssh <Ziel>`-Zugang**, sondern ausschließlich eine Browser-Remote-Shell
>    (WebRTC). Die ursprüngliche Annahme, ein Connect-Ziel ließe sich einfach
>    als `-PiHost` an `deploy.ps1` übergeben, war unbestätigt und ist damit
>    hinfällig. Umgesetzt statt dessen: `deploy.ps1`/`deploy-fleet.ps1` bleiben
>    transportunabhängig (jedes per SSH erreichbare Ziel, z. B. LAN oder VPN),
>    und ein neues Geräte-Register (`deploy\devices.psd1`) plus
>    `deploy-fleet.ps1` erlauben das Deployment eines oder mehrerer der drei
>    Geräte (RIVERWatch/SEPWatch/PUMPWatch) über einen einzigen Befehl mit
>    `-Device`-Auswahl. Raspberry Pi Connect bleibt als manueller
>    Browser-Notzugriff sinnvoll, nur nicht als Deploy-Transport. Betroffene
>    Stelle: §13.
>
> 7. Zurückgenommene Einschränkung: Die Kiosk-Seiten (`/pump-kiosk`,
>    `/aufbau2-kiosk`) waren serverseitig auf Localhost beschränkt (nur der
>    direkt angeschlossene Bildschirm durfte sie öffnen). Diese Beschränkung
>    wurde entfernt, damit sie zu Test-/Kontrollzwecken auch von einem anderen
>    Gerät im selben Netzwerk abrufbar sind — ein zusätzlicher
>    Sicherheitsgewinn bestand ohnehin nicht, da die zugehörigen
>    Steuer-Endpunkte (z. B. `/api/pump/mode`) bereits netzwerkweit erreichbar
>    waren. Betroffene Stelle: §2/§10.
>
> 8. Ergänzung: **Standard-Kalibrierungsvorlage.** Auf der Konfigurationsseite
>    kann die Kennlinie eines fertig kalibrierten Sensors per Knopf ("★ Als
>    Standard setzen") als Vorlage abgelegt und bei baugleichen Sensoren per
>    Knopf ("⬇ Standard übernehmen") wieder eingesetzt werden — spart
>    erneutes Vermessen bei identischer Sensor-/AFE-Hardware. Gespeichert als
>    neues, optionales Feld `default_calibration` in `config.toml`
>    (`internal/config.Config.DefaultCalibration`), wirkt sich nicht auf den
>    Messbetrieb aus. Das Übernehmen überschreibt die Ziel-Kalibrierung und
>    ist deshalb genauso doppelt abgesichert (Rückfrage + Sensor-ID-Eingabe)
>    wie das Löschen einer Kalibrierung. Betroffene Stelle: §9.
>
> 9. Ergänzung: **Einheitliches Layout aller Seiten.** Die Konfigurationsseite
>    ist die gestalterische Vorlage (§13) — Startseite und Handbuch verwenden
>    jetzt dieselbe THW-Gestaltung aus einer gemeinsamen Quelle
>    (`internal/web/templates/layout.html`, Templates `thw-style`/
>    `thw-header`) statt eigener CSS-Kopien. Die Startseite zeigt zusätzlich
>    eine Sitemap mit allen angebotenen Seiten/URLs (inkl. Kiosk-Ansichten),
>    dieselbe Komponente wie im Systemstatus der Konfigurationsseite.
>    Betroffene Stelle: §11, §13.
>
> 10. Präzisierung und Erweiterung (Referenz-Modus, §2/§9): Gewollt ist **eine
>     Spannungsreferenz pro Stapel** zur Kompensation des ratiometrischen
>     Drucksensor-Signals; akzeptiert wird, dass die bis zu vier Boards
>     untereinander leicht unterschiedliche Referenzspannungen haben könnten.
>     Umgesetzt über ein neues, optionales Feld `ref_board_addr` je Sensor
>     (weggelassen = Referenz auf dem eigenen Board, also "pro Board"): geben
>     alle Sensoren dasselbe Referenz-Board und denselben Referenzkanal an,
>     teilt sich der ganze Stapel eine Referenz und es bleiben **bis zu 15
>     Messkanäle** frei (statt 12 bei "pro Board"). Die Validierung erzwingt
>     zusätzlich, dass kein Messkanal mit einem (fest verdrahteten)
>     Referenzkanal kollidiert. Betroffene Stellen: §2, §9.
>
> 11. Erledigt-Vermerk (§4): Die vier Feinparameter der adaptiven Abtastung
>     (Sprungschwelle 10 %, absolutes Totband 2 mm, Fenstergröße 100,
>     Stabilitätsschwelle 1 %) waren intern vorhanden, aber nicht
>     konfigurierbar. Sie sind jetzt in `config.toml` (`[polling]`:
>     `jump_pct`, `jump_abs_mm`, `stable_window`, `stable_pct`) und in der
>     Konfigurations-UI einstellbar — damit ist "Alle Schwellwerte und Zeiten
>     sind konfigurierbar" vollständig erfüllt. Betroffene Stelle: §4.
>
> 12. Präzisierung (§8 "Zugangsdaten verschlüsselt at rest"): Schutzziel ist
>     der Schutz vor **versehentlichem Ändern/Mit-Exportieren** (Nutzerfehler),
>     nicht vor einem böswilligen Angreifer mit Zugriff auf den Pi. Die
>     umgesetzte §9-Variante — separate `secrets.toml`, Dateirechte 0600, beim
>     Export der portablen Konfiguration nie enthalten — erfüllt dieses Ziel;
>     eine lokale Verschlüsselung (deren Schlüssel auf demselben Gerät läge)
>     wird bewusst nicht nachgerüstet. Betroffene Stelle: §8.
>
> 13. Neue Anforderung: **Testsensor (Simulation ohne Messhardware).** Ein
>     Sensor kann per `[sensor.simulation]` (`enabled`, `mean_mm`,
>     `amplitude_mm`, `period_s`) als Testsensor definiert werden: er wird wie
>     ein normaler Sensor konfiguriert (Kalibrierung, Behälter, Alarme),
>     erzeugt seinen Pegel aber rechnerisch (Grundpegel + Sinus) statt von der
>     ADS1115-Hardware zu lesen — damit ist die komplette Funktionalität auf
>     einem Raspberry Pi ohne angeschlossene Messhardware prüfbar. Der Sinus
>     ist bewusst gewählt, um die Umschaltpunkte der adaptiven Abtastung (§4)
>     sichtbar zu machen; zusätzlich verschiebt ein Schieberegler in der
>     Konfigurations-UI den Grundpegel live (Alarm-/Pumpenschwellen gezielt
>     auslösen). Testsensoren belegen kein Kanalbudget; sind alle Sensoren
>     simuliert, startet die Anwendung auch ohne I²C-Bus. Dokumentation:
>     `docs/05-testsensor.md`.
>
> 14. Bereinigte Inkonsistenzen (Audit Juli 2026): veraltete
>     Passwortschutz-Hinweise entfernt (`config.toml.example`, Code-Kommentare
>     — Folge von Punkt 2); Sitemap-Beschreibung der Kiosk-Seiten an Punkt 7
>     angepasst ("netzwerkweit abrufbar"); das `enabled`-Flag je Sensor wird
>     jetzt tatsächlich beachtet (deaktivierte Sensoren werden weder gepollt
>     noch belegen sie Kanalbudget; fehlendes Feld gilt als aktiv);
>     `docs/02-konfiguration.md` an §2-Kanalkonvention (Kanal 0 = Referenz,
>     Kanal 1 = erster Drucksensor), einheitliche Aufbau-Benennung
>     (Einzelsensor/Mehrkanal/Pumpwerk = RIVERWatch/SEPWatch/PUMPWatch) und
>     die fehlenden Abschnitte (`[throughput]`, `[pump_control]`,
>     `[overcurrent]`, `[grafana]`) ergänzt; `[pump_control]` erhält bei
>     komplett fehlender Konfiguration sichere Defaults (3000/500 mm), statt
>     im Auto-Modus sofort anzulaufen.
>
> 15. Erweiterung (§2 "harte Obergrenze 4 Boards"): Die Grenze von 4
>     ADS1115-Boards (Adressen 0x48–0x4B) gilt physikalisch **je I²C-Bus**.
>     Umgesetzt wurde die Unterstützung **mehrerer I²C-Busse**: ein zweiter
>     ADS1115-Stapel läuft auf einem per Device-Tree-Overlay aktivierten
>     Zusatz-Bus (Empfehlung `dtoverlay=i2c6` → GPIO22/23 — die einzige Wahl
>     ohne jede Kollision; bei i2c3/i2c5 wird je ein Relaiskanal unbrauchbar,
>     dokumentiert in docs/04-verdrahtung.md). Konfiguration: `i2c_bus` je
>     Sensor, optionale Pin-Deklaration `[i2c.bus_pins]` für abweichende
>     Overlay-Pins/Pi-5-Overlays. Die Validierung prüft die
>     GPIO-Interferenzfreiheit **aufbauübergreifend** (RIVERWatch/SEPWatch/
>     PUMPWatch): SDA/SCL aller genutzten Busse, SPI0-Display, Relais-Pins und
>     Pneumatik-Leitung dürfen nie kollidieren, auch wenn der betroffene
>     Verbraucher erst nach einem Aufbau-Wechsel aktiv würde. Die Referenz
>     ("pro Stapel", Punkt 10) gilt je Bus — Vollausbau damit 2 × 15 = 30
>     Drucksensoren. Ressourcenbetrachtung: docs/06-ressourcenanalyse.md.
>     Betroffene Stellen: §2, §9.
>
> 16. Neue Anforderungen (Betriebserfahrung Inbetriebnahme PUMPWatch, Juli 2026):
>     - **Testmail-Button** in der SMTP-Sektion der Konfigurations-UI
>       (`POST /api/smtp/test`) — prüft Server/Port/TLS/Zugangsdaten sofort;
>       über die UI gespeicherte Zugangsdaten wirken ohne Neustart.
>     - **Build-Zeitstempel** (Datum + Uhrzeit) wird beim Kompilieren
>       eingebettet (`-ldflags -X main.buildTime=…` in deploy.ps1/build.ps1)
>       und im Systemstatus angezeigt.
>     - **Maximallaufzeit der Pumpe** (`max_runtime_s`, Default 120 s, 0 = aus):
>       Zwangsabschaltung als Trockenlauf-/Luftschutz; Folgeverhalten
>       konfigurierbar (`max_runtime_action`: "lock" = Modus → Aus bis zum
>       bewussten Moduswechsel [Default], "cooldown" = nach 5 min wieder frei).
>       Alarm per Mail + Relais.
>     - **Laufbericht je Pumpenlauf** per E-Mail: Start/Ende/Dauer,
>       Abschaltgrund, Min/Mittel/Max je Phase, Stromverlauf-Diagramm (PNG,
>       in reinem Go gezeichnet) als Anhang und Grafana-Link auf das exakte
>       Zeitfenster (5-s-Abtastung aus dem Shelly-Poll).
>     - **Mail bei Betriebsmodus-Umschaltung** (Kiosk-/Web-Buttons
>       Automatik/Ein/Aus), mit altem/neuem Modus und Zeitpunkt.
>     - **Freifall-Schwelle in Spannung statt Druck** (`freefall_volts_mv`
>       ersetzt `freefall_pressure_pa`; alte Pa-Werte werden beim Laden
>       automatisch über die MPXV5050DP-Kennlinie migriert).
>     - **Moduswechsel → Automatik übernimmt den Soll-Zustand sofort** anhand
>       des letzten gültigen Pegels (statt auf die nächste Messung zu warten);
>       Ein→Automatik stoppt ggf. sofort, Aus→Automatik startet ggf. sofort.
>     - **Kalibrierung extrapoliert oberhalb des höchsten Stützpunkts** linear
>       entlang des letzten Segments (begrenzt auf ~5,1 m) — wenige vermessene
>       Stützstellen (z. B. 50 mm) genügen für den vollen Messbereich.
>     - **Anzeige des Abtastzyklus** (schnell/langsam) je Sensor auf
>       Startseite, beiden Kiosks und im Messwert-Strom (`poll_fast`).
>     - **Pump-Kiosk:** Pegelskala richtet sich nach der Tankhöhe des
>       Primärsensors; kleine **Pfeil-Marker** zeigen alle definierten
>       Schwellen (Pumpe EIN/AUS um den Offset korrigiert, Hoch-/Niedrig-
>       wasser-Alarm) direkt am Gauge.
>     - **Board-Adressauswahl aus dem I²C-Scan:** Die Konfigurations-UI bietet
>       für Board-/Referenz-Board-Adresse nur beim Start tatsächlich gefundene
>       Adressen des jeweiligen Busses an (manuelle Eingabe bleibt als
>       gekennzeichneter Sonderfall möglich) — verhindert falsche
>       Default-Adressen ohne Anzeige.
>     - **Sitemap-Anzeigenamen:** Links heißen jetzt sprechend —
>       `/pump-kiosk` = "Hebewerk_Kiosk", `/aufbau2-kiosk` = "Mehrkanal_Kiosk"
>       (URLs unverändert).
>     - **Fehlerbehebungen:** Shelly-Netzscan erkannte reale 3EM-Geräte nicht
>       (Gen1 meldet sich als "SHEM-3", der Filter suchte "3EM" — jetzt
>       Modellcode-Liste + `num_emeters`-Fallback); Scan übersprang große
>       DHCP-Subnetze komplett (/16) — jetzt Begrenzung auf das /24 um die
>       eigene Adresse; SMTP-EHLO sendete "localhost" (strenge Server: "550
>       Invalid HELO name") — jetzt Adress-Literal der eigenen IP, per
>       `[smtp] helo` überschreibbar; fehlgeschlagene Alarm-Mails werden mit
>       5-Minuten-Backoff wiederholt statt im Messtakt; unvollständige
>       InfluxDB-Konfiguration (Token fehlt) deaktiviert das Ziel mit Warnung
>       statt Absturzschleife; Chromium-Kiosk-Profil liegt auf der RAM-Disk
>       (eine frühere Neustartschleife hatte 19 GB Telemetrie auf die
>       SD-Karte geschrieben); Speichern-/Start-Konsistenz
>       der Kalibrierung (ungültige Kennlinie blockiert nicht mehr den Start,
>       sondern wird beim Speichern abgelehnt); ungültige Shelly-URLs werden
>       beim Speichern abgelehnt statt Dauerfehler zu loggen; Chromium-Kiosk:
>       Binary-Name `chromium`/`chromium-browser`, kein Endlos-Neustart ohne
>       Display; systemd-Unit: `/etc/pegelwatch` beschreibbar
>       (Konfigurations-UI konnte sonst nicht speichern), Unit wird bei jedem
>       Deploy aktualisiert, `Restart=always` + Neustart-Button in der UI.
>
> 17. Neue Anforderungen (Betriebserweiterung Juli 2026):
>     - **Frei konfigurierbare Logik-Relaisausgänge** auf den freien
>       Waveshare-Kanälen CH4–CH8 (`[[logic_output]]`, nur Aufbau 3): Ein
>       beliebiges Quellsignal aus dem zentralen Signal-Register
>       (`/api/signals` — alle im System erzeugten/verarbeiteten Werte:
>       Pegel, Spannungen, Volumina, Shelly-Ströme/-Leistungen,
>       Pi-Temperaturen, sowie Statuswerte wie Pumpe läuft, Alarme aktiv,
>       Dienst erreichbar) wird mit einem Vergleichsoperator (`> >= < <= == !=`)
>       gegen einen Festwert geprüft. Ist die Bedingung länger als die
>       **Totzeit** ununterbrochen erfüllt, schaltet das Relais ein (und nach
>       der Totzeit wieder aus). Der Festwert ist typabhängig: numerisch in
>       der Einheit der Quelle, bei Statussignalen aktiv/inaktiv. Name je
>       Ausgang frei wählbar. Die UI bietet die Quellsignale sortiert/
>       gruppiert mit Live-Wert an und beschränkt die Operatoren je Signaltyp.
>       Fehlende/veraltete Quellen ⇒ sicherer Aus-Zustand; GPIO-Kollisionen
>       werden validiert. Implementierung: `internal/signals`,
>       `internal/logicout`, `relay.LogicSwitch`.
>     - **Aktuelles Behältervolumen + Gesamtvolumen** im Hebewerk-Kiosk
>       (Pumpenkiosk), sofern für den Primärsensor eine Behältergeometrie
>       konfiguriert ist (`current_liters / capacity_liters`).
>     - **Vollbild-Umschaltknopf** in beiden Kiosks (Hebewerk/Mehrkanal):
>       Die Kiosks laufen künftig im Browser-Vollbild; da kein Keyboard
>       angeschlossen ist (kein F11/ESC), schaltet ein kleiner Button in der
>       Kopfzeile den Vollbildmodus per Fullscreen-API um.
>     - **Betriebs-Fix InfluxDB:** Ein WAL-Konflikt (durch die manuelle
>       Ersteinrichtung zwei gleichzeitige Prozesse) hatte InfluxDB 3 sauber
>       beendet (`Restart=on-failure` griff daher nicht). Behoben: WAL
>       bereinigt, systemd-Unit auf `Restart=always` umgestellt.
>
> 18. Große Betriebserweiterung (Juli 2026):
>     - **Grafana-Dashboards neu erstellt.** Die Mehrkanalanzeige (SEPWatch)
>       zeigt jetzt dynamisch alle konfigurierten Sensoren eines Stapels (bis
>       15, Grafana-`repeat` je `sensor_id`), Behältersummen (Gesamt-Füllstand,
>       Gesamtdurchsatz/-füllung seit Nullung) und Durchsatz-Tagesbilanzen
>       (letzter Tag / 2 / 3 Tage / Woche / Monat, als Summe aller Behälter).
>       Das Pumpwerk-Dashboard (PUMPWatch) zeigt zusätzlich die Anzahl der
>       Pumpvorgänge (Nullpunktkalibrierungs-Timing).
>     - **Robuste Durchsatzbilanz.** Zusätzlich zum genullten `drained_liters`
>       wird ein nie genulltes, monoton steigendes `lifetime_drained` je Sensor
>       geschrieben; die Tagesbilanzen (`spread` über das Zeitfenster) sind so
>       unbeeinflusst von Messstellennullungen. Jede Nullung merkt sich zudem
>       ihren Zeitpunkt je Sensor.
>     - **Nullpunktkalibrierung als dedizierte Kalibrierfahrt.** Wird sie fällig
>       (alle `self_cal_every` Pumpvorgänge), fährt die Pumpe im Automatikmodus
>       gezielt über die AUS-Schwelle hinaus, bis der Freifall-Druck (Spannung
>       < `freefall_volts_mv`) erreicht ist → Nullpunkt setzen. Die
>       **Maximallaufzeit begrenzt die Kalibrierfahrt** als Sicherheit: wird sie
>       ohne Freifall erreicht, Abbruch mit Warn-Mail, Kalibrierung auf den
>       nächsten Zyklus verschoben. Während der Fahrt zeigt der Kiosk ein
>       **rotes Vollbild-Popup** „Nullpunktkalibrierung aktiv".
>     - **Pumpvorgänge im Kiosk** (Anzahl + „Nullpunktkal. in N Vorgängen").
>     - **PDF-Betriebsbericht (THW-Design).** Über das 📄-Symbol in beiden
>       Kiosk-Kopfzeilen öffnet ein Popup (Empfänger, Bilanzzeitraum) zum
>       sofortigen Erstellen/Versenden; zusätzlich automatischer täglicher
>       Versand (`[report] daily_at`, `default_to`, `balance_hours`). Der
>       Bericht enthält einen allgemeinen Konfigurationsteil, je Sensor eine
>       Querformat-Seite mit Pegel-/Volumendiagramm und Kennzahlen sowie zwei
>       Summenberichte (Bilanz über den gewählten Zeitraum — Popup überschreibt
>       Konfiguration; und Bilanz je Sensor seit dessen letzter
>       Messstellennullung). Erzeugung als HTML (THW-CI) → Chromium (headless,
>       bereits auf dem Pi) → PDF. Alle Berichte werden unter **/berichte**
>       gelistet und geöffnet, physisch abgelegt in
>       `<state-db>/reports/` (180 Tage Aufbewahrung). Implementierung:
>       `internal/report`, `internal/chart.MultiSeriesPNG`.
>     - **Vollbild-Toggle** in beiden Kiosks (bereits Punkt 17) ergänzt um das
>       PDF-Symbol; Kopfzeilen-Buttons ohne Tastatur bedienbar.
>
> 19. Große Betriebserweiterung (Juli 2026) — **öffentliches Cloud-Frontend**
>     (Design + laufender Umsetzungsstand: `docs/08-cloud-frontend.md`). Ein
>     öffentlich erreichbares Frontend auf Shared-Webhosting
>     (**https://pegelwatch.gatecs.de**, serverprofis) zeigt den Status aller
>     Pi-Anlagen an einer Stelle, hinter Anmeldung. Architektur **alles
>     Pi-ausgehend** (die Pis sitzen hinter NAT — kein VPS/VPN/Tunnel, kein
>     Router-Eingriff): der Pi meldet Status per HTTPS (`internal/cloud`-Agent)
>     und holt dabei seine Befehle ab; das Frontend (PHP + SQLite, genau EINE
>     Datendatei, Umzug = Dateien kopieren) erreicht den Pi nie aktiv.
>     **Wichtig:** Der Passwortschutz-Verzicht aus Punkt 2 gilt nur für die
>     lokale Pi-Weboberfläche — das öffentliche Frontend hat bewusst ein echtes
>     Login (Registrierung, gehashte Passwörter, Sessions, CSRF, Rate-Limiting),
>     Admin-Freigabe von Konten/Anlagen und Pi-Zuteilung je Nutzer.
>     - **Umgesetzt & live:** Statusübersicht (adaptiv 1…30 Sensoren, Pumpe/
>       Alarme/Build/CPU), Pi-Detailseite mit Sensor-Tabelle, Erreichbarkeits-
>       anzeige auf der Pi-Startseite; Mehrbenutzer mit Rechten/Zuteilung
>       (sehen / sehen+steuern); **Füllgrad gegen operativen Sollwert** je
>       Sensor (`full_level_mm`, sonst Aufbau-3-Pump-Start-Pegel bzw.
>       Hochwasser-Schwelle; >100 % = überfüll, Alarm weiterhin über den
>       Hochwasser-Alarm); **Config-Backup** (jeder Pi sichert seine
>       geheimnisfreie `config.toml` im Frontend — Hash-Abgleich je Meldung,
>       Aktualitäts-Check + Download, Basis für ein neues Gerät).
>     - **Umgesetzt (Code fertig, Pi-Verifikation ausstehend):** Befehls-
>       Warteschlange mit **„Erstelle Bericht"** — der Pi holt Befehle beim Ingest
>       ab, erzeugt über den bestehenden `report.Generator` das PDF **und** einen
>       Kiosk-Snapshot aus derselben `kiosk.html`-Quelle via Shim (unverändert,
>       abgesichert durch einen erzwingenden Test) und meldet beides mit
>       Prüfsummen zurück; das Frontend zeigt Berichte (Download) und die
>       Kiosk-Ansicht (abgeschotteter Sandbox-iframe) auf der Pi-Detailseite.
>     - **Offen:** **„Update"** (Selbst-Update des Binaries, Root-Installer per
>       systemd-path-unit). Neue Werkzeuge: `deploy-web.ps1` (Frontend per
>       explizitem FTPS), `[cloud]`-Abschnitt in `config.toml`/`secrets.toml`,
>       Geräte-Register (`deploy/devices.psd1`) um weitere Pis erweiterbar.
>
> > 20. Betriebserweiterung Juli 2026 — **Fließgewässer-Messstelle, Kiosk-Log,
>     geordnetes Abschalten** (Stand 31.07.2026, auf allen drei Anlagen
>     ausgerollt und im Betrieb geprüft).
>
>     **a) Gewässer-Querschnitt und Durchfluss (Aufbau 1).** Eine Messstelle im
>     Bach/Fluss bekommt ein Querschnittsprofil als **Stapel von Trapezen**
>     (je Stützpunkt Höhe über der Sohle + Gewässerbreite dort; unterster Punkt
>     zwingend auf Höhe 0). Daraus die benetzte Fläche beim aktuellen Pegel und
>     — mit der Fließgeschwindigkeit — der Durchfluss (Q = A · v).
>     Geschwindigkeit **wahlweise** über Stützstellen (Pegel → m/s, linear
>     interpoliert, außerhalb konstant) **oder** Manning-Strickler
>     (v = k · R^⅔ · I^½). Oberhalb des Profils wird mit senkrechten Wänden
>     weitergerechnet. Neues Paket `internal/profile` (20 Tests),
>     `[sensor.profile]` in der Konfiguration, Werte in SSE, Signal-Register
>     (`profile.<id>.*`, Gruppe „Gewässer") und in der Konfigurations-UI mit
>     **Live-Vorschau** des Querschnitts beim Eintippen.
>
>     **b) Fluss-Kiosk** (`/fluss-kiosk`, Sitemap „Fluss_Kiosk"): Layout wie der
>     Pumpenkiosk (1024×600), links der maßstäbliche Querschnitt mit dem
>     Wasserstand als blauer Fläche, rechts Pegel / Querschnittsfläche /
>     Durchfluss / Fließgeschwindigkeit, darunter der Pegelverlauf
>     (1 h … 7 d). **Ohne** konfiguriertes Profil ein symbolisches Trapez,
>     ausdrücklich als „symbolisch" gekennzeichnet.
>
>     **c) Betriebstagebuch in ALLEN Kiosken** (Knopf 📜): klappt von unten auf,
>     Neuestes oben, Aktualisierung alle 15 s **nur solange sichtbar**.
>     Einfärbung **nach Inhalt zuerst, Art als Rückfall** (rot Alarm/Überstrom/
>     Leckage, gelb Zwangsabschaltung/Maximallaufzeit, grün Entwarnung, blau
>     Pumpenlauf, violett Bedienhandlung, grau System); der Knopf färbt sich rot,
>     sobald Alarm-Einträge vorliegen. Neuer Endpunkt `/api/events`.
>
>     **d) Geordnetes Herunterfahren** — Knopf ⏻ in jedem Kiosk **und** Befehl
>     im Cloud-Frontend. Motiv: Ein Pi im Feld hat kein Terminal; hartes
>     Ausschalten hat schon eine korrupte InfluxDB verursacht.
>     - Kiosk: rote Sicherheitsabfrage, serverseitige Bestätigungsphrase,
>       Fehlschläge werden **angezeigt** statt verschluckt.
>     - Cloud: bewusst umständlicher, weil der Auslöser **nicht vor Ort** ist —
>       Pflichthaken „nur vor Ort wieder einschaltbar", getipptes
>       `HERUNTERFAHREN` (auch serverseitig geprüft), letzte Rückfrage; die Seite
>       benennt ausdrücklich: kein Wake-on-LAN, keine Alarm-Mails mehr,
>       Ausführung erst beim nächsten Kontakt. Der Agent meldet das Ergebnis,
>       **bevor** systemd ihn beendet.
>     - **7-Segment-Anzeige:** umlaufender **Ladekreis** während des
>       Herunterfahrens, **`AUS`** erst ganz am Ende — geschrieben vom
>       systemd-Hook `/usr/lib/systemd/system-shutdown/pegelwatch-display`
>       (`pegelwatch --display-off`), nachdem die Dateisysteme ausgehängt sind.
>       Erst dieses `AUS` heißt „Strom darf getrennt werden"; ein früheres
>       „OFF" hätte genau zum verfrühten Steckerziehen verleitet.
>
>     **e) Kiosk-Selbstanzeige konfigurierbar** (`[web] kiosk`): `auto`
>     (Standard, nach Aufbau: 1 → Fluss, 2 → Mehrkanal, 3 → Hebewerk), feste
>     Seite oder `off` für Anlagen ohne Monitor.
>
>     **f) 7-Segment-Display** ist jetzt auch in der Konfigurations-GUI
>     schaltbar (vorher nur in der `config.toml`).
>
>     **Behobene Fehler (alle mit Regressionstest):**
>     - **Überstrom-Alarm hing dauerhaft am Relais.** Die Alarmquelle
>       `"overcurrent"` wurde nirgends zurückgenommen — das Alarmrelais blieb
>       nach einer Überstromabschaltung bis zum Dienstneustart angezogen
>       (real aufgetreten: PUMPWatch, 22.07.–28.07.2026). Sie wird jetzt beim
>       nächsten Pumpenstart quittiert, wie `"maxruntime"`.
>     - **Anlaufstrom schaltete die Pumpe ab.** Neue Karenz
>       `overcurrent_grace_s` (Default 8 s), bewertet nach dem **Messzeitpunkt**
>       des Shelly-Werts, nicht nach dem Auswertezeitpunkt — der Zähler wird nur
>       alle 5 s gelesen, ein Anlaufwert bleibt sonst bis zu 5 s „aktuell".
>     - **Nullen der Behältersummen wirkungslos.** Die Kioske senden `FormData`
>       (multipart); ein vorgeschaltetes `r.ParseForm()` liest aber nur
>       urlencodete Körper und verhinderte, dass `r.FormValue` nachlädt → HTTP
>       400 „sensor fehlt". Fiel lange nicht auf, weil ein Testaufruf mit
>       `curl -d` (urlencoded) funktionierte.
>     - **Zeitraum-Auswertung nach dem Nullen negativ.** `Tracker.Reset()` ließ
>       die Snapshot-Historie stehen; `PeriodDelta` rechnete gegen den Stand
>       **vor** der Nullung — bis zu 30 Tage lang stark negative Werte.
>     - **Kiosk-Selbstanzeige startete auf KEINER Anlage.** Der Dienst läuft als
>       systemd-Systemdienst ohne Sitzungsumgebung; ohne `DISPLAY` beendet sich
>       Chromium sofort. `internal/gui` ergänzt `DISPLAY`/`XAUTHORITY` jetzt
>       selbst (ein leerer Eintrag wird **ersetzt**, nicht überlagert).
>     - **Abschalten scheiterte trotz NOPASSWD-sudo.** Die Unit läuft mit
>       `NoNewPrivileges=true` — damit greift das setuid-Bit von `sudo` nicht
>       mehr, während dasselbe `sudo` über SSH einwandfrei funktioniert. Lösung:
>       direkter `systemctl poweroff`, freigegeben durch die polkit-Regel
>       `/etc/polkit-1/rules.d/50-pegelwatch-poweroff.rules` (nur `power-off`,
>       nur für den Dienstbenutzer); sudo bleibt Rückfall. Jeder Fehlversuch wird
>       jetzt **protokolliert** — dass er es vorher nicht wurde, hat die
>       Fehlersuche über mehrere Runden verlängert.
>
>     **Werkzeuge:**
>     - Die **Bedienungsanleitung wird nicht mehr bei jedem Build erzeugt**,
>       sondern nur mit `-BuildManual` (`build.ps1`, `deploy.ps1`,
>       `deploy-fleet.ps1`). Damit weicht der Auftrag aus §11 („automatisch beim
>       (Neu-)Kompilieren generiert") bewusst zu einem Opt-in ab: Der Generator
>       dauert um ein Vielfaches länger als Build und Deploy zusammen.
>     - Der Generator hatte den Deploy **blockiert**: headless-Browser-Aufruf
>       ohne Zeitgrenze, Argumente mit Leerzeichen wurden von `Start-Process`
>       nicht gequotet (Projektpfad „01 Daten"), und Seiten mit offener
>       **SSE-Verbindung** gelten dem Browser nie als fertig geladen. Jetzt:
>       Wachhund mit Abbruch, korrektes Quoting, und `?nolive=1` — die Seiten
>       öffnen dann keine Dauerverbindung, sondern spielen den zuletzt gesendeten
>       Stand einmal ab (`/api/sse/retained`, dem Snapshot-Shim bekannt gemacht).
>
>     **Offen / bewusst nicht gemacht:**
>     - Durchfluss und Querschnittsfläche werden **nicht** nach InfluxDB
>       geschrieben (für eine Grafana-Kurve wäre das nachzurüsten).
>     - Das systemd-Journal ist auf den Anlagen **nicht persistent**; technische
>       Logs sind nach einem Neustart weg (das Betriebstagebuch in `state.db`
>       überlebt dagegen). `Storage=persistent` wäre der Hebel.
>     - Die Simulation auf SEPWatch erzeugt mit ±600 mm Amplitude rund
>       108 Mio. Liter Durchsatz pro Tag und Sensor — die kumulierten Zähler sind
>       dort ohne Aussagekraft. Bewusst so belassen.
>
> 20. **Abschluss-Stand (1. August 2026) — letzter vollständiger Build und
>     Flottendeploy.** Dieser Punkt hält fest, was zum Projektabschluss
>     tatsächlich gebaut, ausgerollt und geprüft wurde — als Referenz dafür,
>     welcher Stand auf den Anlagen läuft.
>
>     **Gebauter Stand:** Build-Label `2026-08-01 09:49:06 (1cd415d)`,
>     cross-kompiliert für linux/arm64 (`CGO_ENABLED=0`), 31 MB. Vorher
>     `go vet ./...` und `go test ./...` über alle 24 Pakete — beides ohne
>     Befund. Das Binary wurde **einmal** gebaut und identisch an alle Ziele
>     verteilt (Pis + Cloud-Update-Ablage), damit kein Gerät ein
>     Phantom-„Update verfügbar" meldet.
>
>     **Dokumentation:** Die Bedienungsanleitung wurde mit `-BuildManual` neu
>     erzeugt (7 Screenshots aus der laufenden UI, `bedienungsanleitung.html`
>     88 KB, `.pdf` 1,68 MB) und ist zusammen mit `docs/` und den
>     Grafana-Dashboards als Bundle nach `/usr/local/share/pegelwatch` auf jede
>     erreichte Anlage gezogen worden (30 Dateien).
>
>     **Ausrollstand je Gerät** (`deploy-fleet.ps1 -AllKnownHosts -BuildManual`):
>     - **PUMPWatch** (Aufbau 3, 192.168.0.106) — **erfolgreich**. Dienst aktiv,
>       Update-Mechanismus (Binary + OS-Update), Abschaltberechtigung und
>       Abschaltanzeige eingerichtet, 3 Grafana-Dashboards provisioniert. Über
>       `/api/hardware` verifiziert: läuft auf Build `2026-08-01 09:49:06 (1cd415d)`.
>     - **SEPWatch** (Aufbau 2, 192.168.0.198) — **erfolgreich**, identischer
>       Umfang, gleiche Build-Kennung verifiziert.
>     - **PEGELWatch** (Aufbau 1, 192.168.0.56) — **nicht ausgerollt**: Der Host
>       war nicht erreichbar (`connect to host 192.168.0.56 port 22: Connection
>       timed out`, auch kein ICMP-Echo). Das Gerät läuft damit weiter auf
>       seinem vorherigen Stand. Der Fleet-Lauf isoliert Gerätefehler bewusst in
>       eigenen Prozessen und hat die übrigen Anlagen normal zu Ende deployt;
>       der Gesamt-Exitcode war deshalb 1 bei zwei erfolgreichen Geräten.
>       **Nachzuholen, sobald der Pi wieder am Netz ist:**
>       `.\deploy-fleet.ps1 -Device PEGELWatch`. Hinweis: Der Deploy meldete
>       zusätzlich, der Pi kenne den Deploy-Key noch nicht — das ist bei einem
>       toten Host nicht aussagekräftig; sollte es nach dem Wiederanlauf
>       bestehen bleiben, ist der Public-Key aus
>       `%LOCALAPPDATA%\PegelWatch\deploy-keys\PEGELWatch.pub` einmalig in
>       `~/.ssh/authorized_keys` einzutragen.
>     - **Cloud-Frontend** (https://pegelwatch.gatecs.de) — **erfolgreich**:
>       24 Dateien (`html/`, `app/`, `cron/`) hochgeladen, Update-Binary
>       `pegelwatch-arm64-1cd415d` + `current.json` in `data/binaries/` abgelegt,
>       Erreichbarkeit und Schema geprüft.
>
>     **Betriebszustand von PUMPWatch bei Abschluss** (zur Einordnung, falls
>     später eine Anzeige rot erscheint): kein Prozessalarm aktiv — Hoch-,
>     Niedrigwasser und Leckage alle inaktiv, Pegel ~105 mm bei einer
>     Hochwasserschwelle von 535 mm (Niedrigwasser und Leckage sind auf dieser
>     Anlage abgeschaltet), Pumpe im Automatikmodus, Shelly und alle Dienste
>     erreichbar. Auf dem Pi standen zu diesem Zeitpunkt 48 apt-Updates aus;
>     die Pi-Detailseite des Cloud-Frontends stellt diesen Hinweis in derselben
>     roten Auszeichnung dar wie echte Alarme (`frontend/public/pi.php`) — das
>     ist kein Anlagenalarm.

Alle anderen Abschnitte sind unverändert der ursprüngliche Auftrag.

> **So benutzt du diesen Prompt:** Kopiere den gesamten Text in Claude Code (auf deinem Windows-Rechner in VS Code). Claude Code soll ihn als verbindliche Projektbeschreibung behandeln und die unten festgelegte **Reihenfolge** einhalten – insbesondere zuerst die Cross-Compiler-Einrichtung und das Einlesen vorhandener Unterlagen, **bevor** Code geschrieben wird.

---

## 0. Rolle und Arbeitsweise

Du bist mein Entwicklungspartner für eine eingebettete Mess- und Steuerungssoftware auf einem Raspberry Pi. Arbeite **schrittweise**, frage bei Unklarheiten nach, statt zu raten, und triff keine stillschweigenden Annahmen über Hardware, die du nicht aus den von mir bereitgestellten Unterlagen ableiten kannst. Halte dich an die unten genannten Defaultwerte, mache sie aber alle in der Konfiguration überschreibbar.

**Sprache:** Code-Kommentare und Commit-Messages auf Deutsch oder Englisch (deine Wahl, konsistent). **Anwender-Dokumentation ausschließlich auf Deutsch.**

---

## 1. Verbindliche Reihenfolge (bitte genau so abarbeiten)

1. **Sprachwahl bestätigen.** Lege mir deine begründete Empfehlung für die Implementierungssprache vor und warte auf mein OK. Meine Vorgabe: Ich entwickle auf einem **Windows-Rechner mit VS Code**, will möglichst einfach cross-kompilieren und das fertige Compilat über einen **Netzwerk-Share** auf den Pi legen und dort per Remote-Terminal starten. Empfohlener Default: **Go** (Cross-Compile aus Windows ohne Toolchain via `GOOS=linux GOARCH=arm64`, ein einziges statisches Binary, eingebauter Webserver). **Bedingung:** Nutze **reine-Go-Hardwarebibliotheken ohne CGO** (z. B. `periph.io`, `go-gpiocdev`/`gpiod`), sonst zerbricht der einfache Windows-Cross-Build. Wenn du eine bessere Option siehst, begründe sie.
2. **Cross-Compiler-Workflow einrichten.** Führe mich durch die Einrichtung:
   - Cross-Compile-Befehl(e) für **Raspberry Pi OS Bookworm, 64-bit, arm64**.
   - Ablauf „Build auf Windows → Ablage im Netzwerk-Share → Start per Remote-Terminal auf dem Pi". Der Entwicklungsrechner hat **nur Windows-Bibliotheken**; alles ARM-spezifische muss zur Build-Zeit ohne Pi-Toolchain funktionieren.
   - Lege ein Repository-Layout an, in das die bestehende Python-Logik kopiert werden kann.
3. **Vorhandene Unterlagen einlesen.** Bitte mich aktiv um:
   - die **bestehende Python-Implementierung** (nur der Messmodus: Polling + Mittelung + adaptives Umschalten). Sie beschreibt das gewünschte Mess-Verhalten; eine performantere Neuimplementierung ist ausdrücklich erlaubt.
   - die **Eagle-Designunterlagen der Sensorleiterplatte**: Netliste, Schaltplan, Layout, BOM. Werte daraus das **Analog-Front-End** aus (Verstärkung/Skalierung, welcher ADC-Kanal welchem Signal entspricht), weil das die Umrechnung Druck → Spannung → ADC-Wert und damit die Kalibriermathematik bestimmt.
   Beginne erst danach mit der Architektur.
4. **Architektur vorschlagen** (Tech-Stack frei wählbar), von mir freigeben lassen, dann implementieren.

---

## 2. Zielhardware (fix)

- **Rechner:** Raspberry Pi ab Version 4 (inkl. Pi 5). Beachte: Pi 5 greift anders auf GPIO zu (RP1); klassisches `RPi.GPIO` funktioniert dort nicht. Die GPIO-Bibliothek muss **Pi 4 und Pi 5** abdecken (libgpiod/gpiod bzw. reine-Go-Äquivalente).
- **Betriebssystem (verbindlich, da frisch installiert):** **Raspberry Pi OS Bookworm, 64-bit (arm64)**. Begründung: kompatibelste Wahl für Go-`arm64`-Cross-Compile, native arm64-Builds von InfluxDB und Grafana, moderne Bibliotheken. Da intern InfluxDB 3 läuft (siehe §7), zusätzlich **4-KB-Speicher-Seitengröße erzwingen** (`kernel=kernel8.img` in `/boot/config.txt`) – besonders auf dem Pi 5, sonst stürzt InfluxDB 3 beim Start ab. Empfohlen **≥ 4 GB RAM**.
- **AD-Wandler:** **ADS1115** (4 Kanäle, I²C). Die I²C-Adresse des ADS1115 (0x48–0x4B über ADDR-Pin) identifiziert zugleich das Board. **Maximal 4 gestapelte Boards = 4 Adressen = 16 Kanäle** (harte Obergrenze, kein 5. Board möglich). Die Software muss eine Zuordnung *I²C-Adresse → physischer Slot* führen und beim Start die vorhandenen Boards scannen.
- **I²C-Bus:** Der Pi steuert die ADS1115 über seinen I²C-Bus (I²C-1, GPIO2/GPIO3). Dieser Bus ist von der übrigen Waveshare-Hardware **nicht** belegt und muss reserviert bleiben.
- **Drucksensor:** **MPXV5050DP** – differenziell, **0–50 kPa**, **ratiometrisch zur 5-V-Versorgung**. Daraus folgt eine **physikalische Obergrenze von ca. 5,1 m Wassersäule pro Sensor**. Diese ~5,1 m reichen für die geplante Anwendung aus, sind aber als **harte Obergrenze** zu behandeln: Plausibilitätsprüfung der Kalibrierung (Stützstellen jenseits ~5 m sind unzulässig und müssen gewarnt werden); im Betrieb Annäherung an die Obergrenze kennzeichnen.
- **Referenzspannungs-Kanal:** In **jedem Aufbau** misst mindestens **ein** ADC-Kanal die Versorgungsspannung als Referenz, damit der ratiometrische Sensorwert kontinuierlich kompensiert werden kann. Konfigurierbar: **eine Referenzmessung pro Stapel** *oder* **eine pro Board**. Der erste Kanal eines Aufbaus ist die Referenz, der zweite Kanal des Boards ist der erste Drucksensor. **Der Referenzkanal ist genau zu diesem Zweck dauerhaft verdrahtet (nicht geschaltet)** und wird in **jedem Pollzyklus mitgelesen** und mit jeder Messung verrechnet (kontinuierlich ratiometrisch). Kanalbudget daraus z. B.: Aufbau 1 = 1 Referenz + 1 Drucksensor; Aufbau 2 = bis zu 15 Sensoren (1 Referenz/Stapel) bzw. 12 (1 Referenz/Board). Die Konfigurations-UI muss dieses Budget erzwingen.
- **Relaiskarte (nur Aufbau 3):** Waveshare **RPi Relay Board (B)**, 8 Kanäle, Ansteuerung über **GPIO** (kein I²C), Pins per Jumper wählbar. Die belegten Relais-GPIOs dürfen **nicht** GPIO2/GPIO3 (I²C) verwenden. Lastdaten beachten (max. 5 A / 250 V AC bzw. 5 A / 30 V DC, optogekoppelt).
- **Display (zwei Geräte, beide werden unterstützt):**
  - **7-Segment-Display** (MAX7219-Treiber, SPI): zeigt **ausschließlich den Pegelwert** des primären Sensors an (4-stellig, mm). Belegt SPI0 (GPIO8/10/11), kein I²C-Konflikt.
  - **Waveshare HDMI-Display**, Auflösung **1024×600** (Querformat) — *korrigiert: nicht mehr 480×800, diese Angabe war veraltet*. Kein Touch, Helligkeit/Versorgung über HDMI + USB (belegt weder I²C noch GPIO). Zielt auf den **Kiosk-Modus**: eine dedizierte, bildschirmfüllende Anzeige pro Aufbau (Aufbau 2: Mehrkanal-/Behälterübersicht; Aufbau 3: Pegel-Gauge + Pumpensteuerung + Shelly-Werte). **UI-Constraint:** alle Kiosk-Seiten müssen für **1024×600** ausgelegt sein.
- **Pneumatikpumpe:** über Rückschlagventile mit allen Sensorschläuchen verbunden (Drift-Kompensation, siehe §5).
- **Aufbau 3 zusätzlich:** Drehstrompumpe über **Schütz**, angesteuert über **Motorschutzschalter**, geschaltet über die Relaiskarte. Strommessung der drei Phasen über **Shelly 3EM** (per LAN-Scan zu finden, siehe §6).

---

## 3. Die drei Aufbauten

Über die Weboberfläche wählbar, welcher Aufbau aktiv ist. Gemeinsame Basis: adaptives Polling (§4), Kalibrierung (§4), ratiometrische Kompensation, Schreiben in InfluxDB (§7), Pneumatikpumpen-Drift-Kompensation (§5).

**Aufbau 1 – reine Wasserpegelmessung.** Ein Drucksensor (+ Referenz). Behältergeometrie und optionale Volumenberechnung (§4) verfügbar.

**Aufbau 2 – Mehrkanal, mehrere Gefäße (keine softwaregesteuerte Pumpe).**
- Mehrere parallele Sensoren, je Sensor ein **eigener Behälter** mit eigener Geometrie/Volumen.
- Je Behälter ein **Füllstand**; **summiertes eingefülltes Volumen** und **Durchsatzmenge** (abtransportiert) gemäß §4 (inkl. Wellen-Lösung); Anzeige von **aktuellem Gesamtbehältervolumen** und **Durchsatzmenge**. Auswertezeitraum konfigurierbar *(erledigt: Zeitraum-Auswahl 1h/24h/7d/30d im Aufbau-2-Kiosk, per periodischen Snapshots und Zeitfenster-Differenz; für längerfristige Auswertungen bleibt der Grafana-Zeitbereich auf `container_volume` die vollständige Quelle)*.
- Über die Konfiguration müssen sich die **Behältersummen nullen** lassen.
- Es gibt **externe Entnahmepumpen** (nicht Teil des Aufbaus, nicht softwaregesteuert), die die Behälter leeren und dabei **bekannte Pegelgradienten** erzeugen. Gefahr: ein Behälter könnte **leck schlagen oder zerreißen**. Erkennung über **schnelles Absinken des Pegels**: pro Behälter ist ein **erwarteter (maximaler) Entleer-Gradient** konfigurierbar; fällt der Pegel **steiler** als dieser Gradient → **Leckage-Alarm** (siehe §8).
- Alarme je Sensor: **Alarmpegel** (Hochwasser) und **Leerlaufpegel**, jeweils **einzeln an-/abschaltbar**, plus der genannte **Leckage-Alarm**. In Aufbau 1/2 erfolgt Alarmierung **nur per E-Mail** (kein Relaisausgang vorhanden).
- **Anzeige:** die bildschirmfüllende HDMI-Kiosk-Ansicht (1024×600, siehe §2) zeigt alle Behälter parallel mit Füllstand, aktuellem Volumen, Durchsatz und Leckage-Status.

**Aufbau 3 – Pumpwerk (Drehstrompumpe, Relaiskarte, Shelly 3EM).**
- **Regellogik Pumpwerk:** Pumpe **EIN bei hohem Pegel**, **AUS bei niedrigem Pegel** (oberer/unterer Pegel konfigurierbar).
- **Offset:** auf die Pegelwerte addierbar, wenn der Schlauch einige Zentimeter über dem Behälterboden endet.
- **Drift-Selbstkalibrierung durch Freifall:** Nach einer **konfigurierbaren Anzahl Pumpvorgänge** wird der Pegel so weit abgesenkt, dass der Schlauch frei hängt. Die Steuerung erkennt diesen Zustand, **wenn ein konfigurierbarer (Freifall-)Druck unterschritten wird** (parametrierbar, nicht hart 0, um Sensordrift abzufangen). Dann Nullpunkt neu setzen.
- **Strommessung:** Strom der drei Phasen über Shelly 3EM in die InfluxDB schreiben.
- **Überstrom:** konfigurierbare **Schwellwertabschaltung** (Pumpe via Relais aus) **plus Alarm** (E-Mail **und** Relaisausgang).
- **Unterstrom / Phasenausfall:** Alarm, wenn der Strom in einer oder mehreren Phasen zu klein ist (Unterbrechung). **Diese Diagnose nur aktiv, solange der Shelly korrekt verbunden ist und „alive" meldet** – ist der Shelly nicht erreichbar, Diagnose abschalten (keine Fehlalarme).
- **Alarm-Relaisausgang:** existiert **ausschließlich** in diesem Aufbau (Relaiskarte). Ein Ausgangskanal ist mit dem Alarm verbunden.
- **Fail-Safe:** Beim Absturz/Neustart der Software muss der Relaiszustand definiert sicher sein; sieh einen **Watchdog** vor.

---

## 4. Messung, adaptives Polling, Kalibrierung, Geometrie

**Adaptives Polling** (Verhalten aus der bestehenden Python-Implementierung übernehmen, performant neu umsetzen erlaubt):
- Sensor wird gepollt, Messwert gemittelt.
- **„Sprung" (langsam → schnell):** Der neue Messwert weicht um **> 10 % vom vorherigen Messwert** ab → Umschalten auf **schnelles** Pollen mit **250 ms** (Default). Der 10-%-Schwellwert ist parametrierbar.
- **„Sättigung / konstanter Wert" (schnell → langsam):** Über ein **Fenster von 100 Messwerten** ist die Signaländerung unter eine definierte Grenze gesunken (Wert ist konstant) → Umschalten auf **langsames** Pollen mit **20 s** (Default). Kriterium: die **Spanne (max − min) über das 100-Sample-Fenster relativ zum Mittelwert ≤ 1 %** (Default, parametrierbar). *Nebenrechnung: 100 × 250 ms = 25 s Beobachtung bis zur Umschaltung.*
- **Stabilität nahe Null:** Relative Schwellen (10 % / 1 %) sind bei fast leerem Behälter instabil (winzige Absolutänderungen lösen Scheinsprünge aus). Führe daher zusätzlich ein **absolutes Totband (Mindeständerung) als Parameter** ein: Ein Sprung gilt nur, wenn **relativ > 10 % UND absolut > Totband**. Schlage einen Default für das Totband anhand der AFE-Auflösung vor.
- **Alle Schwellwerte und Zeiten sind konfigurierbar und haben die genannten Defaultwerte.**

**Kalibrierung:**
- Eingabemaske für **mindestens 10 Stützstellen** (gemessener realer Wasserpegel ↔ Sensorwert).
- Umrechnung Druckwert → Wasserspiegelhöhe per **Regressions-/Polynom-Fit**. Vermeide Überschwingen bei vielen Stützstellen: nutze **Least-Squares mit niedrigem Grad** oder eine **monotone, stückweise** Variante; zeige den Fit-Fehler an. Stützstellen oberhalb der physikalischen Sensorgrenze (~5 m) ablehnen/warnen. *(erledigt: monotone stückweise lineare Variante gewählt, Fit-Fehler ist dadurch konstruktionsbedingt 0 — wird live in der Konfigurations-UI über `/api/calibration/check` angezeigt, inkl. Warnungen nahe der Sensorgrenze.)*

**Behältergeometrie & Volumen** (für optionale Volumen-/Mengenausgabe in InfluxDB):
- **Zylindrisch:** Eingabe über **Durchmesser**.
- **Quadratisch/Quader:** Eingabe über **Kantenlänge** (quadratische Grundfläche).
- **Kegel- bzw. Pyramidenstumpf:** Eingabe über **zwei Flächen (untere und obere) plus Höhe/Abstand** dazwischen; Querschnitt über die Höhe integrieren, um Pegel → Volumen zu berechnen.
- Wenn aktiviert, zusätzlich zur Pegelhöhe die **Behältermenge/-volumen** in die InfluxDB schreiben.

**Füllung, Durchsatz und Wellenproblem (vor allem Aufbau 2):**
- **Füllungsereignis:** beginnt, wenn der Pegel im Behälter **steigt** (positive Pegeländerung). „Mehrere Füllungen aufsummierbar" = summiertes eingefülltes Volumen (Integration der **positiven** Pegeländerungen, in Volumen umgerechnet).
- **Durchsatz:** entsteht erst beim **Entleeren** = **Integration der negativen Pegeländerungen**, in Volumen umgerechnet. Bedeutung: Menge, die einmal im Behälter war und bereits abtransportiert wurde.
- **Anzeigen:** (a) **aktuelles Gesamtbehältervolumen** (Summe der aktuellen Volumina aller Behälter), (b) **Durchsatzmenge** (kumuliert abtransportiertes Volumen). Beide auch in InfluxDB.
- **Wellenproblem (zwingend zu lösen):** Da nur **negative** Änderungen in den Durchsatz eingehen, würden Wellen/Schwankungen (deren Abwärts-Halbwellen) den Durchsatz **einseitig aufblähen**. Pflicht-Lösung:
  1. **Glättung** des Pegelsignals (gleitender Median/Mittelwert; baut auf der vorhandenen Mittelung auf), um hochfrequente Wellen zu entfernen.
  2. **Totband/Hysterese:** nur negative Änderungen **oberhalb eines konfigurierbaren Rausch-Totbands** zählen; Schwankungen innerhalb des Totbands werden ignoriert.
  3. **Trend-/Mindestdauer-Bedingung:** nur ein **anhaltender Abwärtstrend** gilt als echte Entnahme; kurze Oszillationen nicht.
  So mitteln sich Wellen heraus, statt sich einseitig aufzusummieren. Mache Glättungsfenster und Totband konfigurierbar und schlage Defaults vor.

---

## 5. Pneumatikpumpe (Drift-Kompensation)

- Alle Sensoren sind über Rückschlagventile mit der Pneumatikpumpe verbunden.
- **Start: zeit-/intervallgesteuert.** Die Pumpe läuft dann eine **vom Anwender in der Konfiguration eingetragene, feste Zeit** (drückt Luft in die Schläuche, bis am offenen Ende wieder Luft entweichen kann). Intervall und Laufzeit sind konfigurierbar.

---

## 6. Shelly 3EM (nur Aufbau 3)

- **Auffinden per Scan des lokalen Netzwerks**; gefundenes Gerät in der Konfiguration auswählbar/parametrierbar.
- Strom der drei Phasen auslesen und in InfluxDB schreiben.
- **Alive-/Verbindungsstatus** überwachen (steuert die Unterstrom-Diagnose, siehe §3).
- *Hinweis an dich:* Die HTTP-API unterscheidet sich je nach Shelly-Generation (Gen1 vs. Gen2/Pro). Lege den abgefragten Typ in der Konfiguration fest oder erkenne ihn automatisch; frag mich, falls nötig, nach der genauen Gerätevariante.

---

## 7. Datenbanken (InfluxDB) und FHEM

- **Alle drei Aufbauten** schreiben in eine **lokale InfluxDB** (Pflicht).
- **Zweite, optionale InfluxDB:** Die „FHEM-Anbindung" dient **ausschließlich der Messwertübertragung**. Der FHEM-Server hat eine eigene InfluxDB. Realisiere das als **optionales zweites InfluxDB-Schreibziel** (direkt in die DB des FHEM-Servers schreiben, kein FHEM-eigenes Protokoll nötig). **Diese zweite Instanz ist InfluxDB 3.x.**
- **Versionsentscheidung:** Verwende **InfluxDB 3 Core auch intern auf dem Pi**. Begründung: Konsistenz mit der vorgegebenen 3.x-Zweitinstanz (ein einziger Schreib-Client/Code-Pfad, gleiche API), und 3 Core ist die zukunftssichere GA-Richtung. Voraussetzung ist die OS-Konfiguration aus §2 (**arm64 + 4-KB-Seitengröße**, ≥ 4 GB RAM empfohlen).
- **Rückfalloption:** Auf einem Pi 4 mit nur **2 GB RAM** ist InfluxDB 3 Core grenzwertig – dokumentiere **InfluxDB 2.x (2.9.x)** als Rückfall (dann ggf. zweiter Schreib-Client nötig). *(erledigt: zweiter Schreib-Client implementiert — `api_version = "v2"` pro InfluxDB-Ziel in `config.toml`, eigener v2-Line-Protocol-Client ohne zusätzliche Abhängigkeit.)*
- Da ich **frisch installiere**, gib mir im Konfigurationsschritt **aktuelle, konkrete Installationsquellen/-befehle** und **pinne eine konkrete Version** (intern und für die Anbindung an die 3.x-Zweitinstanz).

---

## 8. Alarme und E-Mail

- **Hochwasseralarm** und **Leerlaufalarm** per E-Mail; in Aufbau 2 je Sensor ein Alarmpegel + Leerlaufpegel (einzeln an-/abschaltbar) sowie der **Leckage-Alarm** (Gradient steiler als der konfigurierte erwartete Entleer-Gradient).
- **Alle Alarmschwellen konfigurierbar.**
- **Relaisausgang als Alarmkanal nur in Aufbau 3.**
- **SMTP-Ausgangsserver** (Host, Port, Benutzer, Passwort, TLS) über die Weboberfläche editierbar. **Zugangsdaten verschlüsselt at rest speichern.**

---

## 9. Weboberfläche (zentrale Konfiguration)

Eine Webseite, über die **alles** konfigurierbar ist:
- Aktiver Aufbau (1/2/3), Anzahl Sensoren, Referenz-Modus (pro Stapel / pro Board), Behältertypen/-geometrien je Sensor, ob Volumen mitgeschrieben wird, ob die Pneumatikpumpe läuft (Intervall/Laufzeit), Aufbau-3-Parameter (Pegel, Offset, Freifall-Druck, Pumpvorgänge bis Selbstkalibrierung, Überstrom-/Unterstrom-Schwellen), SMTP-Server, InfluxDB-Ziele, Shelly-Auswahl, Kalibrier-Stützstellen, Behältersummen nullen (Aufbau 2).
- **Abhängigkeitsprüfung beim Start:** Prüfe, ob alle benötigten Abhängigkeiten/Dienste vorhanden sind. Schlägt die Prüfung fehl, **zeige die Installations-/Einrichtungsbefehle als kopierbaren Text** an, damit ich sie selbst im Terminal ausführe. **Führe selbst keine Installationsbefehle aus der Weboberfläche aus** (kein Command-Execution-Endpunkt).
- **Live-Server-Status:** zeige laufend an, ob alle Dienste **gestartet und erreichbar** sind (interne InfluxDB 3, optionale zweite InfluxDB/FHEM, Grafana, in Aufbau 3 der Shelly, sowie SMTP-Erreichbarkeit).
- **Netzwerkanzeige:** zeige an, **welche Internetverbindung über welche Schnittstelle** gerade aktiv ist.
- **Shelly-Suche:** Button zum Scannen des lokalen Netzes und Auswählen des Shelly.
- **Zugangsschutz:** *(korrigiert: kein Login-Passwort — die Weboberfläche läuft im lokalen Netz und braucht keine eigene Anmeldung.)* Stattdessen: Schutz vor versehentlichem Löschen der Sensor-Kalibrierung durch mehrfache Rückfrage in der UI (Löschen eines einzelnen Punktes: eine Rückfrage; komplette Kalibrierung eines Sensors löschen: zwei Rückfragen, davon eine mit Eintippen der Sensor-ID).
  *(ergänzt, siehe Änderungshistorie Punkt 8: Standard-Kalibrierungsvorlage — eine Sensor-Kennlinie kann als Vorlage gesetzt und auf baugleiche Sensoren übertragen werden; das Übertragen überschreibt die Ziel-Kalibrierung und unterliegt deshalb derselben zweistufigen Rückfrage wie das Löschen.)*
- **Konfiguration als eigene, portable Datendatei:** Lege alle Konfigurationsdaten (inkl. Kalibrier-Stützstellen) in **einer eigenen, menschenlesbaren Datei** ab (z. B. TOML/YAML/JSON). Sie muss **einmal editiert gespeichert** und **in andere Installationen geladen** werden können (Export/Import).
  - **Geheimnisse:** SMTP-Passwort und InfluxDB-Tokens dürfen beim Export nicht im Klartext mitreisen – halte sie **verschlüsselt** oder in einem **separaten, standardmäßig nicht exportierten Abschnitt/Datei**.
  - **Kalibrierung ist hardwarespezifisch** (pro Sensor/Board): beim Import in andere Hardware **warnen**.
- **Laufzeit-/Betriebszustand** (Behältersummen, Durchsatz-Integrale, Betriebsmodus) getrennt von der portablen Konfigdatei **neustart-fest** speichern (z. B. SQLite oder Zustandsdatei).

---

## 10. Grafana

- Für die **Anzeige** der Messwerte gibt es eine Grafana-Instanz auf dem Pi.
- Generiere **drei vordefinierte Dashboards**, passend zu den drei Aufbauten.
- **Bedienung in Aufbau 3:** In Grafana soll ein Bedienbereich existieren, mit dem sich **Automatikbetrieb / Pumpe an / Pumpenansteuerung aus** wählen lässt, und der **aktuelle Betriebsmodus** wird angezeigt. Da Grafana primär Anzeige ist: realisiere die **Steuerung** über deine eigene Web-/API-Schicht und **bette sie in Grafana ein** (oder verlinke sie), im **Look & Feel von Grafana**. Die **Anzeige** bleibt in Grafana, die **Bedienung** wird nur hinzugefügt. Beachte das **1024×600-Querformat** des Displays *(korrigiert: nicht mehr 480×800-Hochformat)*.
  *(erledigt, per Verlinken statt Einbetten — siehe Änderungshistorie Punkt 3: Dashboard-Link + Text-Panel-Button zur Pumpensteuerung, `pegelwatch_url`-Variable; zusätzlich zeigen zwei Stat-Panels "Betriebsmodus" und "Pumpe läuft" den aktuellen Zustand live aus InfluxDB.)*

---

## 11. Dokumentation

- **Anwender-Betriebsanleitung auf Deutsch**, **automatisch beim (Neu-)Kompilieren generiert**.
- **Sehr einfach formuliert – für eine etwa 10-jährige Person verständlich.**
- Vollumfänglich (Inbetriebnahme, Konfiguration, alle drei Aufbauten, Kalibrierung, Alarme, Bedienung). Wähle ein praktisches Ausgabeformat (z. B. Markdown → PDF/HTML) und binde es in den Build ein.

---

## 12. Offene Punkte, bei denen du nachfragen sollst, falls relevant

- Genaue **Shelly-3EM-Generation/-Variante** (Gen1 vs. Gen2/Pro; API-Unterschiede).
- Sobald du die Eagle-Netliste/BOM gelesen hast: bestätige die **Kanal-Zuordnung und die AFE-Skalierung**, bevor du die Umrechnung implementierst, und schlage daraus den **Default für das absolute Totband** (Sprung-Erkennung) ab.
- Schlage **Defaults** vor für: Glättungsfenster und Rausch-Totband der Durchsatz-/Wellen-Logik; Mindestdauer des Abwärtstrends.
- Bestätige die gewählte **portable Konfig-Dateiformat** (TOML/YAML/JSON) und die **Geheimnis-Handhabung** beim Export.

---

## 13. Nachtrag: Konfigurations-UI-Redesign und Betriebswerkzeuge

*(Nachträglich ergänzt, nachdem die Konfigurations-Weboberfläche aus §9 bereits als funktionale Erstversion existierte. Prüfe bei einem späteren Durchlauf die Implementierung explizit gegen die folgenden Punkte.)*

**Gestaltung der Konfigurationsseite:**
- **Ausführliche Feldbeschreibungen:** Jedes Eingabefeld (bzw. jede zusammengehörige Feldgruppe, wo Einzelfelder zu kleinteilig wären) bekommt einen erklärenden Hilfstext, der beschreibt, **welcher Wert erwartet wird**, in welcher Einheit, und was ein sinnvoller Wertebereich ist.
- **Piktogramme/Zeichnungen:** Wo immer sinnvoll möglich, ergänze ein kleines Piktogramm oder eine schematische Zeichnung, die zeigt, **was der Wert im System bewirkt oder beeinflusst** (z. B. Referenzkanal am ADC, Behältergeometrie, Relais-Zuordnung, Kalibrierkurve). Muss nicht pro Einzelfeld sein, aber pro Themenblock.
- **Einheitliches Layout/CI:** Konsistente Gestaltung über die gesamte Konfigurationsseite (Farben, Typografie, Abstände, Icon-Stil). **Orientiere dich am Corporate Design des Technischen Hilfswerks (THW)** — d. h. am Charakter des THW-Erscheinungsbilds (kräftiges Blau als Leitfarbe, hoher Kontrast, klare/funktionale Beschriftung, aufgeräumtes Layout), **nicht** an einer wörtlichen Kopie von Logo/Wortmarke (Markenrechte!).
  *(erweitert und erledigt: Die Konfigurationsseite ist die Vorlage — Startseite und Handbuch verwenden dieselbe THW-Gestaltung, aus einer einzigen gemeinsamen Quelle (`internal/web/templates/layout.html`, Templates `thw-style`/`thw-header`) statt dreier separater CSS-Kopien. Die Startseite zeigt zusätzlich alle verfügbaren Seiten/URLs an (dieselbe Sitemap-Komponente wie im Systemstatus der Konfigurationsseite, inkl. Kiosk-Ansichten).)*

**Deployment:**
- **Deployment per Raspberry Pi Connect** geprüft *(erledigt, siehe Änderungshistorie Punkt 6: gegen die offizielle Connect-Dokumentation geprüft — Connect bietet nur eine Browser-Remote-Shell, keinen skriptbaren SSH-Zugang, daher nicht als Deploy-Transport nutzbar. Stattdessen: `deploy.ps1`/`deploy-fleet.ps1` sind transportunabhängig für jedes SSH-erreichbare Ziel, und ein Geräte-Register `deploy\devices.psd1` + `deploy-fleet.ps1 -Device <Name(n)|all>` erlauben das Deployment eines oder mehrerer der drei Geräte über einen einzigen Befehl.)*
- **Konfiguration bleibt beim Deployment erhalten:** Ein normales Update (neues Binary) darf **niemals** `config.toml`, `secrets.toml` oder die Zustands-Datenbank (`state.db`) überschreiben. Das Überschreiben der Konfiguration ist nur über einen **expliziten, separaten Schalter** möglich (bestehendes Verhalten von `-UpdateConfig` beibehalten/absichern, inkl. Sicherheitsabfrage vor dem Überschreiben).
  *(erledigt, gilt unverändert auch für `deploy-fleet.ps1` — jedes Gerät hat sein eigenes Konfigurationsverzeichnis, `-UpdateConfig` wird pro Aufruf an alle ausgewählten Geräte durchgereicht.)*

**Werksreset:**
- Eigene Funktion in der Konfigurations-UI, mit der sich **die Konfiguration auf Standardwerte zurücksetzen** lässt (nicht die Geheimnisse in `secrets.toml` — die bleiben erhalten, analog zur bestehenden Trennung von Konfiguration und Zugangsdaten).
- Wie beim Löschen der Kalibrierung (§9): **mehrfache, unmissverständliche Rückfrage**, bevor der Reset ausgeführt wird — ein Werksreset ist eine seltene, folgenreiche Aktion.

**Erweiterter Systemstatus auf der Konfigurationsseite:**
Zeige alles an, was für den **Betrieb** der Software relevant ist, unter anderem:
- Erreichbarkeit der benötigten Dienste/Server (bereits vorhanden: InfluxDB lokal/FHEM, SMTP, Shelly).
- Aktive Internetverbindung / verfügbare Netzwerkschnittstellen (bereits vorhanden: `/api/network`).
- **Welche Seiten die Anwendung anbietet, inkl. der jeweiligen URL** (Übersicht/Sitemap: Startseite, Konfiguration, Handbuch, Kiosk-Ansichten, API-Basis-Endpunkte).
- **Gefundene Hardware mit Adressen** (I²C-Bus-Scan: welche ADS1115-Boards auf welcher Adresse antworten; im Aufbau 3 der gefundene/verbundene Shelly).
- Sonstige für den Betrieb sinnvolle Informationen (z. B. Pfade der Konfigurations-/Zustandsdateien, aktiver Aufbau, Go-/Build-Version) — nach eigenem Ermessen ergänzen, solange es dem Betrieb dient.

**Beginne jetzt mit Schritt 1 (Sprachempfehlung) und Schritt 3 (fordere die Python-Implementierung und die Eagle-Unterlagen an). Schreibe noch keinen Anwendungscode, bevor diese vorliegen und der Cross-Compile-Workflow steht.**
