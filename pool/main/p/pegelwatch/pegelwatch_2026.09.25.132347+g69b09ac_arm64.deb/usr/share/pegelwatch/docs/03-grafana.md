# PegelWatch — Grafana Dashboards

Im Verzeichnis `grafana/` liegen drei fertige Dashboard-JSONs für Grafana 10+
(neu erstellt Juli 2026, passend zum aktuellen Messschema). Sie referenzieren
eine InfluxDB-Datasource mit der **festen UID `pegelwatch-influx`**
(InfluxQL über die v1-Kompatibilitäts-API von InfluxDB 3 Core).

| Datei | Aufbau | Inhalt |
|---|---|---|
| `aufbau1_pegelstand.json` | RIVERWatch (1) | Einzelsensor: Pegel, Spannung, Gültigkeit, Volumen, Pi-Temperatur |
| `aufbau2_mehrkanal.json` | SEPWatch (2) | Alle Behälter (bis **30 Sensoren**, 2 Stapel, vollständig dynamisch): Pegel, Volumen, kumulierte Füllung/Durchsatz, Diagnose |
| `aufbau3_pumpensteuerung.json` | PUMPWatch (3) | Pegel-Gauge mit Schwellen, Betriebsmodus, Pumpenlauf-Historie, **Relais-Verlauf**, Shelly-Ströme/-Leistung, Link zum Hebewerk_Kiosk |

---

## Voraussetzungen

1. Grafana 10 oder neuer läuft erreichbar (z.B. `http://192.168.0.106:3000`)
2. InfluxDB 3 Core ist aktiv und PegelWatch schreibt Daten (prüfbar im
   Live-Server-Status der Konfigurationsseite)

---

## Einrichtung per Provisioning (empfohlen)

Datasource und Dashboards werden als Dateien hinterlegt — kein Klicken in
der Grafana-Oberfläche nötig, und die Dashboards überleben Neuinstallationen.
`<TOKEN>` ist das InfluxDB-Admin-Token (siehe docs/01-installation.md).

> **Automatisch bei jedem Deploy:** `deploy.ps1` provisioniert die aktuellen
> Dashboards aus `grafana/` bei **jedem** Lauf automatisch mit (kopiert sie nach
> `/var/lib/grafana/pegelwatch-dashboards/`; der Datei-Provider lädt Änderungen
> ohne Neustart nach) und legt zusätzlich Doku + Dashboards als Bundle unter
> `/usr/local/share/pegelwatch/` auf dem Pi ab. Die manuellen Schritte unten
> braucht man daher nur für die **Erst**einrichtung von Datasource und Provider
> (Token!) bzw. für eine reine Grafana-Einzelinstallation.

```bash
# 1. Dashboards ablegen
sudo mkdir -p /var/lib/grafana/pegelwatch-dashboards
sudo cp grafana/aufbau*.json /var/lib/grafana/pegelwatch-dashboards/
sudo chown -R grafana:grafana /var/lib/grafana/pegelwatch-dashboards

# 2. Datasource provisionieren
sudo tee /etc/grafana/provisioning/datasources/pegelwatch.yaml > /dev/null <<EOF
apiVersion: 1
datasources:
  - name: PegelWatch InfluxDB
    uid: pegelwatch-influx
    type: influxdb
    access: proxy
    url: http://localhost:8086
    isDefault: true
    jsonData:
      dbName: pegelwatch
      httpMode: GET
      httpHeaderName1: Authorization
    secureJsonData:
      httpHeaderValue1: Bearer <TOKEN>
EOF

# 3. Dashboard-Provider provisionieren
sudo tee /etc/grafana/provisioning/dashboards/pegelwatch.yaml > /dev/null <<EOF
apiVersion: 1
providers:
  - name: PegelWatch
    folder: PegelWatch
    type: file
    allowUiUpdates: true
    options:
      path: /var/lib/grafana/pegelwatch-dashboards
EOF

sudo systemctl restart grafana-server
```

Danach erscheinen die drei Dashboards im Ordner **PegelWatch**.

## Alternativ: manueller Import

Datasource wie oben (UID muss `pegelwatch-influx` sein — beim manuellen
Anlegen unter *Add data source → InfluxDB* die UID über die URL-Zeile bzw.
Provisioning setzen), dann **Dashboards → Import → Upload JSON file**.

---

## Aufbau 1 — Pegelstand

**Panels:**

| Panel | Typ | Inhalt |
|---|---|---|
| Aktueller Pegel | Stat | Letzter Messwert [mm], farbkodiert |
| Sensor-Spannung | Stat | Letzte Rohspannung [mV] |
| CPU-Temperatur | Stat | Raspberry Pi CPU [°C] |
| GPU-Temperatur | Stat | Raspberry Pi GPU [°C] |
| Wasserstand [mm] | Time series | Zeitverlauf mit Sensor-Filter |
| Sensor-Spannung [mV] | Time series | Rohspannungsverlauf |
| Pi-Temperaturen | Time series | CPU + GPU Temperaturverlauf |

**Template-Variable `sensor_id`:** Ermöglicht Auswahl eines einzelnen Sensors.

---

## Aufbau 2 — Mehrkanal / Leckage

Vollständig **dynamisch bis 30 Sensoren** (Vollausbau: 2 Stapel à 15). Die
Sensoren werden über die Template-Variable `sensor_id` automatisch erkannt
(`SHOW TAG VALUES`), die Füllstands-Gauge wird per `repeat` je Sensor
vervielfältigt, und alle Summen-/Verlaufs-Panels gruppieren über
`GROUP BY "sensor_name"` — es gibt also keine feste Sensor-Obergrenze im
Dashboard, es wächst mit der Konfiguration.

**Panels:**

| Panel | Typ | Inhalt |
|---|---|---|
| Aktuelle Pegelstände je Behälter | Stat | Alle Sensoren, farbkodiert |
| Aktuelles Volumen je Behälter | Stat | current_liters je Behälter |
| Pegelstände aller Behälter | Time series | Alle Sensoren überlagert, Legende mit min/max |
| Behältervolumen | Time series | current_liters je Behälter |
| Kumulierte Füllung / Durchsatz | Time series | filled_liters + drained_liters (seit letztem Nullen) |
| Sensor-Spannungen | Time series | Diagnose/Leckage-Vergleich |
| Pi-Temperaturen | Time series | CPU + GPU |

**Leckage-Erkennung:** Die eigentliche Leckage-Alarmierung (Gradient) macht
PegelWatch selbst (§3/§8); hier dienen die überlagerten Pegel-/
Spannungsverläufe der Nachkontrolle.

---

## Aufbau 3 — Pumpensteuerung

**Panels:**

| Panel | Typ | Inhalt |
|---|---|---|
| Aktueller Pegel | Gauge | Pegelstand 0–5000 mm, farbkodiert |
| Gesamtleistung Pumpe | Stat | Gesamtleistung [W] der 3 Phasen |
| Phasenströme L1/L2/L3 | Stat | Aktuelle Ströme [A], Überstrom-Warnung ab 16 A |
| Phasenspannungen L1/L2/L3 | Stat | Spannungen [V], Warnung außerhalb 210–240 V |
| Phasenleistungen L1/L2/L3 | Stat | Leistungen [W] je Phase |
| CPU / GPU Temperatur | Stat | Pi-Temperaturen |
| **Pumpensteuerung öffnen** | Text (HTML-Button) | Link zur PegelWatch-Pumpensteuerung (`/pump-kiosk`) |
| **Betriebsmodus** | Stat | Aktueller Modus (`auto`/`on`/`off`) aus `pump_status` |
| **Pumpe läuft** | Stat | Laufzustand aus `pump_status`, grün wenn `running=true` |
| **Relais-Verlauf** | State-Timeline | Schaltzustand der Logik-Relais (CH4–CH8) über die Zeit — je Zeile ein Relais mit dem konfigurierten **Benutzernamen** (aus `relay_status`, `GROUP BY "name"`) |
| Wasserstand [mm] | Time series | Pegelstandsverlauf mit Schwellwert-Markierung |
| Phasenströme | Time series | Stromverlauf L1/L2/L3 |
| Phasenspannungen | Time series | Spannungsverlauf L1/L2/L3 |
| Gesamtleistung | Time series | Leistungsverlauf mit Füllbereich |
| Pi-Temperaturen | Time series | CPU + GPU Verlauf |

**Refresh:** 5 Sekunden (Shelly-Polling-Intervall).

**Bedienung (§10 des Auftrags):** Die eigentliche Steuerung (Automatik/Ein/Aus)
läuft weiterhin über die PegelWatch-Weboberfläche (**Hebewerk_Kiosk**,
`/pump-kiosk`) — Grafana kann keine Schreibbefehle an PegelWatch senden. Das
Dashboard **verlinkt** dorthin (Dashboard-Link oben rechts + Bedienungs-Panel),
zeigt aber Betriebsmodus und Laufzustand direkt aus InfluxDB an, plus eine
**Pumpenlauf-Historie** (State-Timeline aus `pump_status.running`) und einen
**Relais-Verlauf** (State-Timeline aus `relay_status`, je Zeile ein
Logik-Relais mit dem in der Konfiguration vergebenen Namen). Bei Bedarf die
Dashboard-Variable **`pegelwatch_url`** anpassen (Standard:
`http://192.168.0.106:8080`).

---

## InfluxDB-Messwerte

### water_level

| Field | Typ | Einheit |
|---|---|---|
| `level_mm` | float | mm |
| `volts_mv` | float | mV |
| `raw_adc` | int | ADC-Rohwert |
| `ref_adc` | int | Referenz-Rohwert (falls vorhanden) |
| `valid` | bool | Kalibrierung vorhanden und plausibel |

Tags: `sensor_id`, `sensor_name`

### system_info

| Field | Typ | Einheit |
|---|---|---|
| `cpu_temp_c` | float | °C |
| `gpu_temp_c` | float | °C |

### electricity (nur Aufbau 3)

| Field | Typ | Einheit |
|---|---|---|
| `l1_a`, `l2_a`, `l3_a` | float | A |
| `l1_v`, `l2_v`, `l3_v` | float | V |
| `l1_w`, `l2_w`, `l3_w` | float | W |
| `total_w` | float | W |

Tag: `source = "shelly_3em"`

### container_volume (nur wenn Behältergeometrie mit `write_volume=true` konfiguriert ist)

| Field | Typ | Einheit |
|---|---|---|
| `current_liters` | float | L (aktuelles Behältervolumen) |
| `filled_liters` | float | L (kumuliert eingefüllt seit letztem "Nullen") |
| `drained_liters` | float | L (kumuliert abtransportiert, Durchsatz) |

Tags: `sensor_id`, `sensor_name`. Für "Auswertezeitraum"-Auswertungen (§3,
Aufbau 2) über einen frei wählbaren Zeitraum eignet sich hier eine
`derivative()`- oder Differenz-Query über den Grafana-Zeitbereich — der
Aufbau-2-Kiosk selbst bietet dafür feste Voreinstellungen (1h/24h/7d/30d) über
`/api/aufbau2/period`.

### pump_status (nur Aufbau 3)

| Field | Typ | Einheit |
|---|---|---|
| `mode` | string | `auto` \| `on` \| `off` |
| `running` | bool | Pumpe läuft gerade |

### relay_status (nur Aufbau 3)

| Field | Typ | Einheit |
|---|---|---|
| `on` | bool | Relais eingeschaltet |

Tag: `name` (der in der Konfiguration vergebene Name des Logik-Ausgangs). Eine
Zeitreihe je Relais; geschrieben bei jeder Schaltflanke plus 15-Sekunden-Heartbeat,
damit die State-Timeline auch für lange unveränderte Relais lückenlos bleibt.

---

## Alarme in Grafana

Grafana Alerting kann auf die InfluxDB-Messpunkte reagieren. Beispiel-Alert
für Hochwasser (Aufbau 1):

**Alert rule → Query:**
```
SELECT last("level_mm") FROM "water_level" WHERE $timeFilter
```

**Condition:** `IS ABOVE 4500`

**Notification:** E-Mail, Telegram, etc.

> **Hinweis:** PegelWatch sendet bereits eigenständig Alarm-Mails via SMTP
> (konfigurierbar in `config.toml`). Grafana-Alerts sind eine zusätzliche
> optionale Benachrichtigungsschicht.
