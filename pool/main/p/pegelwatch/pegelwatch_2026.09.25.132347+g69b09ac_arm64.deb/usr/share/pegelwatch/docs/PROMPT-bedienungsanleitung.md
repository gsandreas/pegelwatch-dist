# Prompt: Bedienungsanleitung für PEGELWatch erstellen

> Diesen gesamten Text in Claude Code (im Projekt-Workspace) einfügen. Claude soll ihn
> als verbindlichen Auftrag behandeln und die Anleitung **erst schreiben, nachdem** die
> vorhandenen Unterlagen und der Quellcode gesichtet sind.

---

## Rolle und Ziel

Du bist technischer Redakteur für dieses Projekt. Erstelle eine **vollständige,
deutschsprachige Bedienungsanleitung** für die Mess- und Steuerungssoftware in diesem
Repository (Produktnamen je Aufbau: **RIVERWatch / SEPWatch / PUMPWatch**).

Die Anleitung führt **einen technisch unerfahrenen Bediener** an **einem roten Faden**
der Reihe nach durch **alle** Optionen und Funktionen des Projekts – von „ich habe nichts
außer diesem GitHub-Repository" bis „meine Anlage läuft, ich kann sie bedienen, ablesen,
warten und im Störungsfall wieder flottmachen".

## Zielgruppe und Ton

- **Leser:** jemand ohne Elektronik-/Programmier-Vorkenntnisse. Kann einen Windows-PC
  bedienen, Kabel nach Bild stecken und Text im Terminal per Kopieren/Einfügen ausführen.
- **Verständlichkeit:** so einfach, dass es sinngemäß auch eine etwa 10-jährige Person
  versteht (siehe `docs/00-projekt-auftrag.md`, §11). Kurze Sätze. Ein Gedanke pro Satz.
- **Anrede:** durchgehend „Sie" **oder** „du" – wähle **eine** Form und bleibe konsistent
  (Empfehlung: „Sie", ruhig und sachlich).
- **Fachbegriffe:** beim ersten Vorkommen in Klammern in Alltagssprache erklären
  (z. B. „I²C-Bus (die Datenleitung zu den Messplatinen)"). Alle Fachbegriffe zusätzlich
  in einem **Glossar** am Ende sammeln.
- **Jeder Handlungsschritt ist nummeriert.** Sag immer, **was** man tut, **wo** man klickt/
  tippt und **woran man erkennt, dass es geklappt hat** (Erfolgskriterium).
- Nutze **Hinweis-/Warn-/Tipp-Kästen** (Markdown-Zitatblöcke mit ⚠️ / 💡 / ✅) für
  Gefahren (Netzspannung, Löschen der Kalibrierung, Werksreset) und für Abkürzungen.
- **Screenshots echter Bedienelemente (verbindlich):** Immer wenn ein konkretes
  **Bedienelement der Weboberfläche** erklärt wird (Knopf, Schalter, Formularfeld,
  Kiosk-Kachel, Statusanzeige, Popup usw.), **gehört ein Screenshot des fertig
  gerenderten Elements** direkt daneben in die Anleitung — nicht nur eine
  Beschreibung. Die Screenshots stammen aus der **tatsächlich gerenderten UI**
  (Templates in `internal/web/templates/*`, Seiten Startseite/Konfiguration/
  Handbuch/Kiosks). Lege dafür einen Bildordner `docs/bilder/` an und binde die
  Bilder als `![… Beschreibung …](bilder/xxx.png)` ein. Der **Screenshot-Schritt
  ist Teil des Build-Vorgangs** (siehe „Build" unten): Die Bilder werden beim
  Kompilieren aus der laufenden UI erzeugt (headless Chromium ist auf dem Pi
  ohnehin vorhanden — dieselbe Kette wie `internal/report`), damit sie nie
  veralten. Wo ein Foto realer Hardware gemeint ist (Verdrahtung, Sensor), genügt
  ein markierter Platzhalter `![Platzhalter: … Foto …](bilder/xx.png)`.

## Ausgangslage (verbindlich)

Der Leser hat **nichts** eingerichtet. Es existiert **nur der Quellcode auf GitHub**,
in dem auch diese Anleitung liegt. Die Anleitung muss also **den kompletten Weg ab
GitHub** abdecken: Repository holen → auf dem Windows-PC bauen → Raspberry Pi vorbereiten →
Hardware anschließen → Software aufspielen → in Betrieb nehmen → bedienen → warten.
Setze **kein** Vorwissen und **keine** vorhandene Installation voraus.

## Umfang

- **Alle drei Aufbauten in EINEM Dokument.** Struktur: ein gemeinsamer Teil (gilt für alle)
  plus je ein klar abgegrenzter Abschnitt für RIVERWatch, SEPWatch und PUMPWatch. Der Leser
  soll früh erkennen, **welcher Aufbau seiner ist**, und dann nur noch dem gemeinsamen Teil
  und seinem Aufbau-Abschnitt folgen müssen.
- **Vollständig:** jede vom Bediener erreichbare Funktion und jede Konfigurationsoption
  kommt vor (Weboberfläche, Kalibrierung, Kiosk-Ansichten, 7-Segment-Display, Grafana,
  Alarme/E-Mail, Berichte, Cloud-Frontend, Wartung, Störungshilfe). Nichts still weglassen.

## Format und Ablage

- **Quelle:** eine einzige Markdown-Datei `docs/bedienungsanleitung.md` mit
  Inhaltsverzeichnis (Anker-Links) am Anfang. Bilder unter `docs/bilder/`.
- **Build (verbindlich, bei JEDEM Buildlauf):** Die Anleitung wird **bei jedem Build
  automatisch neu erzeugt** (siehe `docs/00-projekt-auftrag.md` §11: „automatisch beim
  (Neu-)Kompilieren generiert") — inklusive der **Screenshots der Bedienelemente** und
  der Ausgabe als **HTML und PDF**. Es gibt bereits eine vorbereitete, **nicht-fatale
  Einbindung** in `build.ps1`, `deploy.ps1` (Einzel-Pi) und `deploy-fleet.ps1` (Flotte):
  sie ruft einen Generator über den festen Einstiegspunkt **`tools/build-manual.ps1`**
  auf (fehlt er, wird der Schritt mit Warnung übersprungen). **Deine Aufgabe:** genau
  dieses `tools/build-manual.ps1` erstellen. Es soll (a) die Screenshots der
  Bedienelemente aus der gerenderten UI erzeugen (headless Chromium, wie `internal/report`),
  (b) `docs/bedienungsanleitung.md` → `docs/bedienungsanleitung.html` **und** `.pdf`
  rendern, und dabei ohne zusätzliche schwergewichtige Abhängigkeiten auskommen. Weil die
  gerenderten Dateien unter `docs/` liegen, zieht `deploy.ps1` (`Deploy-Docs`) sie
  automatisch mit auf den Pi (nach `/usr/local/share/pegelwatch`). Erkläre den
  Build-/Regenerations-Schritt kurz auch in der Anleitung selbst.

## Arbeitsweise (bitte in dieser Reihenfolge)

1. **Erst lesen, dann schreiben.** Sichte die vorhandene Doku und leite Fakten daraus ab –
   erfinde nichts:
   - `docs/00-projekt-auftrag.md` (Gesamtanforderung inkl. Änderungshistorie)
   - `docs/01-installation.md`, `docs/02-konfiguration.md`, `docs/03-grafana.md`,
     `docs/04-verdrahtung.md`, `docs/05-testsensor.md`, `docs/06-ressourcenanalyse.md`,
     `docs/07-lagebericht.md`, `docs/08-cloud-frontend.md`,
     `docs/09-analog-frontend.md` (Sensorplatine: Signalweg/Referenz — Grundlage fürs
     Kalibrier-/Verdrahtungskapitel), `docs/10-relaiskarte.md` (Relaiskarte Aufbau 3:
     Aktiv-LOW/Fail-Safe/NO-NC — Grundlage fürs PUMPWatch-Kapitel), `README.md`
   - die **Skripte** `build.ps1`, `deploy.ps1`, `deploy-fleet.ps1`, `deploy/`,
     `config.toml.example`, `secrets.toml.example`
   - den **Code** dort, wo Bedienung/Optionen sichtbar werden: die Weboberfläche und ihre
     Seiten/Endpunkte (`internal/web`, Templates, Kiosk-Seiten, Sitemap), die
     Konfigurationsfelder (`internal/config`), Kalibrierung, Pumpensteuerung, Alarme,
     Berichte (`internal/report`), Cloud-Agent (`internal/cloud`).
2. **Gegen den Code verifizieren.** Namen von Knöpfen, Seiten, URLs, Konfig-Feldern,
   Menüpunkten und Standardwerten müssen mit dem **tatsächlichen Stand** übereinstimmen.
   Wenn Doku und Code sich widersprechen, gilt der Code – weise auf die Abweichung hin.
3. **Roten Faden aufbauen** (siehe Gliederung unten), Lücken kennzeichnen statt raten.
   Ist etwas laut `docs/07-lagebericht.md` / `docs/08-cloud-frontend.md` noch nicht
   verifiziert oder offen, kennzeichne es als „noch nicht abschließend geprüft" statt es
   als fertig zu beschreiben.
4. **Schreiben**, dann am Ende eine **Konsistenzprüfung**: Stimmt jede genannte URL, jeder
   Knopfname, jeder Standardwert? Ist der rote Faden lückenlos vom Nullpunkt bis zum
   laufenden Betrieb?

## Roter Faden (verbindliche Gliederung – anpassen, wenn der Code es verlangt)

Der Aufbau folgt der **zeitlichen Reise** des Bedieners, nicht der Code-Struktur:

0. **Willkommen** – Was macht dieses Gerät (in zwei Sätzen)? Für wen ist die Anleitung?
   Wie liest man sie (Kästen, Schritte, „finde deinen Aufbau")?
1. **Das Ziel vor Augen** – Wie sieht die fertige Anlage aus? Kurzvorstellung der drei
   Aufbauten mit einem Bild/Platzhalter und einer Entscheidungshilfe „Welcher bin ich?".
2. **Was du brauchst** – Checkliste: Hardware je Aufbau (aus `README.md`/§2/Verdrahtung),
   Werkzeug, ein Windows-PC, Netzwerk, ein GitHub-Zugang. Ohne Fachchinesisch.
3. **Den Quellcode holen** – GitHub-Repository als ZIP laden **oder** `git clone`,
   ganz kleinschrittig. Wohin auf dem PC.
4. **Die Software bauen (Windows)** – `build.ps1` Schritt für Schritt; was ein „Build" ist;
   woran man Erfolg erkennt (das erzeugte Binary).
5. **Den Raspberry Pi vorbereiten** – Betriebssystem, Grundeinrichtung (auf
   `docs/01-installation.md` stützen, aber bediengerecht nacherzählen).
6. **Hardware anschließen** – nach Aufbau getrennt, mit Sicherheitswarnungen (Netzspannung
   nur vom Fachmann!). Auf `docs/04-verdrahtung.md` stützen; Bild-Platzhalter je Aufbau.
7. **Software aufspielen** – `deploy.ps1` / `deploy-fleet.ps1`; was `-UpdateConfig` bedeutet
   und warum ein normales Update Konfiguration/Zustand **nicht** überschreibt.
8. **Der erste Start** – Weboberfläche im Browser öffnen (welche Adresse/URL?), was die
   **Startseite** zeigt, die **Sitemap** aller Seiten, der **Systemstatus** (welche Dienste
   laufen, gefundene Hardware, Netzwerk).
9. **Grundeinrichtung in der Weboberfläche** – Aufbau wählen; Sensoren, Referenz-Modus
   (pro Stapel/pro Board), I²C-Bus/Board-Adressen aus dem Scan; Behältergeometrie;
   InfluxDB-Ziele; jede Option mit dem vorhandenen Hilfetext erklärt.
10. **Ohne Hardware üben: der Testsensor** – `[sensor.simulation]` als Trockenübung, damit
    der Leser die Oberfläche gefahrlos ausprobiert (auf `docs/05-testsensor.md` stützen).
11. **Kalibrieren** – der wichtigste Bedienschritt, sehr ausführlich: Stützstellen aufnehmen,
    Kurve prüfen, Standard-Kalibriervorlage setzen/übernehmen; die **doppelten Rückfragen**
    beim Löschen/Übernehmen erklären (Schutz vor Datenverlust).
12. **Deinen Aufbau bedienen** – je ein Abschnitt:
    - **RIVERWatch (Aufbau 1):** Pegel ablesen, Volumen.
    - **SEPWatch (Aufbau 2):** mehrere Behälter, Füllstand/Volumen/Durchsatz, Behältersummen
      nullen, **Leckage-Alarm** verstehen.
    - **PUMPWatch (Aufbau 3):** Betriebsmodus (Automatik/Ein/Aus) umschalten, Pegel-Schwellen,
      Offset, **Freifall-Selbstkalibrierung**, Maximallaufzeit, Überstrom-/Unterstrom-Alarm,
      Shelly-3EM-Suche und -Strommessung, Laufbericht je Pumpenlauf, Logik-Relaisausgänge.
13. **Die Anzeigen verstehen** – Startseite, **Kiosk-Ansichten** (Hebewerk-/Mehrkanal-Kiosk,
    Vollbild-Knopf, Marker am Gauge), **7-Segment-Display**; jeweils was welche Zahl bedeutet.
14. **Grafana** – Dashboards öffnen, Zeitbereich wählen, in Aufbau 3 die Pumpe aus dem
    Grafana-Bedienbereich schalten (auf `docs/03-grafana.md` stützen).
15. **Alarme und E-Mail** – SMTP-Zugang eintragen, **Testmail-Knopf**, welche Alarme es je
    Aufbau gibt und wie man Schwellen setzt.
16. **Berichte** – PDF-Betriebsbericht sofort erstellen (📄-Symbol), täglicher Versand,
    Übersicht unter `/berichte`.
17. **Cloud-Frontend** – die Anlage von unterwegs sehen: `pegelwatch.gatecs.de`,
    Registrierung/Freigabe, Detailseite, Config-Backup, Befehl „Bericht erstellen"
    (auf `docs/08-cloud-frontend.md` stützen; noch offene Teile als solche kennzeichnen).
18. **Alltag und Wartung** – Konfiguration sichern/exportieren (Geheimnisse bleiben außen
    vor), Werksreset (mit den mehrfachen Rückfragen), Software aktualisieren, Neustart-Knopf,
    Pneumatikpumpe.
19. **Wenn etwas nicht geht (Störungshilfe/FAQ)** – Tabelle „Symptom → Ursache → was tun":
    Weboberfläche nicht erreichbar, Dienst rot im Status, keine Messwerte, InfluxDB startet
    nicht (harter Reboot / WAL – auf `docs/07-lagebericht.md` stützen), keine E-Mails, Shelly
    nicht gefunden, Kiosk-Bildschirm bleibt schwarz.
20. **Glossar** – alle Fachbegriffe in einem Satz erklärt.
21. **Kurz-Spickzettel** – eine Seite: die häufigsten Handgriffe im Alltag als Checkliste.

## Nicht tun

- Keine erfundenen Knöpfe, URLs, Menüs oder Standardwerte. Im Zweifel im Code nachsehen
  oder als „zu prüfen" markieren.
- Nichts als „fertig/verifiziert" darstellen, was laut Lagebericht/Cloud-Doku offen ist.
- Keine gefährlichen Verkürzungen bei Netzspannung/Drehstrom – immer auf Fachpersonal
  verweisen.
- Die bestehende Entwickler-Doku in `docs/` **nicht** ersetzen; die Bedienungsanleitung
  ist zusätzlich, verweist aber bei Tiefe auf die passende `docs/`-Datei.

**Beginne mit Schritt 1 (vorhandene Unterlagen und relevanten Code sichten). Lege danach die
Gliederung von `docs/bedienungsanleitung.md` an und schreibe sie Abschnitt für Abschnitt.**
