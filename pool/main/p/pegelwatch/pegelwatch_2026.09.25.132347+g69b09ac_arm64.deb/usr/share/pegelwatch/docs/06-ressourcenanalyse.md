# PegelWatch — Ressourcenanalyse der drei Anwendungsfälle

Welche Konfiguration lastet den Raspberry Pi am stärksten aus — RIVERWatch
(Aufbau 1), SEPWatch (Aufbau 2) oder PUMPWatch (Aufbau 3)? Diese Analyse
leitet die Antwort aus dem tatsächlichen Code-Verhalten und den
Hardware-Eckdaten her, nicht aus Bauchgefühl.

**Kurzantwort: SEPWatch im Vollausbau** (2 ADS1115-Stapel = 30 Drucksensoren,
Volumen-/Durchsatzberechnung je Behälter, Kiosk-Anzeige, beide
InfluxDB-Ziele) ist in **jeder** Ressourcendimension der Spitzenreiter —
und sein Engpass ist nicht die CPU, sondern der **I²C-Bus im
Schnell-Polling**. Details und Herleitung unten.

---

## 1. Ressourcen-Inventar des Raspberry Pi

| Ressource | Kapazität (Pi 4/5) | Wer sie verbraucht |
|---|---|---|
| CPU (4 Kerne) | reichlich | Chromium-Kiosk, InfluxDB, Grafana, (kaum: pegelwatch) |
| RAM | 4–8 GB empfohlen | InfluxDB 3 Core, Chromium, Grafana |
| **I²C-Bus(se)** | ~25 Messungen/s **je Bus** (s. u.) | ausschließlich die Sensorabfrage |
| SD-Karten-I/O | begrenzt, verschleißend | InfluxDB (WAL/Kompaktierung), state.db |
| Netzwerk | reichlich | SSE-Clients, Influx-HTTP, Shelly-Poll |
| GPU/HDMI | reichlich | Kiosk-Rendering (1024×600) |

Wichtig: pegelwatch selbst (Go-Binary) ist auf keiner dieser Achsen der
große Verbraucher — die Goroutinen schlafen fast immer. Die Last entsteht
durch die **Peripherie-Kette**, die eine Konfiguration aktiviert.

---

## 2. Lastmodell der Messkette (aus dem Code hergeleitet)

Eine einzelne Pegelmessung (`sensor.Measure()`) besteht aus:

- **6 ADC-Einzelwandlungen** für den Messkanal (Mittelung, wie die
  Python-Vorlage) **+ 6 für den Referenzkanal** (ratiometrische Kompensation,
  wird in jedem Pollzyklus mitgelesen, §2) = **12 Wandlungen**.
- Der ADS1115 läuft mit 860 SPS (`DR860`); der Treiber wartet je Wandlung
  mindestens 2 ms (Sicherheits-Untergrenze in `conversionDelay`) und liest
  dann Konfigurations- und Ergebnisregister.
- Je Wandlung fallen drei I²C-Transaktionen an (Konfiguration schreiben,
  Status lesen, Ergebnis lesen) ≈ 10–12 Bytes ≈ **~1,2 ms** bei den
  standardmäßigen 100 kHz.

**Je Wandlung ≈ 3,2 ms → je Messung (12 Wandlungen) ≈ 40 ms Buszeit.**

Daraus folgt die zentrale Größe der ganzen Analyse:

> **Ein I²C-Bus schafft ≈ 25 vollständige Messungen pro Sekunde.**
> Alle Sensoren eines Stapels teilen sich diese Kapazität (der Bus-Mutex
> serialisiert die Zugriffe). Ein zweiter Stapel auf einem eigenen Bus
> (`i2c_bus = 6`) verdoppelt sie, weil jeder Bus seinen eigenen Mutex hat.

### Was das adaptive Polling daraus macht

| Zustand | Nominale Rate je Sensor | Buszeit je Sensor |
|---|---|---|
| SLOW (20 s) | 0,05 Messungen/s | 0,2 % Bus-Auslastung |
| FAST (250 ms) | 4 Messungen/s | **16 % Bus-Auslastung** |

- **15 Sensoren, alle SLOW:** 15 × 0,2 % = 3 % — völlig unkritisch.
- **15 Sensoren, alle FAST** (z. B. alle Behälter werden gleichzeitig
  befüllt, oder eine Welle regt alle gleichzeitig an): Bedarf 60 Messungen/s
  bei 25 verfügbaren → der Bus ist **2,4-fach übernachgefragt**. Die Engines
  blockieren am Bus-Mutex; die effektive Abtastperiode steigt von 250 ms auf
  ≈ 600 ms. Es gehen keine Daten verloren und nichts stürzt ab — aber die
  konfigurierte Schnellabtastung wird nicht erreicht.
- Genau deshalb ist der zweite Stapel auf einem **eigenen Bus** auch ein
  Performance-Feature, nicht nur ein Adressraum-Feature: 30 Sensoren auf
  2 Bussen verhalten sich wie 2 × 15, nicht wie 30 auf einem.

*(Abhilfen, falls der FAST-Worst-Case praktisch relevant wird: `fast_ms`
erhöhen (z. B. 500 ms), I²C-Baudrate per `dtparam=i2c_arm_baudrate=400000`
anheben — verkürzt den Transfer-Anteil, nicht die Wandlungszeit, bringt also
grob 25–30 % — oder die Sensoren bewusst auf beide Stapel verteilen.)*

---

## 3. Was jede Konfiguration zusätzlich aktiviert

| Lastquelle | RIVERWatch (1) | SEPWatch (2) | PUMPWatch (3) |
|---|---|---|---|
| Sensoren (max.) | typ. 1 (+Ref) | **bis 30 (2 Stapel)** | typ. 1 (+Ref) |
| Volumen-/Durchsatz-Tracker je Sensor | optional | **je Behälter** (Median-Fenster, Snapshots alle 15 min) | optional |
| Leckage-Gradientenprüfung je Messung | — | **ja** | — |
| Chromium-Kiosk (größter RAM/CPU-Einzelposten!) | **nein** | ja (`/aufbau2-kiosk`) | ja (`/pump-kiosk`) |
| Shelly-3EM-Poll (alle 5 s, HTTP) | — | — | ja (vernachlässigbar) |
| Relais/GPIO, systemd-Watchdog | — | — | ja (vernachlässigbar) |
| InfluxDB-Schreiblast | 1 Punktquelle | **30 Sensor- + 30 Volumenpunkte je Zyklus** | 1 Sensor- + Pumpen- + Shelly-Punkte |
| SSE-Broadcast je Messung | wenig | **× 30 Sensoren × Clients** | wenig |

InfluxDB 3 Core + Grafana laufen in allen drei Fällen als Basisdienste; das
7-Segment-Display (SPI) und die Pneumatik-Zeitsteuerung sind überall
vernachlässigbar (Mikrosekunden bzw. ein Timer).

### InfluxDB-Schreiblast konkret (SEPWatch-Vollausbau)

Der Writer batcht (50 Punkte je HTTP-Request, Flush spätestens alle 5 s,
Puffer 2000). Worst Case alle 30 Sensoren in FAST und `write_volume = true`:
2 Busse × 25 Messungen/s × 2 Punkte (Pegel + Volumen) ≈ **100 Punkte/s ≈
2 HTTP-Requests/s** an die lokale InfluxDB — verdoppelt bei aktivem
FHEM-Zweitziel. Das ist für InfluxDB 3 auf einem Pi 4 gut machbar, erzeugt
aber die mit Abstand höchste dauerhafte SD-Karten-Schreiblast aller drei
Anwendungsfälle (WAL + Kompaktierung).

### RAM-Budget (Erfahrungswerte, Vollausbau)

| Posten | RIVERWatch | SEPWatch | PUMPWatch |
|---|---|---|---|
| Raspberry Pi OS (Basis) | ~0,3 GB | ~0,3 GB | ~0,3 GB |
| InfluxDB 3 Core | 0,5–1,5 GB | **1–2 GB** (mehr Serien/Schreiblast) | 0,5–1,5 GB |
| Grafana | ~0,25 GB | ~0,25 GB | ~0,25 GB |
| Chromium-Kiosk | — | **0,4–0,8 GB** | 0,4–0,8 GB |
| pegelwatch | ~0,03 GB | ~0,06 GB | ~0,03 GB |
| **Summe (grob)** | **~1,3–2,1 GB** | **~2,3–3,4 GB** | **~1,7–2,9 GB** |

---

## 4. Ergebnis und Begründung

**Rangfolge der Auslastung: SEPWatch (Vollausbau) > PUMPWatch > RIVERWatch.**

1. **SEPWatch skaliert als einziger Anwendungsfall in der Breite.** Alle
   teuren Posten wachsen mit der Sensorzahl: I²C-Buszeit (linear, bis zur
   Sättigung im FAST-Modus — der **einzige echte Engpass** im System),
   InfluxDB-Punkte (×2 durch `write_volume`), Durchsatz-Tracker,
   Leckage-Prüfungen, SSE-Ereignisvolumen. Dazu kommt derselbe
   Chromium-Kiosk wie bei PUMPWatch. Im Vollausbau (2 Stapel à 15 Sensoren)
   erreicht **nur** SEPWatch die Busgrenze und die höchste Schreib- und
   RAM-Last.
2. **PUMPWatch liegt dazwischen:** Es hat den Chromium-Kiosk (den größten
   RAM/CPU-Einzelposten) und zusätzliche Peripherie (Shelly-Poll alle 5 s,
   Relais, Watchdog) — aber typisch nur **einen** Sensor. Shelly-HTTP-Poll und
   Relais-GPIO sind gegen die Messkette vernachlässigbar (< 1 % einer
   CPU). Sicherheitskritisch ja, ressourcenkritisch nein.
3. **RIVERWatch ist die Minimallast:** ein Sensor, kein Kiosk-Browser, kaum
   Schreiblast. Selbst dauerhaft im FAST-Modus belegt der eine Sensor nur
   ~16 % **eines** Busses.

**Der kritischste Einzelfall** ist damit: *SEPWatch, ein Stapel voll belegt
(15 Sensoren auf einem Bus), alle Behälter gleichzeitig in Bewegung (alle
Engines FAST).* Der Bus ist dann 2,4-fach übernachgefragt und die effektive
Abtastung sinkt auf ≈ 600 ms je Sensor. Wer diesen Fall real erwartet,
verteilt die Sensoren auf beide Stapel (je Bus ≤ 6 Sensoren bleiben auch im
FAST-Worst-Case unter der Sättigung: 6 × 16 % ≈ 96 %) oder erhöht `fast_ms`.

**Hardware-Empfehlung** unverändert §2 des Auftrags, durch diese Analyse
bestätigt: **≥ 4 GB RAM** (SEPWatch-Vollausbau braucht ~2,3–3,4 GB; ein
2-GB-Pi 4 passt nur mit InfluxDB-2.x-Rückfall und ohne Kiosk), gute
SD-Karte (A2) oder SSD wegen der InfluxDB-Schreiblast, und für den zweiten
Stapel `dtoverlay=i2c6` (einzige kollisionsfreie Bus-Wahl, siehe
docs/04-verdrahtung.md).

---

## 5. Annahmen und Grenzen dieser Analyse

- I²C-Timings gerechnet mit Standard-Baudrate 100 kHz, `DR860`, 6-fach-
  Mittelung, Referenzkanal in jedem Zyklus (alles Code-Defaults). Gemessene
  Werte auf realer Hardware können ±20 % abweichen (Kernel-Scheduling,
  Clock-Stretching des ADS1115).
- RAM-Werte sind Erfahrungsgrößen typischer Installationen (InfluxDB 3 Core,
  Grafana 11, Chromium im Kiosk-Modus), keine Garantien — der erweiterte
  Systemstatus der Konfigurationsseite und `free -h` zeigen die realen Werte.
- Der Testsensor (Simulation, docs/05-testsensor.md) erzeugt **keine**
  I²C-Last — mit ihm lässt sich die restliche Kette (InfluxDB, SSE, Kiosk)
  gefahrlos auch über die Busgrenze hinaus belasten, z. B. 30 simulierte
  Sensoren mit kurzer Sinus-Periode als Lasttest vor dem Feldeinsatz.
