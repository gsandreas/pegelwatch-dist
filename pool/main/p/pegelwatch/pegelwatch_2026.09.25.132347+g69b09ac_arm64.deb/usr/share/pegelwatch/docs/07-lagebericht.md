# PegelWatch — Lagebericht (PDF)

Der PDF-Bericht ist als **Lagebericht für eine Einsatzleitung** aufgebaut, nicht
als technisches Messprotokoll. Er folgt der Gliederung der Lagefeststellung
(Allgemeine Lage, Eigene Lage, Schadenslage, Lageführung) und übersetzt jedes
ihrer Elemente in die Größen dieser Anlage: **Messstellen, Behälter, Durchsatz,
Daten**.

Das Format ist für **alle drei Aufbauten dasselbe** — der Mehrkanal-Aufbau 2 ist
die Leitform. Aufbauspezifische Angaben (Pumpe, Strommessung) erscheinen
zusätzlich, wenn die Anlage sie hat.

Erstellt wird er
* manuell über das 📄-Symbol in den Kiosk-Ansichten oder über `/berichte`,
* automatisch täglich zur Uhrzeit `report.daily_at` an `report.default_to`.

---

## Woher die Angaben kommen

| Quelle | liefert |
|---|---|
| **Laufender Prozess** (Momentaufnahme) | aktuelle Pegel/Volumen, Alarmzustände, Dienst-Erreichbarkeit, gefundene Hardware, Pumpen-/Shelly-Zustand |
| **InfluxDB** (Verlauf) | Diagramme, Min/Mittel/Max, Durchsatz im Zeitraum, Trend und Prognose |
| **SQLite-Zustand** | Summen seit Nullung, Zeitpunkt der letzten Nullung, Einsatztagebuch |
| **Konfiguration** | Behältergeometrie, Schwellwerte, Kanalbelegung |

Wichtig: Fällt die **InfluxDB** aus, bleibt der Bericht aussagefähig. Verlauf,
Trend und Prognose fehlen dann (und werden als fehlend ausgewiesen), aber die
Momentaufnahme — Pegel, Bestand, Füllgrad, Alarme, Bilanzen seit Nullung —
steht weiterhin, weil sie nicht aus der Zeitreihendatenbank stammt.

---

## Aufbau des Berichts

### Kurzlage (Seite 1)

Was in den ersten fünf Sekunden gelesen wird: eine **Gesamtbeurteilung** in
einem Satz (grün/gelb/rot), die kritischen Meldungen als Aufzählung, dann die
Kernzahlen — anstehende Alarme, Gesamtbestand gegen Kapazität, Durchsatz im
Zeitraum, Messstellen in Betrieb, erreichbare Dienste (bei Aufbau 3 zusätzlich
die Pumpe). Darunter die Schadenslage-Tabelle im Überblick.

### 1 Allgemeine Lage — Ist-Zustand des Objekts

| Element der Lage | Entsprechung in dieser Anlage |
|---|---|
| Bebauung (Dichte, Nutzung) | Anzahl und Nutzung der Messstellen: wie viele mit Behältergeometrie (bilanzfähig) und wie viele als reine Pegelmessung; welche deaktiviert oder Testsensor sind |
| Topographie | **Behältergeometrie** — sie ist das „Gelände" dieser Lage: sie bestimmt, wie viel Wasser wo Platz hat und wie aus einem Pegel eine Menge wird (Formen, Nennvolumen, Höhen) |
| Wetter | Von der Anlage nicht gemessen; ersatzweise die Umgebungslage der Technik (CPU-/GPU-Temperatur). Ausdrücklich als „nicht gemessen" gekennzeichnet |
| Zeit | Erstellzeitpunkt, Wochentag, Tag/Nacht, Berichtszeitraum, Betriebsdauer der Anlage |
| Verkehrs-/Fernmeldelage | **Datenwege**: Erreichbarkeit von InfluxDB (Datenhaltung), Grafana (Darstellung), SMTP (Meldeweg), Shelly; dazu die Netzanbindung der Messstelle. Ohne sie ist die Lage messbar, aber nicht speicherbar, darstellbar oder meldbar |

### 2 Eigene Lage — vorhandene Mittel

| Element der Lage | Entsprechung |
|---|---|
| Eigene Technik | Messstellen, gefundene ADS1115-Wandler, Anzeige, Pneumatik, Relaiskarte, Pumpe, Strommessung, Softwarestand |
| Personalentwicklung / Reserven | **freie Messkanäle** je I²C-Stapel und freie Logik-Relaiskanäle — wie viele Messstellen bzw. Schaltausgänge ohne neue Hardware nachrüstbar sind; dazu die Ausfallreserve der Datenhaltung |
| Verbrauchsmaterial | **freies Aufnahmevolumen** der Behälter (wie viel Wasser passt noch hinein), gebundenes Volumen, Zustand der Datenhaltung |
| Personal | Von der Anlage **nicht** erfasst — der Bericht sagt das ausdrücklich und weist die Ergänzung der Einsatzleitung (SGL 2) zu, statt eine Zahl zu erfinden |

### 3 Schadenslage — der dynamische Verlauf

Je Messstelle eine Zeile:

* **Gefahr** — anstehende Alarme (Hochwasser, Niedrigwasser, Leckage).
* **Veränderung der Gefahr** — Trend der **letzten Stunde** (mm/h und L/h,
  bewusst nicht über den ganzen Berichtszeitraum gemittelt: die Einsatzleitung
  braucht die aktuelle Entwicklung).
* **Prognose** — „voll in ca. 4 Stunden" / „leer in ca. 90 Minuten" /
  „Bestand stehend", gerechnet aus Bestand, Kapazität und aktueller Rate.

Bewertung je Messstelle (die Regel steht im Bericht mit drauf):

| Ampel | Bedeutung |
|---|---|
| 🔴 rot | Ein Alarm steht an |
| 🟡 gelb | Füllgrad über 90 % oder unter 5 %, oder keine belastbaren Daten |
| 🟢 grün | im Normalbereich |

Die Gesamtbeurteilung ist die schlechteste Einzelbewertung; ein nicht
erreichbarer Dienst zählt ebenfalls als kritische Meldung.

### 4 Messstellen im Detail — je Messstelle eine Seite

**Alle** Sensoren erscheinen, nicht nur die messenden:

* **aktiv** — Diagramm (Pegel + Volumen) und alle Kennzahlen.
* **deaktiviert** — mit Hinweis, dass die Messstelle abgeschaltet ist.
* **Testsensor (Simulation)** — mit dem ausdrücklichen Hinweis, dass die Werte
  **nicht lagerelevant** sind und nicht als Einsatzdaten verwendet werden dürfen.

Die Einsatzleitung soll sehen, welche Messstellen es gibt **und** welche davon
gerade keine belastbaren Daten liefern. Eine fehlende Messstelle ist eine
Information, kein Grund zum Weglassen.

### 5 Bilanzen — Durchsatz und Bestand

* **Bilanz über den Berichtszeitraum** — die abtransportierte Menge. Sie wird
  aus dem nie genullten Lebensdauer-Zähler gebildet und bleibt deshalb auch dann
  richtig, wenn eine Messstelle zwischendurch genullt wurde.
* **Bilanz seit der letzten Messstellennullung** — die Bezugsgröße für
  abgeschlossene Einsatzabschnitte.

### 6 Lageführung — Einsatztagebuch und Dokumentation

Chronologischer Auszug aus dem **Einsatztagebuch** der Anlage. Protokolliert
werden:

| Art | Ereignis |
|---|---|
| `ALARM` / `Entwarnung` | Jeder Wechsel eines Alarmzustands je Messstelle |
| `Pumpe` | Jeder beendete Pumpenlauf mit Dauer und Abschaltgrund |
| `Betrieb` | Messstellennullung, Konfiguration gespeichert, Bericht erstellt, Verdrahtungstest, Neustart über die Weboberfläche |
| `System` | Dienststart und -ende |

Alarme werden dabei beim **Zustandswechsel** protokolliert, nicht beim
Mailversand: ein Alarm bei nicht erreichbarem Mailserver stünde sonst in keinem
Tagebuch. Für die Lageführung zählt der Zustand, nicht die Zustellung.

Zum Problem der Unveränderbarkeit digitaler Dokumente: Von jedem erzeugten PDF
wird die **SHA-256-Prüfsumme** gebildet und im Berichtsindex festgehalten. Sie
steht auf der Seite `/berichte` neben jedem Bericht — eine nachträgliche
Änderung des Dokuments ist damit erkennbar.

Zum Schluss der Verteiler: Empfänger, Auslösung (manuell/automatisch), der
Grafana-Link für die laufende Lagedarstellung und der Ablageort.

Ereignisse werden 180 Tage vorgehalten, erzeugte Berichte ebenso.

---

## Konfiguration

Siehe `[report]` in [docs/02-konfiguration.md](02-konfiguration.md):

```toml
[report]
default_to    = ["einsatzleitung@example.de"]
daily_at      = "06:00"   # leer = kein automatischer Versand
balance_hours = 24        # Bilanzzeitraum des regelmäßigen Berichts
```

Die PDF-Erzeugung braucht Chromium auf dem Pi:

```bash
sudo apt install chromium
```
