# PegelWatch — Konfigurationsreferenz

Alle Konfigurationsparameter von `config.toml` und `secrets.toml`.

---

## Aufbau-Typ

```toml
aufbau = 1   # 1 = Einzelsensor, 2 = Mehrkanal, 3 = Pumpwerk
```

Die drei Aufbauten heißen überall gleich (Weboberfläche, Grafana-Dashboards,
Geräte-Register `deploy/devices.psd1`); je nach aktivem Aufbau tritt die
Weboberfläche unter einem eigenen Produktnamen auf:

| Wert | Bezeichnung | Produktname | Beschreibung |
|---|---|---|---|
| `1` | Einzelsensor | **RIVERWatch** | Ein Drucksensor (+ Referenz), kein Relais |
| `2` | Mehrkanal | **SEPWatch** | Mehrere Behälter, Füllstands-/Durchsatzsummen, Leckage-Erkennung |
| `3` | Pumpwerk | **PUMPWatch** | Pumpensteuerung mit Drehstrommotor, Relaiskarte und Shelly 3EM |

---

## [i2c]

```toml
[i2c]
bus = 1   # Standardbus /dev/i2c-1 (GPIO2/GPIO3) für Sensoren ohne i2c_bus

# Nur nötig, wenn ein Zusatz-Bus NICHT die Standard-Overlay-Pins nutzt
# (z. B. dtoverlay=i2c4,pins_6_7 oder Pi-5-Overlays). Schlüssel = Busnummer,
# Wert = [SDA, SCL] in BCM-Nummerierung — Grundlage der Interferenzprüfung.
# [i2c.bus_pins]
# 4 = [6, 7]
```

Zusätzliche Busse für einen **zweiten ADS1115-Stapel** werden per
Device-Tree-Overlay aktiviert (Empfehlung `dtoverlay=i2c6` → GPIO22/23) und
je Sensor über `i2c_bus` ausgewählt. Bekannte Standard-Belegungen (Pi 4):
i2c3=GPIO4/5, i2c4=GPIO8/9, i2c5=GPIO12/13, i2c6=GPIO22/23. Vollständige
Tabelle inkl. Auswirkung auf die Relaiskanäle: [docs/04-verdrahtung.md](04-verdrahtung.md).

---

## [[sensor]]

Mehrere Sensoren werden als TOML-Array definiert. Mindestens einer ist erforderlich.

```toml
[[sensor]]
id          = "s1"         # Eindeutiger Bezeichner (alphanumerisch)
name        = "Hauptbehälter"  # Anzeigename in Web-UI und InfluxDB
enabled     = true         # false = Sensor wird nicht abgefragt (fehlend = true)
# i2c_bus   = 6            # I²C-Bus dieses Sensors; weggelassen/0 = [i2c].bus.
                           # Ein Bus = ein Stapel (max. 4 Boards); zweiter
                           # Stapel z. B. auf Bus 6 (dtoverlay=i2c6)
board_addr  = 0x48         # ADS1115-Adresse: 0x48, 0x49, 0x4A oder 0x4B (je Bus)
channel     = 1            # ADC-Kanal 0–3 (Sensor-Signal)
ref_channel = 0            # ADC-Kanal 0–3 (Referenzspannung LT1461)
                           # gleicher Kanal auf demselben Board → kein Referenzkanal
# ref_board_addr = 0x48    # Board des Referenzkanals; weggelassen/0 = eigenes Board

[[sensor.calibration]]
water_mm = 0.0      # Pegelstand in mm
volts_mv = 210.0    # Sensorspannung in mV (ratiometrisch kompensiert)

[[sensor.calibration]]
water_mm = 5097.0
volts_mv = 4520.0
```

Konvention (§2 des Auftrags): **der erste Kanal (0) ist die Referenz, der
zweite Kanal (1) der erste Drucksensor** — wie im Beispiel oben.

**Kalibrierung:**
- Mindestens 2 Stützpunkte erforderlich (empfohlen ≥ 10)
- `water_mm` und `volts_mv` müssen strikt monoton steigend sein; `volts_mv`
  muss größer 0 sein (wird beim Speichern erzwungen)
- Physikalische Grenze: max. 5.097 mm (50 kPa / MPXV5050DP-Limit)
- Interpolation erfolgt stückweise linear
- **Oberhalb des höchsten Stützpunkts wird die Gerade des letzten Segments
  linear verlängert** (begrenzt auf ~5,1 m): Es genügt z. B., nur die ersten
  50 mm Tauchtiefe zu vermessen — der restliche Messbereich folgt derselben
  Geraden, weil der MPXV5050DP linear ist. Unterhalb des untersten Punkts
  wird weiterhin auf dessen Pegel begrenzt.

**Mehrere Sensoren auf einem Board:**
Gleicher `board_addr`, unterschiedliche `channel`-Werte. Ein Messkanal darf
nie auf einem Kanal liegen, der (von irgendeinem Sensor) als Referenzkanal
genutzt wird — der Referenzkanal ist fest auf die Versorgungsspannung
verdrahtet. Die Validierung lehnt solche Kollisionen ab.

**Mehrere ADS1115-Boards:**
Unterschiedliche `board_addr`-Werte (0x48–0x4B via ADDR-Pin), maximal 4 Boards.

**Referenz-Modus (pro Board oder pro Stapel):**
- *Pro Board* (Default): `ref_board_addr` weglassen — jedes Board misst seine
  eigene Referenz auf einem seiner Kanäle. Kostet 1 Kanal pro Board
  (max. 12 Drucksensoren bei 4 Boards).
- *Pro Stapel*: bei **allen** Sensoren dasselbe `ref_board_addr` (z. B. `0x48`)
  und `ref_channel` angeben — der ganze Stapel teilt sich eine Referenz.
  Kostet nur 1 Kanal insgesamt (max. **15 Drucksensoren je Stapel**).
  Die Referenz gilt **je Bus/Stapel** — ein zweiter Stapel (`i2c_bus`) braucht
  seine eigene Referenzmessung (max. 30 Drucksensoren mit zwei Stapeln).

## [sensor.simulation] — Testsensor ohne Messhardware

```toml
[sensor.simulation]
enabled      = true    # dieser Sensor liest KEINE Hardware, sondern simuliert
mean_mm      = 1000.0  # Grundpegel (per Web-UI-Schieberegler live verschiebbar)
amplitude_mm = 800.0   # Sinus-Amplitude um den Grundpegel; 0 = konstant
period_s     = 300     # Dauer eines vollen Sinus-Zyklus (Standard: 300)
```

Ein Testsensor wird wie ein normaler Sensor konfiguriert (Kalibrierung, Tank,
Alarme) und durchläuft den kompletten Signalweg — er belegt aber **kein**
Kanalbudget und braucht keine ADS1115-Hardware. Details und Anwendungsfälle:
[docs/05-testsensor.md](05-testsensor.md).

## [sensor.tank] — Behälter (optional)

Nur nötig, wenn Volumen/Durchsatz berechnet werden sollen (§4 des Auftrags).
Ohne Behälter misst der Sensor nur den Pegel — keine Mengenbilanz.

Es gibt zwei Wege: einen **Standardbehälter** verwenden (die Geometrie wird
dann zentral gepflegt, siehe [tank_preset](#tank_preset--standardbehälter)) oder
die Maße nur für diesen Sensor eintragen.

```toml
# Variante A — Standardbehälter (empfohlen, wenn der Typ mehrfach vorkommt)
[sensor.tank]
preset       = "IBC 1.000 l (1,00 × 1,20 m)"
write_volume = true          # bleibt eine Einstellung DIESES Sensors

# Variante B — eigene Geometrie
[sensor.tank]
type            = "cylinder" # cylinder | box | frustum
height_mm       = 2000.0     # maßgebliche Füllhöhe (nicht zwingend Bauhöhe)
diameter_mm     = 1000.0     # nur cylinder: Innendurchmesser
# side_mm         = 1200.0   # nur box: Länge der Grundfläche
# width_mm        = 1000.0   # nur box: Breite; 0/weggelassen = quadratisch
# bottom_area_mm2 = 78540.0  # nur frustum: Fläche unten
# top_area_mm2    = 78540.0  # nur frustum: Fläche oben
write_volume    = true       # Volumen zusätzlich in InfluxDB schreiben
```

Ist `preset` gesetzt, stammt die **gesamte** Geometrie aus der Vorlage; die
übrigen Felder werden ignoriert (Ausnahme: `write_volume`). Zeigt `preset` auf
eine Vorlage, die es nicht gibt, wird das Speichern abgelehnt — der Sensor liefe
sonst stillschweigend ohne Mengenbilanz.

`height_mm` ist die für die Mengenrechnung **maßgebliche Füllhöhe**, nicht
zwingend die Bauhöhe: bei einem Schnelleinsatzbehälter (Bauhöhe 1,50 m) sind das
1,20 m — erst damit ergibt die Geometrie die Nennmenge.

---

## [[tank_preset]] — Standardbehälter

Wiederverwendbare Behältergeometrien. Sie werden **einmal** definiert und stehen
danach in jeder Sensorkarte per Auswahlliste zur Verfügung (`[sensor.tank]`
`preset`). Eine Änderung an der Vorlage wirkt auf alle Sensoren, die sie
verwenden.

**Eingebaut** (immer verfügbar, stehen nicht in der `config.toml`, nicht
löschbar):

| Vorlage | Geometrie | Fassungsvermögen |
|---|---|---|
| IBC 300 l | Quader 800 × 600 mm, Höhe 1000 mm | 480 L |
| IBC 600 l | Quader 1200 × 800 mm, Höhe 1013 mm | 973 L |
| IBC 640 l | Quader 1200 × 1000 mm, Höhe 1150 mm | 1.380 L |
| IBC 800 l | Quader 1000 × 1200 mm, Höhe 1000 mm | 1.200 L |
| IBC 1.000 l | Quader 1000 × 1200 mm, Höhe 1160 mm | 1.392 L |
| Schnelleinsatzbehälter 30.000 l | Zylinder Ø 5,80 m, Füllhöhe 1,20 m | 31.700 L |
| Schnelleinsatzbehälter 50.000 l | Zylinder Ø 7,28 m, Füllhöhe 1,20 m | 49.900 L |
| Schnelleinsatzbehälter 75.000 l | Zylinder Ø 8,92 m, Füllhöhe 1,20 m | 75.000 L |
| Abrollbehälter Zwischenlager 36.000 l | Quader 6500 × 2350 mm, Höhe 2350 mm | 35.900 L |

Das Fassungsvermögen ergibt sich aus der Geometrie und kann von der
Typbezeichnung abweichen (bei den IBC ist die **Bauhöhe** hinterlegt; ist die
tatsächliche Füllhöhe geringer, die Vorlage kopieren und die Höhe anpassen —
Knopf **„⧉ Als eigene Vorlage kopieren"** in der Weboberfläche).

**Eigene Vorlagen** (in der Weboberfläche unter *Standardbehälter → Eigene
Vorlagen*, oder direkt in der Datei):

```toml
[[tank_preset]]
name        = "Zisterne Nord"
type        = "cylinder"     # cylinder | box | frustum
height_mm   = 1600.0
diameter_mm = 2000.0
```

Namen müssen eindeutig sein und dürfen keine eingebaute Vorlage überschreiben.
Eine Vorlage, die noch von einem Sensor verwendet wird, lässt sich nicht
entfernen.

## [sensor.profile] — Gewässer-Querschnitt (Aufbau 1, optional)

Für eine Messstelle in einem Fließgewässer: Aus dem Querschnittsprofil und dem
gemessenen Pegel ergibt sich die **benetzte Fläche**, zusammen mit der
**Fließgeschwindigkeit** der **Durchfluss** (Q = A · v). Beides zeigt der
Fluss-Kiosk (`/fluss-kiosk`) und das Signal-Register (`profile.<id>.*`).

Der Querschnitt ist ein **Stapel von Trapezen**: je Stützpunkt eine Höhe über
der Sohle und die Gewässerbreite in dieser Höhe; zwischen zwei Punkten verläuft
die Uferlinie gerade.

```toml
[sensor.profile]
velocity_mode  = "points"   # none | points | manning

[[sensor.profile.point]]    # Sohle — MUSS auf height_mm = 0 liegen
height_mm = 0
width_mm  = 800             # 0 = V-Profil (spitze Sohle)
[[sensor.profile.point]]
height_mm = 150
width_mm  = 1800
[[sensor.profile.point]]    # Oberkante Böschung
height_mm = 400
width_mm  = 3000

[[sensor.profile.velocity]] # nur bei velocity_mode = "points"
height_mm   = 0
velocity_ms = 0.30
[[sensor.profile.velocity]]
height_mm   = 400
velocity_ms = 1.10
```

**Regeln:**
- Mindestens **zwei** Stützpunkte, der unterste auf `height_mm = 0`.
- Je Höhe genau **eine** Breite (ein senkrechter Absatz lässt sich mit Trapezen
  nicht abbilden — dafür zwei Punkte mit minimalem Höhenunterschied setzen).
- Die Reihenfolge der Punkte ist egal, es wird nach Höhe sortiert.
- Oberhalb des höchsten Stützpunktes wird mit **senkrechten Wänden**
  weitergerechnet — ein Pegel über dem Profil liefert damit weiter plausible
  Werte statt zu springen.
- Ohne `[[sensor.profile.point]]` ist das Profil nicht konfiguriert: der Kiosk
  zeichnet ein symbolisches Trapez, Fläche und Durchfluss bleiben leer.

**Fließgeschwindigkeit — `velocity_mode`:**

| Wert | Bedeutung |
|---|---|
| `none` (Standard) | Keine Geschwindigkeit — nur die Fläche wird berechnet, kein Durchfluss. |
| `points` | Stützstellen `[[sensor.profile.velocity]]` (Pegel → m/s, z. B. aus Messflügel-Messungen). Dazwischen linear interpoliert, außerhalb gilt der äußerste Wert. Eine einzelne Stützstelle = konstante Geschwindigkeit. |
| `manning` | Formel von Manning-Strickler: v = k · R^(2/3) · I^(1/2) mit dem hydraulischen Radius R = A/U. Braucht `strickler_k` und `slope_permille`. |

```toml
[sensor.profile]
velocity_mode  = "manning"
strickler_k    = 30.0   # Rauheitsbeiwert k_St in m^(1/3)/s:
                        # Wiesenbach ~25, Kies ~30–35, glatter Beton ~80
slope_permille = 2.5    # Sohlgefälle in Promille (2,5 ‰ = 0,0025)
```

In der Konfigurations-Weboberfläche wird der Querschnitt beim Eintippen
**live gezeichnet**, samt Fläche und überschlägigem Durchfluss bei randvollem
Profil.

## [sensor.alarms] — Alarme je Sensor

```toml
[sensor.alarms]
high_water_mm       = 1800.0 # Hochwasser-Alarm ab diesem Pegel
high_water_enabled  = true
low_water_mm        = 50.0   # Niedrigwasser-Alarm unter diesem Pegel
low_water_enabled   = true
max_drain_gradient_mm_per_s = 0.0   # Leckage: erwarteter max. Entleer-Gradient; 0 = aus
leakage_alarm_enabled       = false # nur sinnvoll bei externen Entnahmepumpen (Aufbau 2)
```

---

## default_calibration — zentrale Standard-Kalibrierung (optional)

Eine Kennlinie für alle baugleichen Sensoren: **einmal** vermessen, von beliebig
vielen Sensoren genutzt. Sie wird in der Weboberfläche im eigenen Abschnitt
*Standard-Kalibrierung (zentral)* gepflegt.

```toml
# Achtung TOML: Der Schlüssel muss VOR der ersten Tabellen-Überschrift stehen,
# sonst zählt er zur zuletzt geöffneten Tabelle.
default_calibration = [
  { water_mm = 0.0,    volts_mv = 210.0 },
  { water_mm = 2500.0, volts_mv = 2350.0 },
  { water_mm = 5097.0, volts_mv = 4520.0 },
]
```

Es gibt zwei Arten, sie zu nutzen:

**1. Dauerhafte Bindung** — `use_default_calibration = true` in `[[sensor]]`
(Haken *„Zentrale Standard-Kalibrierung verwenden"* in der Sensorkarte). Der
Sensor misst dann mit der zentralen Kennlinie; eine Änderung dort wirkt nach dem
nächsten Neustart auf **alle** so gebundenen Sensoren. Eigene
`[[sensor.calibration]]`-Punkte darf der Sensor trotzdem behalten — sie sind
gespeichert, aber nicht wirksam, und gelten wieder, sobald der Haken fällt.
Der Haken ist also keine Löschung.

**2. Einmaliges Kopieren** — Knopf **„⬇ Standard in eigene Kennlinie kopieren"**.
Der Sensor bekommt eine eigene Kopie der Kennlinie und kann sie danach
individuell nachjustieren (wie bisher). Umgekehrt erhebt **„★ Als Standard
setzen"** die fertig vermessene Kennlinie eines Sensors zum Standard.

Optional; wenn gesetzt, gelten dieselben Regeln wie bei der Sensor-Kalibrierung
(mindestens 2 Punkte, `water_mm`/`volts_mv` strikt monoton steigend). Ist
mindestens ein Sensor gebunden, ist sie **Pflicht** — sonst würde dieser Sensor
unkalibriert laufen, und das Speichern wird abgelehnt. Kopieren und Löschen sind
genauso doppelt abgesichert (Rückfrage + Bestätigungseingabe) wie das Löschen
einer Sensor-Kalibrierung.

---

## Verdrahtungstest der Relaisausgänge

Kein Konfigurationsschlüssel, sondern ein Werkzeug der Weboberfläche
(*Konfiguration → Verdrahtungstest der Relaisausgänge*): Jeder tatsächlich
betriebene Relaisausgang — Pumpe, Alarm, Pneumatik (Aufbau 3), die einzelne
Pneumatik-GPIO-Leitung (Aufbau 1/2) und jeder Logik-Ausgang — bekommt eine
Checkbox, die das Relais **sofort** schaltet. Damit lässt sich nach der Montage
prüfen, ob die Verdrahtung stimmt: anhaken, hören/messen ob das richtige Relais
klickt, wieder abhaken.

Betrieben werden dieselben GPIO-Objekte wie im Automatikbetrieb (eine zweite
GPIO-Leitung ließe sich gar nicht öffnen). Die Automatik behält daher jederzeit
die Oberhand und setzt ihren Ausgang beim nächsten Takt wieder — an jedem Kanal
steht, wer ihn übersteuern kann. Zwei Sicherungen:

* Das **Pumpenrelais** wird nur geschaltet, wenn die Pumpensteuerung in der
  Betriebsart **„Aus"** steht (sonst arbeitete der Test gegen die Automatik).
  Ausschalten ist immer erlaubt.
* Beim Herunterfahren des Dienstes und über den Knopf **„⏻ Alle Ausgänge sofort
  aus"** gehen alle Testausgänge in den sicheren Aus-Zustand.

Jede Schalthandlung wird ins Einsatztagebuch geschrieben (siehe
[docs/07-lagebericht.md](07-lagebericht.md)).

---

## [polling]

Adaptive Abtastrate: im Ruhemodus langsam, bei erkannter Pegeländerung schnell.
Alle Schwellwerte und Zeiten sind konfigurierbar (§4 des Auftrags).

```toml
[polling]
fast_ms = 250   # Abtastrate im Schnellmodus in ms (Standard: 250)
slow_s  = 20    # Abtastrate im Langsammodus in s (Standard: 20)

# Sprungerkennung (langsam → schnell) — BEIDE Bedingungen müssen erfüllt sein:
jump_pct    = 10.0  # relative Pegeländerung in % (Standard: 10)
jump_abs_mm = 2.0   # absolutes Totband in mm (Standard: 2,0) — verhindert
                    # Scheinsprünge bei fast leerem Behälter

# Sättigungserkennung (schnell → langsam):
stable_window = 100 # Fenstergröße in Messwerten (Standard: 100)
stable_pct    = 1.0 # Spanne (max−min) relativ zum Mittelwert in % (Standard: 1)
```

*Nebenrechnung:* 100 × 250 ms = 25 s Beobachtung bis zur Rückschaltung.

---

## [throughput] — Füllung/Durchsatz (Wellenproblem)

Glättung, Totband und Trendbedingung der Füllungs-/Durchsatzberechnung
(vor allem Aufbau 2, §4 des Auftrags).

```toml
[throughput]
smoothing_window     = 5    # Fenstergröße gleitender Median (Standard: 5)
deadband_mm          = 3.0  # Rausch-Totband in mm (Standard: 3,0)
min_trend_duration_s = 10   # Mindestdauer eines anhaltenden Trends (Standard: 10)
```

---

## [display]

MAX7219CWG 7-Segment-Display (4-stellig, SPI0).

```toml
[display]
enabled = true   # false = Display deaktiviert (kein Fehler wenn kein SPI)
```

**Pinbelegung (fest):**
- DIN → GPIO10 (SPI0 MOSI)
- CLK → GPIO11 (SPI0 CLK)
- CS  → GPIO8  (SPI0 CE0)

Diese drei Pins sind bei `enabled = true` belegt und stehen nicht mehr für
Logik-Ausgänge zur Verfügung (die Konfiguration lehnt eine Doppelbelegung ab).

Auch über die **Konfigurations-Weboberfläche** schaltbar: Abschnitt
*Allgemein* → *7-Segment-Display (MAX7219)*. Wirkt nach Speichern und
Dienst-Neustart.

**Anzeige beim Herunterfahren.** Wird die Anlage über den Kiosk-Knopf oder das
Cloud-Frontend abgeschaltet, zeigt das Display einen umlaufenden **Ladekreis**
(Segmentmuster im No-Decode-Modus) und behält ihn auch nach dem Ende des
Dienstes — der MAX7219 hält sein letztes Bild von selbst. Die Endmeldung
**`AUS`** schreibt der systemd-Hook
`/usr/lib/systemd/system-shutdown/pegelwatch-display` über
`pegelwatch --display-off` im allerletzten Moment, nachdem die Dateisysteme
ausgehängt sind. Beides richtet `deploy.ps1` automatisch ein.

---

## [web]

```toml
[web]
port  = 8080     # HTTP-Port (Standard: 8080)
kiosk = "auto"   # Seite für einen am Pi angeschlossenen Bildschirm
```

**`kiosk`** bestimmt, welche Seite der Dienst beim Start auf einem **am Pi
angeschlossenen Monitor** im Vollbild öffnet (Chromium, siehe `internal/gui`).
Das betrifft **nur diese Selbstanzeige** — über das Netzwerk sind ohnehin alle
Seiten erreichbar.

| Wert | Wirkung |
|---|---|
| `auto` (Standard) | Nach aktivem Aufbau: 1 → `/fluss-kiosk`, 2 → `/aufbau2-kiosk`, 3 → `/pump-kiosk` |
| `fluss` / `aufbau2` / `pump` / `start` | Feste Seite, unabhängig vom Aufbau |
| `off` | Kein Selbststart — für Anlagen ohne Bildschirm |

Der Dienst läuft als systemd-Systemdienst **ohne Sitzungsumgebung**. Er setzt
deshalb selbst `DISPLAY=:0` (und `XAUTHORITY`, falls `~/.Xauthority`
existiert), sonst beendet sich Chromium sofort mit Exit-Status 1. Ein in der
systemd-Unit gesetztes `DISPLAY` hat Vorrang — z. B. für einen zweiten
Bildschirm:

```ini
[Service]
Environment=DISPLAY=:1
```

Die Weboberfläche hat bewusst **kein Login-Passwort** — sie ist fürs lokale
Netz gedacht. Schutz vor versehentlichem Löschen gibt es gezielt für die
Sensor-Kalibrierung: die Konfigurationsseite (`/konfiguration`) fragt beim
Löschen einzelner Kalibrierpunkte einmal, beim Löschen der kompletten
Kalibrierung eines Sensors zweimal nach (inkl. Eintippen der Sensor-ID).

---

## [alarm]

Alarm-Mails bei Über- und Unterschreitung von Schwellwerten.

```toml
[alarm]
enabled = true
high_mm = 4500.0   # Hochwasser-Alarm ab diesem Pegelstand [mm]
low_mm  = 100.0    # Niedrigwasser-Alarm unter diesem Pegelstand [mm]
```

**Hysterese:** 50 mm — nach dem Alarm wird erst dann wieder eine Mail gesendet,
wenn der Pegel die Schwelle um 50 mm in der entgegengesetzten Richtung
überschritten hat.

---

## [smtp]

Konfiguration für Alarm-Mails.

```toml
[smtp]
host = "smtp.example.com"
port = 587          # 587 = STARTTLS, 465 = direktes TLS (SMTPS)
from = "pegelwatch@example.com"
to   = ["operator@example.com", "backup@example.com"]
user = ""           # Login-Benutzername (§8: Host, Port, Benutzer, Passwort);
                    # leer = Absenderadresse (from) wird als Benutzer verwendet.
                    # Viele Provider verlangen hier die Postfach-Adresse.
helo = ""           # optional: HELO/EHLO-Name; leer = eigene IP als Adress-
                    # Literal ("[192.168.0.106]"). Setzen, wenn der Server
                    # "550 Invalid HELO name" meldet und einen FQDN verlangt.
# password → secrets.toml
```

Authentifiziert wird nur, wenn ein Passwort gespeichert ist (sonst versucht
PegelWatch unauthentifiziertes Relaying — Fehlermeldung *"not permitted to
relay"* bedeutet fast immer: Passwort fehlt oder Benutzername falsch). Als
Mechanismus wird AUTH PLAIN verwendet, bei Servern, die nur AUTH LOGIN
anbieten, automatisch LOGIN.

Die SMTP-Konfiguration lässt sich direkt über den Button **"✉ Testmail
versenden"** auf der Konfigurationsseite prüfen. Scheitert ein
Alarm-Mailversand, wird frühestens nach 5 Minuten erneut versucht (kein
Log-/Versand-Spam bei Fehlkonfiguration); der Alarmzustand selbst bleibt
davon unberührt.

**Datenbank-Ausfallalarm** (immer aktiv, sobald ein SMTP-Server eingetragen
ist): Nimmt ein InfluxDB-Ziel (`local` oder `fhem`) länger als **15 Minuten**
keine Messwerte an, verschickt PegelWatch eine Mail „Datenbank-Ausfall“ und
trägt den Ausfall ins Einsatztagebuch ein. Sobald wieder geschrieben wird,
folgt eine Entwarnung. Pro Ausfall gibt es nur eine Mail, auch über einen
Dienstneustart hinweg. Messung und Steuerung laufen während des Ausfalls
weiter, die Messwerte dieser Zeit fehlen aber in der Datenbank.

---

## [influx]

Zwei unabhängige InfluxDB-Verbindungen: `local` (auf dem Pi) und `fhem`
(optionaler FHEM-Server). Beide unterstützen wahlweise InfluxDB 3 Core
(`api_version = "v3"`, Standard) oder InfluxDB 2.x (`api_version = "v2"`,
Rückfall für einen Pi 4 mit nur 2 GB RAM — siehe
[docs/01-installation.md](01-installation.md)).

```toml
[influx.local]
enabled     = true
url         = "http://localhost:8086"
database    = "pegelwatch"
api_version = "v3"   # "v3" (Standard) | "v2"
org         = ""     # nur fuer api_version="v2" (InfluxDB-2.x-Organisation)
# token → secrets.toml

[influx.fhem]
enabled     = false
url         = "http://fhem-server:8086"
database    = "pegelwatch"
api_version = "v3"
org         = ""
# token → secrets.toml
```

---

## [pneumatic] — alle Aufbauten

Pneumatikpumpe für die Drift-Kompensation (§5 des Auftrags).

```toml
[pneumatic]
enabled    = false
interval_s = 3600   # Pause zwischen zwei Pumpvorgaengen
runtime_s  = 30      # Laufzeit der Pumpe je Vorgang
gpio_line  = 17      # NUR Aufbau 1/2 (keine Relaiskarte vorhanden)
```

`gpio_line` wird nur in Aufbau 1/2 verwendet — dort steuert eine einzelne,
dedizierte GPIO-Leitung die Pumpe direkt (siehe
[docs/04-verdrahtung.md](04-verdrahtung.md)). In Aufbau 3 wird stattdessen
`relay.pneumatic_gpio` auf der Relaiskarte verwendet, `gpio_line` wird
ignoriert.

---

## [relay] — nur Aufbau 3

GPIO-Zuweisung für die Waveshare RPi Relay Board (B). Frei wählbar aus den
Standard-Kanalpins der Platine (siehe [docs/04-verdrahtung.md](04-verdrahtung.md)
für die vollständige 8-Kanal-Tabelle, Aktiv-LOW-Hinweis und NO/NC-Wechslerwahl);
alle drei Pins müssen unterschiedlich und außerhalb der reservierten Pins
(GPIO2, 3, 8, 10, 11) sein.

```toml
[relay]
pump_gpio      = 5    # CH1 — GPIO-Pin für Pumpen-Relais
alarm_gpio     = 6    # CH2 — GPIO-Pin für Alarm-Relais (Signalleuchte/Summer)
pneumatic_gpio = 13   # CH3 — GPIO-Pin für Pneumatikpumpe
```

**Gültige GPIO-Pins:** 1–27, außer 2, 3, 8, 10, 11. Sinnvoll sind vor allem die
8 Standard-Kanalpins der Relaiskarte (GPIO 5, 6, 13, 16, 19, 20, 21, 26) — jeder
andere Wert erfordert, den Kanal-Jumper auf der Platine umzustecken (siehe
docs/04-verdrahtung.md).

---

## [pump_control] — nur Aufbau 3

Regellogik der Drehstrompumpe (§3 des Auftrags: EIN bei hohem, AUS bei
niedrigem Pegel, Freifall-Selbstkalibrierung).

```toml
[pump_control]
on_level_mm        = 3000.0 # Pumpe startet im Auto-Modus ab diesem Pegel
off_level_mm       = 500.0  # Pumpe stoppt im Auto-Modus unter diesem Pegel
offset_mm          = 0.0    # wird addiert, wenn der Schlauch über dem Boden endet
freefall_volts_mv  = 250.0  # Spannungs-Schwelle der Freifall-Erkennung (mV)
self_cal_every     = 10     # Pumpvorgänge bis zur Nullpunkt-Selbstkalibrierung
self_cal_max_offset_mv = 30 # größte zulässige Nullpunkt-Korrektur (mV), sonst verworfen
max_runtime_s      = 300    # Maximallaufzeit am Stück (Rückfallschutz); 0 = aus
max_runtime_action = "lock" # "lock" = nach Zwangsstopp Modus auf "Aus" (Freigabe
                            # nur durch bewussten Moduswechsel) | "cooldown" =
                            # nach 5 min Abkühlzeit wieder frei
dryrun_ref_w       = 1260.0 # Leistung beim Fördern von Wasser (W, Summe L1–L3); 0 = aus
dryrun_drop_pct    = 20.0   # Abschaltung, wenn die Leistung um mehr als 20 % fällt
dryrun_hold_s      = 10     # … und zwar mindestens so lange am Stück (s)
```

- Sind `on_level_mm` **und** `off_level_mm` beide 0 (unkonfiguriert), setzt die
  Software automatisch die Defaults 3000/500 — sonst würde die Pumpe im
  Auto-Modus sofort und dauerhaft anlaufen.
- `freefall_volts_mv` ersetzt das frühere `freefall_pressure_pa`: Die Schwelle
  wird jetzt direkt als (ratiometrisch kompensierte) Sensorspannung angegeben —
  dieselbe Größe wie bei der Kalibrierung. Alte Konfigurationen mit Pa-Angabe
  werden beim Laden automatisch umgerechnet (0 kPa = 200 mV, 50 kPa = 4520 mV).
- **Nullpunkt-Selbstkalibrierung:** Alle `self_cal_every` Läufe fährt die Pumpe
  über die AUS-Schwelle hinaus bis zum Freifall. Mit aktiver
  Leistungsüberwachung (siehe unten) gilt der Freifall als erreicht, sobald die
  Pumpe Luft zieht — dann ist der Schacht leer und die Staudruckglocke sicher
  frei; ohne sie gilt die Spannungsschwelle `freefall_volts_mv`. Der neue
  Nullpunkt ist der **Median der letzten 10 s**, sofern er stabil ist (Streuung
  ≤ 5 mV), und wird gegen den **0-mm-Stützpunkt der Kalibrierung** gerechnet.
  Die Korrektur wird in `state.db` gespeichert (übersteht Neustarts) und
  verfällt, sobald die Kalibrierung geändert wird. Ergäbe sie mehr als
  `self_cal_max_offset_mv`, wird sie verworfen und per Mail gemeldet.
  Hinweis: Bis zum Luftzug läuft die Pumpe länger als ein normaler Lauf —
  `max_runtime_s` entsprechend großzügig wählen.
  *(Bis 09/2026 rechnete die Software gegen den Datenblattwert 200 mV statt
  gegen den Kalibrier-Nullpunkt; die Korrektur wuchs dadurch bei jeder
  Kalibrierung und verschob das Pegelfenster um bis zu ~165 mm.)*
- **Luft/Trockenlauf per Leistungsabfall:** Zieht die Pumpe Luft, sinkt ihre
  Leistungsaufnahme deutlich (Messung am Pumpwerk 24.09.2026: Wasser
  1230–1350 W, Luft 550–830 W). Liegt die Leistung (Summe der Beträge aller
  drei Phasen des Shelly 3EM) mindestens `dryrun_hold_s` am Stück mehr als
  `dryrun_drop_pct` unter `dryrun_ref_w` — mit den Defaults also unter 1008 W —,
  wird die Pumpe abgeschaltet (Alarm-Mail + Alarm-Relais). Danach gilt die
  Abkühlzeit (5 min), anschließend regelt die Automatik normal weiter. Die
  Anlauf-Karenz ist `overcurrent_grace_s`. Das schützt vor Überhitzung, ohne
  die Laufzeit zu begrenzen.
- Läuft die Pumpe länger als `max_runtime_s` am Stück, wird sie zwangsweise
  abgeschaltet (Alarm-Mail + Alarm-Relais). Das ist nur noch der
  Rückfallschutz, z. B. wenn der Shelly nicht erreichbar ist. Ein Moduswechsel auf **Automatik**
  übernimmt den Soll-Zustand sofort anhand des letzten Pegels (Ein→Automatik
  stoppt ggf. sofort, Aus→Automatik startet ggf. sofort).
- Nach **jedem** Pumpenlauf verschickt PUMPWatch einen **Laufbericht** per
  E-Mail: Start/Ende/Dauer, Abschaltgrund, Min/Mittel/Max je Phase, den
  Stromverlauf als PNG-Diagramm im Anhang (L1 = rot, L2 = grün, L3 = blau)
  und einen Grafana-Link auf das exakte Zeitfenster. Auch jede Umschaltung
  des Betriebsmodus (Kiosk-Buttons Automatik/Ein/Aus) wird per Mail gemeldet.

---

## [overcurrent] — nur Aufbau 3

```toml
[overcurrent]
threshold_a    = 15.0 # Überstrom je Phase: Pumpe aus + Alarm (E-Mail und Relais)
undercurrent_a = 1.0  # Unterstrom/Phasenausfall; 0 = Diagnose deaktiviert
                      # (nur aktiv, solange der Shelly erreichbar ist)

undercurrent_grace_s = 3 # Karenz nach dem Pumpenstart (Anlauf, Strom noch ~0)
overcurrent_grace_s  = 8 # Karenz nach dem Pumpenstart (Anlaufstrom über der Schwelle)
```

Die beiden Karenzzeiten überbrücken den Motoranlauf: der Anlaufstrom liegt
kurzzeitig weit über, die gemittelte Shelly-Messung zu Beginn noch unter dem
Betriebsstrom. Beide Werte werden auf den **Messzeitpunkt** des Shelly-Werts
bezogen, nicht auf den Auswertezeitpunkt — der Shelly wird nur alle 5 s
gepollt, derselbe Anlaufwert wird also mehrfach ausgewertet. Deshalb muss
`overcurrent_grace_s` **über 5 s** liegen, sonst wirkt die Karenz nicht.
`0` bedeutet „Standardwert verwenden" (3 s bzw. 8 s), ein **negativer** Wert
schaltet die jeweilige Karenz ab.

---

## [shelly] — nur Aufbau 3

Shelly 3EM Drehstromzähler.

```toml
[shelly]
url        = "http://192.168.1.100"   # IP-Adresse des Shelly 3EM (per Web-UI-Scan auffindbar)
generation = "auto"                    # "auto" | "gen1" (HTTP REST) | "gen2" (RPC)
```

Bei `generation = "auto"` fragt PegelWatch beim Start einmalig
`GET {url}/shelly` ab, um die Generation automatisch zu erkennen (schlägt das
fehl, wird sicherheitshalber Gen1 angenommen). Der Shelly 3EM wird danach alle
5 Sekunden abgefragt.

---

## [[logic_output]] — Logik-Relaisausgänge (nur Aufbau 3)

Frei konfigurierbare Relaisausgänge auf den freien Waveshare-Kanälen
**CH4–CH8** (CH1–CH3 sind Pumpe/Alarm/Pneumatik). Ein beliebiges Quellsignal
aus dem System wird gegen einen Festwert verglichen; ist die Bedingung
**länger als die Totzeit** ununterbrochen erfüllt, schaltet das Relais ein —
und nach der Totzeit wieder aus (symmetrische Entprellung gegen Flattern).

```toml
[[logic_output]]
name    = "Lüfter"            # freier Name
enabled = true               # false = inaktiv (fehlend = true)
gpio    = 16                 # freier Kanal: CH4=16, CH5=19, CH6=20, CH7=21, CH8=26
source  = "system.cpu_temp_c" # Quellsignal (siehe unten / /api/signals)
op      = ">"                # > >= < <= == !=
value   = 65.0               # Festwert in der Einheit der Quelle
dwell_s = 30                 # Totzeit in Sekunden (0 = sofort)
```

Am einfachsten in der Konfigurations-UI (Abschnitt „Aufbau 3 → Logik-Ausgänge"):
dort werden **alle verfügbaren Quellsignale mit ihrem Live-Wert** gruppiert
angeboten, und der Vergleich passt sich dem Signaltyp an.

**Quellsignal-Typen:**
- *Numerische Signale* (Analogquellen): Pegel (mm), Sensorspannung (mV),
  Behältervolumen (L), Shelly-Ströme/-Spannungen/-Leistungen (A/V/W),
  Pi-Temperaturen (°C) — alle Vergleichsoperatoren nutzbar, Festwert in der
  Einheit der Quelle.
- *Statussignale* (aktiv/inaktiv): Pumpe läuft, Automatikmodus, Alarme
  (Hoch-/Niedrigwasser/Leckage) je Sensor, Schnell-Polling aktiv,
  Shelly/Grafana/InfluxDB/SMTP erreichbar — nur `==`/`!=`, Festwert
  `1` = aktiv, `0` = inaktiv.

Die vollständige, aktuelle Liste der verfügbaren Signal-Schlüssel liefert
`GET /api/signals` (hängt vom aktiven Aufbau und den konfigurierten Sensoren
ab). Beispiele: `system.cpu_temp_c`, `shelly.l1_a`, `shelly.total_w`,
`sensor.<id>.level_mm`, `container.<id>.current_liters`, `pump.running`,
`alarm.<id>.high`.

**Sicherheit:** Liefert eine Quelle keine (oder nur veraltete) Werte, gilt die
Bedingung als *nicht erfüllt* — der Ausgang fällt nach der Totzeit in den
sicheren Aus-Zustand. Beim Herunterfahren werden alle Logik-Ausgänge
ausgeschaltet. GPIO-Kollisionen (mit reservierten Pins, den festen
Relais-Kanälen oder untereinander) lehnt die Validierung beim Speichern ab.

---

## [grafana]

```toml
[grafana]
url = "http://localhost:3000"   # nur für die Erreichbarkeitsprüfung (Live-Server-Status)
```

---

## [report] — PDF-Betriebsbericht

Regelmäßiger und/oder manueller PDF-Bericht im THW-Design.

```toml
[report]
default_to    = ["chef@thw.de"]  # Standard-Empfänger, auch Vorschlag im Kiosk-Popup
daily_at      = "06:00"          # tägliche Versand-Uhrzeit "HH:MM"; leer = kein Auto-Versand
balance_hours = 24               # Bilanzzeitraum des regelmäßigen Berichts (Stunden)
```

- **Manuell:** In beiden Kiosk-Ansichten (Hebewerk/Mehrkanal) öffnet das
  **📄-Symbol** in der Kopfzeile ein Popup — dort lassen sich Empfänger und
  Bilanzzeitraum je Bericht wählen und der Bericht sofort erstellen (und
  optional versenden). Popup-Angaben überschreiben die Konfiguration.
- **Automatisch:** Ist `daily_at` gesetzt, wird täglich zu dieser Uhrzeit ein
  Bericht über `balance_hours` erzeugt und an `default_to` versendet.
- **Inhalt:** Der Bericht ist ein **Lagebericht für eine Einsatzleitung**
  (Kurzlage mit Beurteilung und Kernzahlen, Allgemeine Lage, Eigene Lage,
  Schadenslage mit Trend und Prognose, je Messstelle eine Seite, Bilanzen,
  Lageführung mit Einsatztagebuch). Dasselbe Format gilt für alle drei
  Aufbauten. Vollständige Beschreibung: [docs/07-lagebericht.md](07-lagebericht.md).
- **Ablage:** Alle Berichte werden unter `/berichte` gelistet und dort als PDF
  geöffnet; sie liegen physisch in `<state-db-Verzeichnis>/reports/` und werden
  180 Tage aufbewahrt. Zu jedem Bericht steht dort seine **SHA-256-Prüfsumme** —
  damit ist eine nachträgliche Änderung des Dokuments erkennbar. Die
  PDF-Erzeugung nutzt das auf dem Pi vorhandene Chromium (headless).

---

## secrets.toml

**Diese Datei enthält alle Zugangsdaten**. Sie gehört dem Dienst-Benutzer
(der Dienst muss sie lesen und über die Weboberfläche schreiben können) und
ist per `chmod 600` nur für ihn lesbar. Sie darf nie in die
Versionskontrolle eingecheckt werden und
reist beim Konfigurations-Export **nie** mit. Schutzziel (präzisiert, siehe
Projektauftrag Änderungshistorie): Schutz vor **versehentlichem Ändern/Export**
(Nutzerfehler), nicht vor einem böswilligen Angreifer mit Zugriff auf den Pi —
deshalb Klartext mit restriktiven Dateirechten statt lokaler Verschlüsselung.

```toml
[influx.local]
token = "mein-influxdb-token-hier"

[influx.fhem]
token = ""

[smtp]
password = "mein-smtp-passwort"
```

---

## Vollständiges Aufbau-3-Beispiel

```toml
# /etc/pegelwatch/config.toml — Aufbau 3: Pumpensteuerung

aufbau = 3

[i2c]
bus = 1

[[sensor]]
id          = "s1"
name        = "Pumpensumpf"
board_addr  = 0x48
channel     = 1   # Kanal 1 = erster Drucksensor …
ref_channel = 0   # … Kanal 0 = Referenz (Konvention aus §2)

[[sensor.calibration]]
water_mm = 0.0
volts_mv = 210.0

[[sensor.calibration]]
water_mm = 2500.0
volts_mv = 2400.0

[[sensor.calibration]]
water_mm = 5000.0
volts_mv = 4500.0

[polling]
fast_ms = 250
slow_s  = 20

[display]
enabled = true

[web]
port = 8080

[alarm]
enabled = true
high_mm = 4000.0
low_mm  = 50.0

[smtp]
host = "smtp.gmail.com"
port = 587
from = "pegelwatch@example.com"
to   = ["andreas@example.com"]

[influx.local]
enabled  = true
url      = "http://localhost:8086"
database = "pegelwatch"

[influx.fhem]
enabled = false

[relay]
pump_gpio      = 5
alarm_gpio     = 6
pneumatic_gpio = 13

[pump_control]
on_level_mm          = 3000.0
off_level_mm         = 500.0
offset_mm            = 0.0
freefall_pressure_pa = 500
self_cal_every       = 10

[overcurrent]
threshold_a          = 15.0
undercurrent_a       = 1.0
undercurrent_grace_s = 3
overcurrent_grace_s  = 8

[shelly]
url        = "http://192.168.1.100"
generation = "auto"
```
