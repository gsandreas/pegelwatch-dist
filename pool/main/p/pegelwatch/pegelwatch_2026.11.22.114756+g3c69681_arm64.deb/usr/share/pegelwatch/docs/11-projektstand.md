# PegelWatch — Projektstand und offene Punkte

Stand: **29.09.2026**. Übergabenotiz für die nächste Arbeitssitzung. Die
Details stehen in den verlinkten Dokumenten. Hier steht nur, was gilt, was
zuletzt geändert wurde und was noch offen ist.

---

## Flotte

| Anlage | Adresse | Aufbau | Build | Kanal |
|---|---|---|---|---|
| PUMPWatch | 192.168.0.106 | 3 (Hebewerk, HDMI-Kiosk) | 2026-09-27 07:32:05 (e35fccc) | stable, `auto_update` an |
| PEGELWatch | 192.168.0.56 | 1 (Grabensensor) | 2026-09-27 07:32:05 (e35fccc) | stable |
| SEPWatch | 192.168.0.198 | 2 | alt | offline, bei Erreichbarkeit: `.\deploy-fleet.ps1 -Device SEPWatch` |

Die SSH-Schlüssel liegen in `%LOCALAPPDATA%\PegelWatch\deploy-keys\<Name>`,
der Benutzer auf den Pis ist `andreas`.

---

## Auslieferung (seit 25.–27.09.)

- **Debian-Paket** `pegelwatch` (arm64), gebaut mit nfpm
  (`packaging/build-deb.ps1`).
- **Signierte apt-Paketquelle** auf GitHub Pages:
  <https://gsandreas.github.io/pegelwatch-dist/>
  - Kanäle `stable` und `daily`
  - Aufbewahrung: 5 daily, 3 stable
  - `releases.json` für Pi und Cloud-Frontend
- **Signaturschlüssel** (ed25519, Fingerprint
  `811C0B63D3FBFEDA059C008F5CFBFAA986058508`, gültig bis 2031):
  - privat nur als Actions-Secret `APT_SIGNING_KEY`
  - lokale Sicherung in `%LOCALAPPDATA%\PegelWatch\signing`
- **Ablauf:** `deploy-fleet.ps1`
  1. schreibt den Changelog fort
  2. baut das Paket einmal
  3. installiert es per LAN auf die Flotte
  4. legt ein GitHub-Release an → der Workflow `publish-apt.yml` veröffentlicht es als daily
- **stable** wird über die Seite *Releases* im Cloud-Frontend hochgestuft
  (GitHub-Dispatch).
- **Auf dem Pi** wählt der Betreiber den Kanal selbst (Konfiguration →
  Software-Updates):
  - Auto-Update installiert nur neuere Builds und erst, wenn die Pumpe steht.
  - Optional kann ein normales `apt upgrade` PegelWatch mitnehmen.
- **Öffentliches Repo** `gsandreas/pegelwatch-dist`: Betreiber-Handbuch
  `docs/handbuch.md` (Inbetriebnahme ohne Rückfrage beim Anbieter).

Details: [08-cloud-frontend.md](08-cloud-frontend.md),
[01-installation.md](01-installation.md), [CHANGELOG.md](../CHANGELOG.md).

---

## Zuletzt erledigt

- **PUMPWatch, Nullpunkt:** Der Offset ist bei jeder Selbstkalibrierung
  hochgelaufen. Behoben durch:
  - Referenz auf den Kalibrier-Nullpunkt statt auf 200 mV
  - Plateau-Median
  - Plausibilitätsgrenze 30 mV
  - Speicherung in `state.db`
- **PUMPWatch, Trockenlauf-Abschaltung:** Abschaltung bei Leistungsabfall
  (Referenz 1260 W, −20 %, 10 s). Sie beendet auch die Kalibrierfahrt.
- **InfluxDB-Ausfall:** Alarm nach 15 min, Entwarnung per Mail.
- **Release-Management** mit den Kanälen daily/stable, Signatur und
  Changelog (siehe oben).
- **apt-Paket-Cache:** Wird nach PegelWatch- und OS-Updates geleert
  (Commit e466c81). Wirkt ab dem nächsten Deploy.
- **Doku zur Sensorversorgung:** Referenzkanal statt Präzisionsreferenz,
  ADS1115 an 5 V mit I²C-Pegelwandler, Warnung zu Pin 27/28 (Commit 5812679).
  Siehe [04-verdrahtung.md](04-verdrahtung.md#sensorversorgung-und-referenzkanal)
  und [09-analog-frontend.md](09-analog-frontend.md).

---

## Hardware-Erkenntnisse (Stand 29.09.)

- **Pumpenplatine (AFE V4):** 5 V, die LT1461-5 läuft aus der Pi-5-V-Schiene im
  Dropout (4,66–5,0 V).
  - Die Messung ist trotzdem richtig, weil der Referenzkanal diese Spannung misst.
  - Die Sensoren liegen dann teils unter 4,75 V.
- **Pegelplatine (PEGELWatch):** 3,3 V für ADS1115 und Sensor.
  - Misst dank Referenzkanal richtig.
  - Der MPXV5050DP läuft damit außerhalb seiner Spezifikation.
- **Softwareseitig** ist keine Änderung nötig. Alle Spannungen werden auf 5 V
  normiert, die Kalibrierung ist je Platine.
- **Geplantes Einplatinenkonzept:**
  - AC/DC-Wandler auf der Platine (5,1–5,2 V) → Pi-Filter → Pi
  - Ferritperle + gedämpfte Cs → Analog-5 V für Sensor und ADS1115
  - keine Referenz-IC
- **Mehrkanal-Aufbau:** eigene, getrennt erzeugte Analog-5 V je Stapel.
- **Zweiter I²C-Bus:** `dtoverlay=i2c6` an **Pin 15/16** (GPIO22/23).
  **Nicht Pin 27/28** (HAT-EEPROM).

---

## Offen

### Beim Betreiber (Andreas)

- [ ] Einmalig den apt-Cache auf beiden Pis leeren (je 1,6–1,7 GB):
  `ssh andreas@192.168.0.106 "sudo apt-get clean"` und dasselbe für
  `192.168.0.56`.
- [ ] Build `2026-09-27 07:32:05 (e35fccc)` im Cloud-Frontend (*Releases*) auf
  stable hochstufen.
- [ ] PUMPWatch: `pump_control.max_runtime_s` von 110 auf etwa 300 setzen. Die
  Kalibrierfahrt bis zum Luftziehen dauert länger.
- [ ] Handbuch (pegelwatch-dist) prüfen:
  - Lieferumfang (Kap. 2.1)
  - Einbau von Glocke und Schlauch (Kap. 5.2)
  - Aussage „I²C-Anpassung macht die Platine selbst“ (Kap. 5.1). Das gilt nur,
    wenn die Pull-ups auf der Pi-Seite des P82B715 an 3,3 V hängen.

### Software / Doku

- [ ] `docs/bedienungsanleitung.html` neu erzeugen: `.\build.ps1 -BuildManual`.
  Dabei wird auch der veraltete Screenshot `konfiguration.png` ohne den Abschnitt
  Software-Updates ersetzt.
- [ ] SEPWatch deployen, sobald erreichbar.
- [ ] Optional, noch nicht entschieden: Überwachung der Sensorversorgung
  (Referenzkanal außerhalb 4,75–5,25 V → Warnung). Diese Warnung würde auf der
  3,3-V-Pegelplatine bewusst anschlagen.
- [ ] Optional: I²C-Pegelwandler bzw. Pull-up-Spannung in der nächsten
  Platinenrevision festlegen.

### Hardware (nächste Revision)

- [ ] AFE: LT1461 aus ≥ 7 V speisen oder weglassen. Sensor und ADS1115 an eine
  gefilterte Analog-5-V-Schiene, Referenz am Vs-Pin abgreifen, gleiche RC-Glieder
  auf Referenz- und Sensorkanal.
- [ ] AC/DC-Wandler auf der Platine: Luft- und Kriechstrecken, Sicherung,
  Varistor, CE nach Niederspannungs- und EMV-Richtlinie. Ein zertifiziertes
  Printmodul (z. B. Mean Well IRM, Recom) vereinfacht die Zulassung.

---

## Nie ins Repo

`config.toml`, `secrets.toml`, `deploy/.netrc`, `frontend/config.local.php`,
SSH-Schlüssel, den privaten Signaturschlüssel und GitHub-Tokens.
