# PegelWatch — Hardware-Prüfsuite für die 4-Kanal-Sensorplatine (afetest)

`afetest` prüft die Hardware der Sensorplatine
**PegelV2Evo_AnalogFrontEnd_V5** (`.sch` + `.brd`, Eagle 7.7) mit einem
**Raspberry Pi Zero W** als Prüfrechner. Geprüft wird nur die Hardware: es
läuft keine PegelWatch-Anwendung, keine Datenbank, kein Webserver.

Grundlage ist die Netzliste aus Schaltplan **und** Board V5 (beide sind
netzgleich; gegenüber V4 sind nur Bestückungsangaben geändert, siehe unten).
Wie die Platine funktioniert, beschreibt
[09-analog-frontend.md](09-analog-frontend.md).

---

## Prüfadapter: Pi Zero W ↔ Steckleiste J5

J5 (Samtec SSQ-110, 2 × 10) führt jedes Signal doppelt (gegenüberliegende
Pins). Es genügt, je Signal einen der beiden Pins zu verdrahten.

| J5 | Signal Karte | Pi Zero W (physischer Pin) | Bemerkung |
|---|---|---|---|
| 15/16 | +5V | **2** (5 V) | versorgt die ganze Karte |
| 19/20 | GND (digital) | **6** (GND) | LED1, U1 |
| 17/18 | AGND (analog) | **9** (GND) | ADS1115, Sensoren, LT1461 — **beide Massen anschließen**, sie sind auf der Karte nicht verbunden |
| 11/12 | SDA | **3** (GPIO2) | |
| 13/14 | SCL | **5** (GPIO3) | |
| 3/4 | ALERT1 (SJ15) | **11** (GPIO17) | |
| 5/6 | ALERT2 (SJ17) | **13** (GPIO27) | |
| 7/8 | ALERT3 (SJ14) | **15** (GPIO22) | |
| 9/10 | ALERT4 (SJ16) | **16** (GPIO23) | |
| 1/2 | — | — | nicht belegt |

Andere GPIOs für ALERT1–4 lassen sich im Profil (`alert_gpio`) einstellen.
Ohne verdrahtete ALERT-Leitungen laufen alle anderen Prüfungen trotzdem.

> **Sicherheit (zeigt `afetest` vor jedem Lauf an):**
>
> 1. **Karte nur bei ausgeschaltetem Pi anstecken.** Rund 3,5 mF an +5V
>    ziehen die 5-V-Schiene des Pi beim Einstecken herunter.
> 2. **5-V-Pull-ups am I²C:** R14/R15 (2,2 kΩ) ziehen SDA/SCL an +5V. Mit den
>    1,8-kΩ-Pull-ups des Pi an 3,3 V stellen sich rund 4 V an GPIO2/GPIO3 ein —
>    über der Spezifikation des Pi. Für einen Prüfplatz, der viele Karten
>    prüft, einen **I²C-Pegelwandler (z. B. PCA9306)** zwischen Pi und J5
>    setzen (Pi-Seite 3,3 V, Kartenseite +5V von J5.15).
> 3. **Sichtprüfung vor dem ersten Einschalten:** Polung von C16, C17, C20
>    (siehe Befund 2 unten).
> 4. Netzteil für den Pi Zero W mindestens 2 A, kurzes Kabel.

---

## Pi Zero W vorbereiten

1. Raspberry Pi OS **Lite 32-bit** (der Pi Zero W ist ARMv6; arm64 läuft nicht).
2. I²C einschalten: `sudo raspi-config nonint do_i2c 0`, neu starten.
   Der Standardtakt 100 kHz ist richtig.
3. Der Benutzer braucht die Gruppen `i2c` und `gpio` (beim ersten Benutzer
   von Raspberry Pi OS bereits gesetzt).
4. Binary bauen und kopieren (unter Windows):

   ```powershell
   .\build-afetest.ps1 -Test -PiHost <IP-des-Pi-Zero>
   ```

   `-Test` führt vorher die Unit-Tests gegen die simulierte Karte aus.
   Ohne `-PiHost` entsteht nur `.\afetest` (linux/arm, GOARM=6).

---

## Ablauf

```bash
./afetest -sn K-0042                    # vollständig, mit Sicht- und Drucktests
./afetest -sn K-0042 -batch             # nur automatische Prüfungen (ca. 30–40 s)
./afetest -sn K-0042 -column-mm 1000    # zusätzlich Wassersäulentest (1 m)
./afetest -only V01,V02,K01             # einzelne Schritte
./afetest -list                         # Prüfschritte, Grenzwerte, Fehlerbilder
./afetest -print-profile > afetest.toml # Profil zum Anpassen
```

Die Rückfragen (Seriennummer, LEDs, Drucktest) brauchen ein Terminal — per
SSH mit `ssh -t` starten; ohne Eingabemöglichkeit gilt jede Frage als „nein“.
Für Skripte `-batch` verwenden.

Jeder Lauf legt unter `./protokolle/` ein Text- und ein JSON-Protokoll ab
(`<Datum>-<Zeit>_<Seriennummer>.txt/.json`).
Exit-Code: **0** bestanden (auch mit Warnungen), **1** nicht bestanden,
**2** Startfehler (z. B. `/dev/i2c-1` fehlt).

Ohne Hardware (Windows oder Pi) zeigt `-sim` den kompletten Ablauf an einer
simulierten Karte; `-sim-fault clone,alert-bridge,…` spielt Fehlerbilder durch.

---

## Checkliste im Browser (Servermodus)

Mit `-serve` liefert der Pi die Inbetriebnahme-Checkliste selbst aus. Die
Prüfung wird dann aus der Checkliste bedient, nicht mehr im Terminal:

```bash
./afetest -serve                  # Checkliste unter http://<IP-des-Pi>:8080
./afetest -serve -listen :9000    # anderer Port
./afetest -serve -sim             # ohne Hardware, auch unter Windows
```

Beim Start nennt `afetest` die Adressen, unter denen die Seite erreichbar ist.

Weil der Pi für jede Karte aus- und wieder eingeschaltet wird, läuft der
Servermodus am besten als Dienst. Das Build-Skript richtet ihn ein:

```powershell
.\build-afetest.ps1 -Test -PiHost <IP-des-Pi-Zero> -InstallService
```

Das legt [deploy/afetest.service](../deploy/afetest.service) als Benutzerdienst
nach `~/.config/systemd/user/` und schaltet ihn ein (kein `sudo` nötig). Damit
er ab dem Einschalten läuft, ohne dass sich jemand anmeldet, einmalig auf dem
Pi `loginctl enable-linger` ausführen. Spätere Aufrufe des Skripts mit
`-PiHost` starten den Dienst nach dem Kopieren neu. Zustand und Ausgabe:
`systemctl --user status afetest`, `journalctl --user -u afetest`.

Im Browser eines Rechners im selben Netz:

- **Zustand des Pi** im Schritt „Pi Zero W vorbereiten“: Modell, I²C-Takt,
  gefundener ADS1115 (0x48–0x4B) und Unterspannung.
- **Prüfung starten** im Schritt „afetest ausführen“: vollständig mit Sicht-
  und Drucktests oder nur die automatischen Prüfungen. Das Profil der Karte
  (Adresse, ALERT-Leitung, Kanäle) geht aus der Konfiguration der Checkliste
  mit. Die Ausgabe läuft mit; Rückfragen (LEDs, Druck geben, Druck wegnehmen)
  erscheinen als Knöpfe, **Enter** bzw. **J/N** gehen wie im Terminal.
- **Protokoll**: landet nach dem Lauf in der Karte und zusätzlich wie gewohnt
  unter `./protokolle/`.

Auf echter Hardware lässt sich die Prüfung erst starten, wenn in der Karte
die Schritte „Sichtprüfung vor dem ersten Einschalten“ und „Karte stecken,
dann Pi einschalten“ abgehakt sind. „Prüfung abbrechen“ beendet die Rückfragen;
eine begonnene Messung läuft noch zu Ende, ein Protokoll entsteht dann nicht.

Die Karten der Checkliste (Fortschritt, Messwerte, Protokoll) liegen im
Servermodus auf dem Pi unter `./karten/<Kennung>.json` (`-cards` ändert das
Verzeichnis), daneben das Profil des letzten Laufs als `.toml`.

> **Kein Zugriffsschutz.** Jeder im selben Netz kann Prüfläufe starten und
> Karten ändern. `-serve` gehört nur ins Netz des Prüfplatzes;
> `-listen 127.0.0.1:8080` beschränkt den Zugriff auf den Pi selbst.

Dieselbe Seite ist auch als Artifact auf claude.ai veröffentlicht. Dort
funktioniert alles außer der Verbindung zum Pi: der Browser lässt von
claude.ai aus keinen Zugriff auf Geräte im eigenen Netz zu. Karten, die dort
angelegt wurden, liegen bei claude.ai und erscheinen nicht auf dem Pi.

| Aufruf | Zweck |
|---|---|
| `GET /` | Checkliste |
| `GET /api/status` | Zustand des Prüfrechners, gefundene ADS1115-Adressen, Prüfschritte |
| `GET`, `PUT`, `DELETE /api/boards[/<Kennung>]` | Karten lesen, speichern, löschen |
| `POST /api/run` | Prüflauf starten (`board`, `serial`, `profile` als TOML, `batch`, `column_mm`) |
| `GET /api/run?since=<n>` | Zustand, Ausgabe ab Position n, offene Rückfrage, am Ende das Protokoll |
| `POST /api/run/answer`, `/api/run/abort` | Rückfrage beantworten, Lauf abbrechen |

Schreibende Aufrufe brauchen `Content-Type: application/json`; damit kann
keine fremde Webseite über den Browser des Prüfers einen Lauf auslösen.

---

## Prüfumfang

| ID | Prüfung | Methode | Erkennt u. a. |
|---|---|---|---|
| S01 | Prüfumgebung | Modell, Kernel, I²C-Takt aus dem Device-Tree | falscher Prüfrechner, I²C-Takt |
| S02 | Pi-Versorgung | `get_throttled` | Unterspannung am Pi (Netzteil, Einschaltstrom der Karte) |
| J01 | ALERT-Leitungen statisch | jede Leitung mit Pull-down und Pull-up des Pi lesen | Kurzschluss nach GND, Verbindung zu +5V/SDA/SCL, Pull-up auf dem ADS-Modul |
| I01 | Busscan | 1-Byte-Lesezugriff auf 0x08–0x77 | fehlende Versorgung/Masse, SDA klemmt (alle Adressen antworten), fremde Teilnehmer |
| I02 | Adresse | gegen Profil, Deutung der Brücken SJ18/SJ20 | falsch gesetzte Adressbrücke |
| I03 | Registerdefaults | General-Call-Reset, Config 0x8583, Schwellen 0x8000/0x7FFF | Bitfehler, Reset ohne Wirkung |
| I04 | Bitmuster | 42 Muster gegenläufig in Lo/Hi_thresh (84 Registerwerte), Bitmasken der Fehler | kippende Bits auf SDA |
| I05 | Konfigurationsregister | jedes Feld (MUX, PGA, DR, Komparator) + Zufallswerte | Register-/Busfehler |
| I06 | Dauertest | 2000 Schreib-/Lesezyklen mit Zufallswerten | sporadische Fehler (Pegel, Pull-ups, Leitungslänge) |
| J02 | Querschluss | eine Leitung auf 0 V treiben, die anderen lesen; I²C muss weiterlaufen | Brücken zwischen ALERT-Pins und zu SDA/SCL |
| J03 | Übersprechen | Flanken auf ALERT1–4 während 300 I²C-Zugriffen | Kopplung SDA/SCL → ALERT |
| A01 | Baustein | Wandlungszeit bei Datenraten-Code 000 (ADS1115: 125 ms, ADS1015: 7,8 ms), belegte Bits 3:0 | **gefälschte/falsche Module (ADS1015, 12 Bit)** |
| A02 | Wandlungszeiten | alle 8 Datenraten über das OS-Bit, Messunsicherheit wird abgezogen | Oszillator außerhalb ±10 % |
| R01 | ALERT/RDY-Brücke | Komparator gezielt aktiv/inaktiv in beiden Polaritäten | welche Brücke SJ14–SJ17 geschlossen ist, offene/mehrfache Brücken, ALRT-Stift unverlötet |
| R02 | RDY-Takt | Dauerbetrieb 8/128/860 SPS, Kernel-Zeitstempel der RDY-Pulse | Oszillatorabweichung (genau auf < 0,1 %) |
| V01 | 5V_REG | Referenzkanal A0 (SJ5), 16 SPS, Mittel aus 16 | LT1461 regelt / Dropout / zu niedrig, SJ5 offen, Kurzschluss auf 5V_REG |
| V02 | Rauschen 5V_REG | 860 SPS über 2 s, effektiv (trendbereinigt) und Spitze-Spitze | Filter L1/FB1/Elkos, Schwingen |
| V03 | Laststufe | 5V_REG ohne/mit CPU-Volllast des Pi | Durchgriff der Pi-Versorgung (Dropout) |
| K01 | Kanäle | je Kanal 2 × 16 Werte im Abstand 0,4 s: Pegel, Verhältnis zu 5V_REG, Drift; Abgleich mit Profil | fehlender Sensor (offener OPV-Eingang driftet), Kurzschluss nach AGND, Kanal auf 5V_REG, OPV-Sättigung |
| K02 | Sensor-Nullpunkt | Sensor und Referenz abwechselnd, ratiometrisch auf 5 V normiert | Sensor außerhalb 88–313 mV (Datenblatt) |
| K03 | Kanalrauschen | 860 SPS, 1,5 s je Sensor | schlechte Lötstellen, fehlende Filterwirkung |
| K04 | Kanalunabhängigkeit | Abstand aller Kanalpaare, bei Verdacht Differenzmessung im ±0,256-V-Bereich | Lötbrücken zwischen Kanälen |
| A03 | PGA-Gleichlauf | ein Sensorkanal (≈ 0,2 V) in allen 6 Bereichen, vor- und rückwärts | Verstärkungsfehler einzelner Bereiche |
| A04 | Multiplexer | Differenzeingänge A0–A1, A0–A3, A1–A3, A2–A3 gegen Einzelmessungen | Multiplexerfehler |
| M01 | LED1 | Frage an den Prüfer | LED1/R13 |
| M02 | LED2/LED3 | drei Blöcke I²C-Verkehr, Frage an den Prüfer | U1 nicht/verkehrt gesteckt, LED2/R18/R19, LED3/R17/R16 |
| M03 | Drucktest | Prüfer gibt nacheinander auf jeden Sensor Druck; Anstieg, Übersprechen, Rückkehr | Zuordnung, toter Sensor, vertauschte Druckanschlüsse, Übersprechen |
| M04 | Wassersäule | bekannte Wassertiefe (`-column-mm`), Abweichung gegen 90 mV/kPa | Empfindlichkeit außerhalb ±2,5 % VFSS |
| S03 | Abschluss | Reset der Karte, Unterspannung während der Prüfung? | — |

Alle Grenzwerte mit Herleitung zeigt `./afetest -list`; im Profil lassen sie
sich unter `[limits.<Schlüssel>]` anpassen.

### Was die Suite nicht messen kann

- Die **+5V-Eingangsspannung** und die **I²C-Pegel** selbst (der Pi hat keinen
  Analogeingang; 5V_REG wird über den ADS1115 gemessen).
- **R9–R12 / C9–C12** (750 Ω / 0,47 µF) nur indirekt: ein offener Widerstand
  fällt in K01 auf, ein fehlender Kondensator praktisch nicht (der Digitalfilter
  des ADS1115 liegt in derselben Größenordnung wie die 451 Hz des RC-Glieds).
- **OPV-Offset** des LMV324 und die **ESD-Dioden** (IC5/IC6, in V5 ohnehin DNP).
- **Kanäle ohne Sensor**: ein unbestückter Kanal (Rolle `empty`) hat einen offenen
  OPV-Eingang und ist nur als „driftet/offen“ erkennbar. Die Signalkette lässt
  sich nur mit bestücktem Sensor (oder einem Signal am VOUT-Pad) prüfen.

---

## Profil und Bestückungsvarianten

Ohne `-profile` gilt die **V5-Standardbestückung** laut Schaltplan:

- **CH1 / A0 = Referenzkanal:** SJ5 geschlossen (einzige Lötbrücke ohne DNP),
  legt 5V_REG direkt auf A0; IC1 nicht bestückt.
- **CH2–CH4 / A1–A3:** MPXV5050DP IC2–IC4.
- **Adresse 0x48:** SJ18/SJ20 offen, ADDR über den Pull-down des ADS-Moduls an
  Masse.
- **ALERT:** SJ14–SJ17 offen (DNP) → R01 meldet INFO, R02 entfällt. Für den
  Stapelbetrieb mit ALERT-Auswertung im Profil `alert_line = 1…4` setzen.
- **U1 (P82B715) gesteckt.**

Abweichende Karten (z. B. ohne Sensoren, andere Adresse, Referenz auf einem
anderen Kanal) bekommen ein eigenes Profil, Vorlage:
[afetest.toml.example](../afetest.toml.example).

---

## Befunde aus Schaltplan und Board V5

Beim Ableiten der Prüfungen aus der Netzliste sind folgende Punkte
aufgefallen. Sie betreffen das Design, nicht die Prüfsuite.

1. **I²C-Pull-ups an +5V direkt am Pi.** J5.11–14 hängen am selben Netz wie
   ADS1115, R14/R15 und die Sx/Sy-Seite des P82B715. Der P82B715 trennt hier
   keine Pi-Seite ab — er treibt nur die LEDs (Lx/Ly). Der Pi sieht damit rund
   4 V an GPIO2/3. Die Aussage „I²C-Anpassung macht die Platine selbst“ trifft
   für V5 nicht zu (vgl. offener Punkt in [11-projektstand.md](11-projektstand.md)).
2. **Polung C16, C17, C20 (1000 µF/6,3 V).** Im Schaltplan liegt der Pin „+“
   des Symbols an **AGND**, „−“ an +5V / 5V_L1 / 5V_FILTER. Der Footprint
   `UWT(8X10)` hat keine Polaritätsmarkierung. Wird nach Pad 1 = „+“ bestückt,
   liegen die Elkos verpolt an 5 V. Bestückung prüfen; im Symbol/Footprint
   korrigieren.
3. **SJ5 und OPV A gemeinsam auf A0.** Mit geschlossenem SJ5 liegt 5V_REG
   direkt auf A0, gleichzeitig treibt der Ausgang von IC7A dasselbe Netz. Der
   Eingang von IC7A hängt (IC1 unbestückt) offen an C12. Der OPV arbeitet damit
   gegen 5V_REG. Messbar ist das mit der Suite nicht direkt; in der nächsten
   Revision den OPV-Ausgang des Referenzkanals abtrennbar machen.
4. **Gleichtaktbereich LMV324.** Der LMV324 verarbeitet Eingänge nur bis etwa
   V+ − 0,8 V (Datenblatt, typisch). Bei 5V_REG = 5,0 V sättigen die
   Sensorkanäle ab ≈ 4,2 V, das sind ≈ 44 kPa ≈ 4,5 m WS. Weil Sensor und
   Grenze beide mit 5V_REG skalieren, gilt die Druckgrenze auch im Dropout.
   Der obere Teil des Sensorbereichs (bis 50 kPa / 4,52 V) ist damit nicht
   nutzbar.
5. **ESD-Dioden IC5/IC6 ohne Wirkung.** Pin 3 (gemeinsame Kathode) der
   DZ23C20 ist an kein Netz angeschlossen; bestückt lägen nur zwei Z-Dioden in
   Reihe zwischen zwei Kanälen. In V5 sind sie DNP.
6. **AGND und GND nur über J5 verbunden** (17/18 bzw. 19/20). Jeder Adapter
   bzw. Pi-Anschluss muss beide Massen führen.
7. **C1–C4 jetzt 100 µF X5R 1206 / 6,3 V** (V4: Tantal). Bei 5 V Gleichspannung
   bleiben von keramischen 100 µF in 1206 je nach Typ nur etwa 20–30 % übrig
   (DC-Bias-Kurve des Herstellers prüfen). C14 trägt
   den Wert „100uF10V 2312“, hat aber den 1206-Footprint — BOM prüfen.
8. **LT1461 im Dropout** aus der Pi-5-V-Schiene (bekannt, siehe
   [09-analog-frontend.md](09-analog-frontend.md)); V01/V03 zeigen den Zustand
   je Karte an.

### Änderungen V4 → V5 (laut Dateien)

| | V4 | V5 |
|---|---|---|
| Netzliste | — | unverändert (Schaltplan und Board netzgleich) |
| C1–C4 | 100 µF Tantal (CPOL 6032) | 100 µF X5R 1206 |
| C14 | 100 µF Tantal | 1206-Footprint, Wert „100uF10V 2312“ |
| DNP-Kennzeichnung | Sensoren, U1, J5, ADS-Modul, R1–R8 | zusätzlich J1–J4, IC5/IC6, alle Lötbrücken außer SJ5 |

---

## Aufbau des Codes

| Datei | Inhalt |
|---|---|
| `cmd/afetest/main.go` | Programm, Optionen, Protokolldateien |
| `cmd/afetest/serve.go` | Servermodus `-serve`: Checkliste ausliefern, Karten speichern, Prüflauf mit Rückfragen über HTTP |
| `cmd/afetest/web/checkliste.html` | die Checkliste (ins Binary eingebettet; dieselbe Datei ist das Artifact auf claude.ai) |
| `internal/afetest/hw.go`, `hw_linux.go` | I²C über `I2C_RDWR` (Repeated Start), GPIO über go-gpiocdev, Systeminfos |
| `internal/afetest/ads.go` | ADS1115 auf Registerebene mit Messung der Wandlungszeit |
| `internal/afetest/profile.go` | Hardwaredaten V5 (Kanäle, Brücken, Pins) und Prüfprofil |
| `internal/afetest/limits.go` | Grenzwerte mit Herleitung |
| `internal/afetest/t_*.go` | die Prüfschritte |
| `internal/afetest/sim.go` | simulierte Karte mit Fehlerbildern (für `-sim` und die Unit-Tests) |

Die Unit-Tests (`go test ./internal/afetest/`) lassen die komplette Suite gegen
die simulierte Karte laufen: eine fehlerfreie Karte muss bestehen, und jedes
Fehlerbild muss im richtigen Prüfschritt auffallen. `go test ./cmd/afetest/`
prüft den Servermodus gegen die simulierte Karte: Karten speichern, Läufe mit
und ohne Rückfragen, Abbruch und abgelehnte Anfragen.
